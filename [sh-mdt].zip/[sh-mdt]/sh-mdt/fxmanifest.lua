fx_version 'cerulean'
game 'gta5'
lua54 'yes'


name 'sh-mdt'
author 'SherlockCo'
description 'MDT policial integrado con radio - QB-Core'
version '0.1.0'

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/app.js',
    'html/images/*.png',
    'html/images/*clicks.ogg',
    'html/images/*open.ogg'
}

shared_script 'config.lua'

client_scripts {
    'client/main.lua',
    'client/camara.lua',
    'client/fotoViewer.lua',
    'client/detector.lua',
    'client/servicio.lua',
    'client/dispatch.lua',
    'client/ciudadanos.lua',
    'client/vehiculos.lua',
    'client/informes.lua',
    'client/codigo_penal.lua',
    'client/registroarma.lua',
    'client/tiempo.lua',
    'client/agentes.lua',
    'client/busquedacaptura.lua',
    'client/dashcams.lua',
    'client/camaras.lua',
    'client/federal.lua',
    'client/evidencias.lua',
    'client/analisis.lua',
    'client/tags.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua', -- opcional si luego guardas cosas en DB
    'server/main.lua',
    'server/servicio.lua',
    'server/camara.lua',
    'server/dispatch.lua',
    'server/ciudadanos.lua',
    'server/vehiculos.lua',
    'server/informes.lua',
    'server/codigo_penal.lua',
    'server/registroarma.lua',
    'server/tiempo.lua',
    'server/agentes.lua',
    'server/busquedacaptura.lua',
    'server/dashcams.lua',
    'server/camaras.lua',
    'server/federal.lua',
    'server/evidencias.lua',
    'server/analisis.lua',
    'server/tags.lua'
}

dependencies {
    'qb-core',
    'oxmysql',
    'PolyZone',
    'screenshot-basic'
}
