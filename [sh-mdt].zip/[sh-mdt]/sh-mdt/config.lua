Config = {}

-- Item requerido para abrir el MDT
Config.RequiredItem = 'tablet2'

-- Job y servicio
Config.AllowedJob = 'police'
Config.RequireOnDuty = false

-- Keymapping
Config.CommandName = 'shmdt'
Config.KeyDefault = 'NUMPAD0'

-- NUI
Config.EnableCloseWithEsc = true

-- Texto UI
Config.Slogan = 'Proteger y Servir'

-- 🔥 NUEVO: Configuración de licencias
Config.Licencias = {
    -- Licencias tradicionales (de metadata)
    LicenciasTradicionales = {
        ["driver"] = "LICENCIA DE CONDUCIR",
        ["weapon"] = "LICENCIA DE PORTE DE ARMAS", 
        ["business"] = "LICENCIA COMERCIAL",
        ["pilot"] = "LICENCIA DE PILOTO",
        ["fishing"] = "LICENCIA DE PESCA"
    },
    
    -- Items del inventario que se consideran licencias
    LicenciasInventario = {
        ["weaponlicense"] = "LICENCIA DE ARMAS",
        ["bank_card"] = "TARJETA BANCARIA", 
        ["lawyerpass"] = "PASE DE ABOGADO",
        ["driver_license"] = "LICENCIA DE CONDUCIR",
        ["id_card"] = "DOCUMENTO DE IDENTIDAD",
        ["medical_card"] = "CARNET MÉDICO",
        ["business_license"] = "LICENCIA COMERCIAL",
        ["fishing_license"] = "LICENCIA DE PESCA",
        ["pilot_license"] = "LICENCIA DE PILOTO"
    },
    
    -- Estados disponibles para licencias
    EstadosLicencias = {
        "VÁLIDA",
        "SUSPENDIDA", 
        "REVOCADA"
    },
    
    -- Tipos de licencias para agregar manualmente
    TiposLicencias = {
        "LICENCIA DE CONDUCIR",
        "LICENCIA DE PORTE DE ARMAS",
        "LICENCIA COMERCIAL", 
        "LICENCIA DE PILOTO",
        "LICENCIA DE PESCA",
        "TARJETA BANCARIA",
        "PASE DE ABOGADO",
        "DOCUMENTO DE IDENTIDAD",
        "CARNET MÉDICO"
    }
}

-- 🔥 NUEVO: Configuración de Cámaras de Seguridad
Config.Camaras = {
    {id = 1, nombre = "Comisaría - Entrada Principal"},
    {id = 2, nombre = "Comisaría - Estacionamiento"},
    {id = 3, nombre = "Comisaría - Celda 1"},
    {id = 4, nombre = "Comisaría - Celda 2"},
    {id = 5, nombre = "Centro - Plaza Principal"},
    {id = 6, nombre = "Centro - Banco Fleeca"},
    {id = 7, nombre = "Centro - Jewelry Store"},
    {id = 8, nombre = "Centro - Tribunal"},
    {id = 9, nombre = "Centro - Hospital Pillbox"},
    {id = 10, nombre = "Sur - Puerto"},
    {id = 11, nombre = "Sur - Aeropuerto Entrada"},
    {id = 12, nombre = "Sur - Aeropuerto Terminal"},
    {id = 13, nombre = "Norte - Vinewood Blvd"},
    {id = 14, nombre = "Norte - Casino"},
    {id = 15, nombre = "Norte - Galería de Arte"},
    {id = 16, nombre = "Este - Estación de Tren"},
    {id = 17, nombre = "Este - Concesionario"},
    {id = 18, nombre = "Este - Motel"},
    {id = 19, nombre = "Oeste - Playas"},
    {id = 20, nombre = "Oeste - Muelle"},
    {id = 21, nombre = "Sandy Shores - Tienda"},
    {id = 22, nombre = "Sandy Shores - Aeródromo"},
    {id = 23, nombre = "Paleto Bay - Banco"},
    {id = 24, nombre = "Paleto Bay - Ayuntamiento"},
    {id = 25, nombre = "Autopista - Entrada Norte"},
    {id = 26, nombre = "Autopista - Entrada Sur"},
    {id = 27, nombre = "Túneles - Centro"},
    {id = 28, nombre = "Túneles - Este"},
    {id = 29, nombre = "Zona Industrial"},
    {id = 30, nombre = "Mina abandonada"},
    {id = 31, nombre = "Base Militar - Entrada"},
    {id = 32, nombre = "Joyeria - Torre"},
    {id = 33, nombre = "Penitenciaría - Entrada"},
    {id = 34, nombre = "Penitenciaría - Patio"}
}

-- 🔥 NUEVO: Configuración de Dashcams
Config.Dashcams = {
    -- Rango mínimo requerido para ver dashcams (grade 1 = todos los policías)
    MinGrade = 1,
    
    -- Mensajes y notificaciones
    Messages = {
        NoPermission = "No tienes permiso para ver dashcams",
        Spectating = "Viendo dashcam de ~b~%s~y~ - BACKSPACE para salir",
        StoppedSpectating = "Dejaste de ver la dashcam",
        TargetOffline = "El oficial no está en servicio"
    }
}

Config.Animation = {
    dict = "amb@code_human_in_bus_passenger_idles@female@tablet@idle_a",
    name = "idle_a",
    prop = "prop_cs_tablet",
    propBone = 28422,
    propOffset = { x = -0.05, y = 0.0, z = 0.0 },
    propRot = { x = 0.0, y = 0.0, z = 0.0 },
    loop = true,
    moving = true
}

-- Config (agregar)
Config.CodigoPenalMinGrade = 1  -- cambiar al grade que quieras permitir crear/eliminar
Config.MultaPagoTipo = "bank"  -- "cash" o "bank"


-- Tags predeterminados
--Config.DefaultTagsAgentes = {
--    "Experto en Tiro",
--    "Piloto de Aviones",
--    "Buzo Profesional",
--    "Francotirador",
--    "Negociador"
--}

--Config.DefaultTagsInformes = {
  --  "Caso Abierto",
    --"Caso Cerrado",
    --"Investigación en Curso",
    --"Detective Boreu"
--}

-- en tu config.lua
-- Configuración de permisos para ascensos
Config.PromotionMinGrade = 3  -- Solo rangos 3 o superiores pueden ascender/descender

-- ==========================================================
-- 🔹 SISTEMA DE ARMARIOS Y EVIDENCIAS POLICIALES
-- ==========================================================
-- ==========================================================
-- 🔹 SISTEMA DE ARMARIOS Y EVIDENCIAS POLICIALES
-- ==========================================================
Config.PoliceArmorySystem = {
    enabled = true, -- ✅ activar / ❌ desactivar todo el sistema
    locations = {
        {
            coords = vector3(485.45, -994.78, 31.07),
            radius = 1.5,
            label = "Comisaría Principal"
        },
        {
            coords = vector3(-445.58, 6019.46, 37.13),
            radius = 1.5, 
            label = "Estación Norte"
        },
        --{
           -- coords = vector3(361.45, -1584.78, 29.29),
           -- radius = 1.5,
            --label = "Estación Sur"
        --},
        -- 🔹 Puedes agregar más ubicaciones aquí:
        -- {
        --     coords = vector3(x, y, z),
        --     radius = 1.5,
        --     label = "Nombre de la ubicación"
        -- }
    }
}

-- 🔹 Equipamiento Policial (stash fijo)
Config.EquipamientoPolicial = {
    ['police'] = {
        { name = 'weapon_pistol',       price = 0, amount = 50, info = { attachments = { { component = 'COMPONENT_AT_PI_FLSH', label = 'Flashlight' } } } },
        { name = 'weapon_stungun',      price = 0, amount = 50, info = { attachments = { { component = 'COMPONENT_AT_AR_FLSH', label = 'Flashlight' } } } },
        { name = 'weapon_pumpshotgun',  price = 0, amount = 50, info = { attachments = { { component = 'COMPONENT_AT_AR_FLSH', label = 'Flashlight' } } } },
        { name = 'weapon_smg',          price = 0, amount = 50, info = { attachments = { 
            { component = 'COMPONENT_AT_SCOPE_MACRO_02', label = '1x Scope' }, 
            { component = 'COMPONENT_AT_AR_FLSH', label = 'Flashlight' } } } },
        { name = 'weapon_carbinerifle', price = 0, amount = 50, info = { attachments = { 
            { component = 'COMPONENT_AT_AR_FLSH', label = 'Flashlight' }, 
            { component = 'COMPONENT_AT_SCOPE_MEDIUM', label = '3x Scope' } } } },
        { name = 'weapon_nightstick',   price = 0, amount = 50 },
        { name = 'weapon_flashlight',   price = 0, amount = 50 },
        { name = 'pistol_ammo',         price = 0, amount = 50 },
        { name = 'smg_ammo',            price = 0, amount = 50 },
        { name = 'shotgun_ammo',        price = 0, amount = 50 },
        { name = 'rifle_ammo',          price = 0, amount = 50 },
        { name = 'handcuffs',           price = 0, amount = 50 },
        { name = 'empty_evidence_bag',  price = 0, amount = 50 },
        { name = 'police_stormram',     price = 0, amount = 50 },
        { name = 'armor',               price = 0, amount = 50 },
        { name = 'radio',               price = 0, amount = 50 },
        { name = 'binoculars',          price = 0, amount = 50 },
        { name = 'heavyarmor',          price = 0, amount = 50 },
        { name = 'pol_detector',        price = 0, amount = 50 },
        { name = 'pol_camera',          price = 0, amount = 50 },
    }
}

-- ==========================================================
-- 🔹 SISTEMA DE PROCESADOS (PRESOS) - INDEPENDIENTE
-- ==========================================================
Config.ProcessedSystem = {
    enabled = true,
    locations = {
        {
            coords = vector3(473.17, -1006.99, 26.24),
            label = "Lista de Procesados",
            radius = 1.5
        },
        {
            coords = vector3(-448.78, 6005.72, 28.11),
            label = "Lista de Procesados", 
            radius = 1.5
        },
        -- Agrega más ubicaciones aquí:
        -- {
        --     coords = vector3(x, y, z),
        --     label = "Lista de Procesados",
        --     radius = 1.5
        -- }
    }
}

-- ==========================================================
-- 🔹 SISTEMA DE HUELLAS DIGITALES
-- ==========================================================
Config.FingerprintSystem = {
    enabled = true,
    locations = {
        {
            coords = vector3(472.0, -1010.92, 26.56),
            prop = "h4_prop_h4_fingerkeypad_01b",
            heading = 0.0,
            label = "Apoyar Dedo",
            propOffset = vector3(0.0, -0.025, 0.0)  -- Ajuste si está en la pared
        },
        {
            coords = vector3(-454.83, 5998.16, 27.91),
            prop = "h4_prop_h4_fingerkeypad_01b", 
            heading = 135.0,
            label = "Apoyar Dedo",
            propOffset = vector3(0.0, 0.025, 0.0)
        },
        -- Agrega más ubicaciones aquí:
        -- {
        --     coords = vector3(x, y, z),
        --     prop = "h4_prop_h4_fingerkeypad_01b",
        --     heading = 0.0,
        --     label = "Apoyar Dedo",
        --     propOffset = vector3(0.0, 0.0, 0.0)  -- Ajustar si está en pared
        -- }
    }
}


Config.Dispatch = {
    Framework = "qbcore", -- 🔥 AGREGAR ESTA LÍNEA
    
    Commands = {
        OpenMiniDispatch = {
            key = 'U',
            description = "Abrir mini dispatch"
        },
        AcceptAlert = {
            key = 'O', 
            description = "Aceptar alerta"
        },
        DeleteAlert = {
            key = 'I',
            description = "Eliminar alerta"
        },
        NextAlert = {
            cmd = 'nxtalert',
            description = "Siguiente alerta",
            key = 'RIGHT'
        },
        PreviousAlert = {
            cmd = 'prvalert', 
            description = "Alerta anterior",
            key = 'LEFT'
        }
    },

    -- 🔥 SOLO POLICE
    CustomCommandAlert = {
        ["911"] = {
            jobCategory = "police",
        },
        ["panic"] = {
            jobCategory = "police",
        }
    },

    Translations = {
        ClosestAlert = "Ya estás en la alerta más cercana",
        AlertAsigned = "Alerta #%s asignada a %s",
        AssignedByDispatch = "Asignado por Dispatch",
        NoAlerts = "No hay alertas activas",
        AlertAccepted = "Alerta aceptada",
        AlertDeleted = "Alerta eliminada",
        CantSendEmpty = "No puedes enviar un mensaje vacío",
        Call911 = "LLAMADA 911"
    },

    -- Configuración de alertas
    DisplayPlateOnVehicleAlerts = true,
    RecieveAlwaysAlerts = false,
    DispatchRedirect = false,
    HeatMapAlerts = false,

    -- 🔥 SOLO POLICE
    JobCategory = {
        police = {
            { name = "police" }
        }
    }
}

Config.DispatchWeapons = {
    'weapon_pistol',
    'weapon_pistol_mk2',
    'weapon_combatpistol',
    'weapon_appistol',
    'weapon_pistol50',
    'weapon_snspistol',
    'weapon_heavypistol',
    'weapon_vintagepistol',
    'weapon_ceramicpistol',
    'weapon_revolver',
    'weapon_revolver_mk2',
    'weapon_microsmg',
    'weapon_smg',
    'weapon_smg_mk2',
    'weapon_assaultsmg',
    'weapon_combatpdw',
    'weapon_minismg',
    'weapon_carbinerifle',
    'weapon_assaultrifle',
    'weapon_specialcarbine',
    'weapon_bullpuprifle',
    'weapon_compactrifle',
    'weapon_marksmanrifle',
    'weapon_heavysniper',
    'weapon_pumpshotgun',
    'weapon_sawnoffshotgun',
    'weapon_autoshotgun',
    'weapon_bullpupshotgun',
    'weapon_combatshotgun'
}

-- === Config / Sistema de Cámaras ===
Config.Camara = {
    WebhookURL = "https://discord.com/api/webhooks/111w1d1wd11111111111", -- discord de ejemplo
    FilenamePrefix = "foto_evidencia",
    ResourceScreenshot = "screenshot-basic",
    
    -- Animación y prop
    AnimDict = "amb@world_human_paparazzi@male@base",
    AnimName = "base",
    PropName = "ch_prop_ch_camera_01",
    PropBone = 28422,
    PropOffset = {x = 0.0, y = 0.0, z = 0.0},
    PropRotation = {x = 0.0, y = 0.0, z = 0.0},
    
    -- Configuración de cámara
    CameraOffset = {x = 0.0, y = 0.8, z = 0.6}, -- Cámara más adelante
    CameraRotation = {x = 0.0, y = 0.0, z = 0.0},
    
    -- Configuración de zoom (CORREGIDO)
    ZoomMin = 20.0,   -- Campo de visión mínimo (más zoom - número más pequeño = más zoom)
    ZoomMax = 70.0,   -- Campo de visión máximo (menos zoom - número más grande = menos zoom)
    ZoomDefault = 50.0, -- Zoom por defecto
    ZoomStep = 2.0,   -- Incremento de zoom por scroll
    
    -- Controles
    ControlTomarFoto = 38, -- Tecla E
    ControlCancelar = 177, -- Tecla BACKSPACE
    
    -- Mensajes
    Mensajes = {
        UsandoCamara = "Usando cámara - [E] Tomar Foto | [RUEDA] Zoom | [BACKSPACE] Cancelar",
        FotoTomada = "¡Foto tomada! Revisa tu inventario.",
        SinCamara = "No tienes una cámara policial",
        Cancelado = "Modo cámara cancelado",
        ErrorAnim = "Error al cargar animación",
        NoEspacio = "No tienes espacio para más fotos",
        VerFoto = "Visualizando foto de evidencia"  -- 🔥 NUEVO MENSAJE

    }
}

-- === Config / Sistema de Análisis de Evidencias ===
Config.AnalisisEvidencias = {
    -- Props para análisis
    Props = {
        Huellas = {
            prop = "ch_prop_fingerprint_scanner_01a",
            coords = vector4(482.94, -986.01, 30.69, 47.44),
            heading = 90.0,
            label = "Analizar Huella Digital"
        },
        Sangre = {
            prop = "prop_chem_vial_02", 
            coords = vector4(484.5, -985.46, 30.69, 46.87),
            heading = 90.0,
            label = "Analizar Muestra de Sangre"
        },
        Casquillos = {
            prop = "v_ret_ml_scale",
            coords = vector3(487.13, -983.58, 30.68),
            heading = 90.0,
            label = "Analizar Casquillo de Bala"
        }
    },
    
    -- Mensajes
    Mensajes = {
        Analizando = "Analizando evidencia...",
        EvidenciaCreada = "Informe de evidencia creado",
        SinEvidencias = "No hay evidencias para analizar",
        Error = "Error al analizar la evidencia"
    }
}

-- Configuración de Dispatch
Config.Dispatch = {
    RespondKeybind = 'E', -- Tecla para responder a alertas
   -- OpenDispatchMenu = 'O', -- Tecla para abrir menú de dispatch
    AlertTime = 15, -- Tiempo que aparece la alerta en pantalla
    MaxCallList = 25, -- Máximo de llamadas en lista
    OnDutyOnly = true, -- Solo agentes en servicio ven alertas
    Jobs = {"police", "sheriff"}, -- Jobs que pueden ver alertas
    
    -- Comandos
    AlertCommandCooldown = 60, -- Cooldown para evitar spam
    
    -- Alertas automáticas
    DefaultAlertsDelay = 5,
    DefaultAlerts = {
        Speeding = true,
        Shooting = true,
        Autotheft = true,
        Melee = true,
        PlayerDowned = true,
        Explosion = true
    },
    
    -- Zonas
    MinOffset = 1,
    MaxOffset = 120,
    
    -- Blips configuración
    Blips = {
        ['911call'] = {
            radius = 0,
            --sprite = 480,
            --color = 1,
            --scale = 1.5,
            length = 2,
            sound = 'Lose_1st',
            sound2 = 'GTAO_FM_Events_Soundset',
            offset = false,
            flash = false
        },
        ['shooting'] = {
            radius = 0,
            --sprite = 110,
            --color = 1,
            --scale = 1.5,
            length = 2,
            sound = 'Lose_1st',
            sound2 = 'GTAO_FM_Events_Soundset',
            offset = false,
            flash = false
        },
        ['carjacking'] = {
        radius = 0,
        --sprite = 225,
        --color = 1, 
        --scale = 1.5,
        length = 2,
        sound = 'Lose_1st',
        sound2 = 'GTAO_FM_Events_Soundset',
        offset = false,
        flash = false
    },
    ['drugs'] = {
        radius = 0,
        --sprite = 514,  -- Sprite para drogas
        --color = 6,     -- Color morado
        --scale = 1.5,
        length = 2,
        sound = 'Lose_1st',
        sound2 = 'GTAO_FM_Events_Soundset', 
        offset = false,
        flash = false
    },
['vehicletheft'] = {
    radius = 0,
    --sprite = 225,
    --color = 5,
    --scale = 1.5,
    length = 2,
    sound = 'Lose_1st',
    sound2 = 'GTAO_FM_Events_Soundset',
    offset = false,
    flash = false
},
        ['officerdown'] = {
            radius = 15.0,
            sprite = 526,
            color = 1,
            scale = 1.5,
            length = 2,
            sound = 'panicbutton',
            offset = false,
            flash = true
        }
    }
}

Config.CarjackingAlert = {
    Cooldown = 3000, -- Tiempo entre alertas en milisegundos (30000 = 30 segundos)
}

Config.VehicleTheft = {
    AlertChance = 60,       -- % de probabilidad de alerta
    DetectRadius = 3.0,     -- metros para detectar vehículo
    AlertCooldown = 2500,  -- ms entre alertas
}

-- 🔫 SISTEMA DE DETECCIÓN DE DISPAROS
Config.ShootingAlerts = {
    enabled = true,
    cooldown = 30000, -- 30 segundos en milisegundos
    alertTime = 15, -- Tiempo que aparece la alerta en pantalla
    
    -- Armas que NO generan alerta (whitelist)
    WeaponWhitelist = {
        'WEAPON_STUNGUN',
        'WEAPON_SNOWBALL', 
        'WEAPON_BALL',
        'WEAPON_FLARE',
        'WEAPON_FLAREGUN',
        'WEAPON_FIREEXTINGUISHER',
        'WEAPON_PETROLCAN',
        'WEAPON_HAZARDCAN',
        'WEAPON_SMOKEGRENADE',
        'WEAPON_BZGAS'
    },
    
    -- Armas que SÍ generan alerta (basado en tu lista)
    WeaponBlacklist = {
        -- Pistolas
        'WEAPON_PISTOL',
        'WEAPON_PISTOL_MK2',
        'WEAPON_COMBATPISTOL',
        'WEAPON_APPISTOL',
        'WEAPON_PISTOL50',
        'WEAPON_SNSPISTOL',
        'WEAPON_HEAVYPISTOL',
        'WEAPON_VINTAGEPISTOL',
        'WEAPON_MARKSMANPISTOL',
        'WEAPON_REVOLVER',
        'WEAPON_REVOLVER_MK2',
        'WEAPON_DOUBLEACTION',
        'WEAPON_SNSPISTOL_MK2',
        'WEAPON_RAYPISTOL',
        'WEAPON_CERAMICPISTOL',
        'WEAPON_NAVYREVOLVER',
        'WEAPON_GADGETPISTOL',
        'WEAPON_PISTOLXM3',
        
        -- Subfusiles
        'WEAPON_MICROSMG',
        'WEAPON_SMG',
        'WEAPON_SMG_MK2',
        'WEAPON_ASSAULTSMG',
        'WEAPON_COMBATPDW',
        'WEAPON_MACHINEPISTOL',
        'WEAPON_MINISMG',
        'WEAPON_RAYCARBINE',
        
        -- Escopetas
        'WEAPON_PUMPSHOTGUN',
        'WEAPON_SAWNOFFSHOTGUN',
        'WEAPON_ASSAULTSHOTGUN',
        'WEAPON_BULLPUPSHOTGUN',
        'WEAPON_MUSKET',
        'WEAPON_HEAVYSHOTGUN',
        'WEAPON_DBSHOTGUN',
        'WEAPON_AUTOSHOTGUN',
        'WEAPON_PUMPSHOTGUN_MK2',
        'WEAPON_COMBATSHOTGUN',
        
        -- Rifles de asalto
        'WEAPON_ASSAULTRIFLE',
        'WEAPON_ASSAULTRIFLE_MK2',
        'WEAPON_CARBINERIFLE',
        'WEAPON_CARBINERIFLE_MK2',
        'WEAPON_ADVANCEDRIFLE',
        'WEAPON_SPECIALCARBINE',
        'WEAPON_BULLPUPRIFFLE',
        'WEAPON_COMPACTRIFLE',
        'WEAPON_SPECIALCARBINE_MK2',
        'WEAPON_BULLPUPRIFFLE_MK2',
        'WEAPON_MILITARYRIFLE',
        
        -- Ametralladoras
        'WEAPON_MG',
        'WEAPON_COMBATMG',
        'WEAPON_GUSENBERG',
        'WEAPON_COMBATMG_MK2',
        
        -- Rifles de francotirador
        'WEAPON_SNIPERRIFLE',
        'WEAPON_HEAVYSNIPER',
        'WEAPON_MARKSMANRIFLE',
        'WEAPON_REMOTESNIPER',
        'WEAPON_HEAVYSNIPER_MK2',
        'WEAPON_MARKSMANRIFLE_MK2',
        
        -- Armas pesadas
        'WEAPON_RPG',
        'WEAPON_GRENADELAUNCHER',
        'WEAPON_GRENADELAUNCHER_SMOKE',
        'WEAPON_MINIGUN',
        'WEAPON_FIREWORK',
        'WEAPON_RAILGUN',
        'WEAPON_RAILGUNXM3',
        'WEAPON_HOMINGLAUNCHER',
        'WEAPON_COMPACTLAUNCHER',
        'WEAPON_RAYMINIGUN'
    },
    
    -- Configuración de blips para disparos
    -- BlipConfig = {
    --     sprite = 432,
    --     color = 1,
    --     scale = 1.2,
    --     flash = true,
    --     length = 2 -- minutos
    -- }
}

-- 🔫 SISTEMA DE DETECCIÓN DE CARJACKING
Config.CarjackingWeapons = {
    'WEAPON_PISTOL',
    'WEAPON_PISTOL_MK2',
    'WEAPON_COMBATPISTOL',
    'WEAPON_APPISTOL',
    'WEAPON_PISTOL50',
    'WEAPON_SNSPISTOL',
    'WEAPON_HEAVYPISTOL',
    'WEAPON_VINTAGEPISTOL',
    'WEAPON_MARKSMANPISTOL',
    'WEAPON_REVOLVER',
    'WEAPON_REVOLVER_MK2',
    'WEAPON_DOUBLEACTION',
    'WEAPON_SNSPISTOL_MK2',
    'WEAPON_RAYPISTOL',
    'WEAPON_CERAMICPISTOL',
    'WEAPON_NAVYREVOLVER',
    'WEAPON_GADGETPISTOL',
    'WEAPON_PISTOLXM3',
    
    -- Subfusiles
    'WEAPON_MICROSMG',
    'WEAPON_SMG',
    'WEAPON_SMG_MK2',
    'WEAPON_ASSAULTSMG',
    'WEAPON_COMBATPDW',
    'WEAPON_MACHINEPISTOL',
    'WEAPON_MINISMG',
    'WEAPON_RAYCARBINE',
    
    -- Escopetas
    'WEAPON_PUMPSHOTGUN',
    'WEAPON_SAWNOFFSHOTGUN',
    'WEAPON_ASSAULTSHOTGUN',
    'WEAPON_BULLPUPSHOTGUN',
    'WEAPON_MUSKET',
    'WEAPON_HEAVYSHOTGUN',
    'WEAPON_DBSHOTGUN',
    'WEAPON_AUTOSHOTGUN',
    'WEAPON_PUMPSHOTGUN_MK2',
    'WEAPON_COMBATSHOTGUN',
    
    -- Rifles de asalto
    'WEAPON_ASSAULTRIFLE',
    'WEAPON_ASSAULTRIFLE_MK2',
    'WEAPON_CARBINERIFLE',
    'WEAPON_CARBINERIFLE_MK2',
    'WEAPON_ADVANCEDRIFLE',
    'WEAPON_SPECIALCARBINE',
    'WEAPON_BULLPUPRIFFLE',
    'WEAPON_COMPACTRIFLE',
    'WEAPON_SPECIALCARBINE_MK2',
    'WEAPON_BULLPUPRIFFLE_MK2',
    'WEAPON_MILITARYRIFLE',
    
    -- Ametralladoras
    'WEAPON_MG',
    'WEAPON_COMBATMG',
    'WEAPON_GUSENBERG',
    'WEAPON_COMBATMG_MK2',
    
    -- Rifles de francotirador
    'WEAPON_SNIPERRIFLE',
    'WEAPON_HEAVYSNIPER',
    'WEAPON_MARKSMANRIFLE',
    'WEAPON_REMOTESNIPER',
    'WEAPON_HEAVYSNIPER_MK2',
    'WEAPON_MARKSMANRIFLE_MK2',
    
    -- Armas pesadas
    'WEAPON_RPG',
    'WEAPON_GRENADELAUNCHER',
    'WEAPON_GRENADELAUNCHER_SMOKE',
    'WEAPON_MINIGUN',
    'WEAPON_FIREWORK',
    'WEAPON_RAILGUN',
    'WEAPON_RAILGUNXM3',
    'WEAPON_HOMINGLAUNCHER',
    'WEAPON_COMPACTLAUNCHER',
    'WEAPON_RAYMINIGUN'
}

-- Config específico para detección de venta de drogas desde sh-mdt (independiente de qb-drugs)
Config.DrugsDetect = {
    SuccessChance = 60,
    ScamChance = 25,
    RobberyChance = 15,
    --MinimumDrugSalePolice = 2, -- si querés que requiera X policías online para permitir venta

    PoliceCallChance = 70, -- probabilidad (%) de que se llame a policía al vender (ajustable)

    -- Precios/inventario (solo referencia para lógica local)
    DrugsPrice = {
        ['weed_whitewidow'] = { min = 15, max = 24 },
        ['weed_ogkush']      = { min = 15, max = 28 },
        ['weed_skunk']       = { min = 15, max = 31 },
        ['weed_amnesia']     = { min = 18, max = 34 },
        ['weed_purplehaze']  = { min = 18, max = 37 },
        ['weed_ak47']        = { min = 18, max = 40 },
        ['crack_baggy']      = { min = 18, max = 34 },
        ['cokebaggy']        = { min = 18, max = 37 },
        ['meth']             = { min = 18, max = 40 },
    },

    -- Opciones para detección local
    DetectRadius = 3.0,          -- distancia mínima para considerar que un NPC está "vendiendo"
    AnimDetect = true,           -- detectar por animación (gesture_point)
    EventListen = true,          -- también escucha 'qb-drugs:client:sellCornerDrugs' si existe
    DebounceMs = 1000            -- evitar duplicados por breve periodo
}
