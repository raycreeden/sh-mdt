local QBCore = exports['qb-core']:GetCoreObject()

-- Función mejorada para formatear fecha
local function formatFecha(fechaStr)
    if not fechaStr then
        return "Sin fecha"
    end
    
    -- Convertir a string si es número o otro tipo
    local fechaString = tostring(fechaStr)
    
    -- 🔥 NUEVO: Si es un timestamp de Unix (número grande como 1760231512000.0)
    local timestamp = tonumber(fechaString)
    if timestamp and timestamp > 1000000000000 then -- Mayor a 1 billón (timestamp en milisegundos)
        -- Convertir timestamp de milisegundos a segundos
        local tiempoSegundos = timestamp / 1000
        -- Usar os.date para formatear
        local fechaFormateada = os.date("%d/%m/%Y %H:%M", tiempoSegundos)
        return fechaFormateada
    end
    
    -- Diferentes patrones para diferentes formatos de fecha
    -- Patrón 1: "2024-12-15 14:30:25" (MySQL timestamp)
    local anio, mes, dia, hora, minuto = fechaString:match("(%d+)-(%d+)-(%d+) (%d+):(%d+):(%d+)")
    if anio and mes and dia then
        local resultado = dia .. "/" .. mes .. "/" .. anio .. " " .. hora .. ":" .. minuto
        return resultado
    end
    
    -- Patrón 2: "2024-12-15T14:30:25Z" (formato ISO)
    anio, mes, dia, hora, minuto = fechaString:match("(%d+)-(%d+)-(%d+)T(%d+):(%d+):(%d+)")
    if anio and mes and dia then
        local resultado = dia .. "/" .. mes .. "/" .. anio .. " " .. hora .. ":" .. minuto
        return resultado
    end
    
    -- Patrón 3: Solo fecha "2024-12-15"
    anio, mes, dia = fechaString:match("(%d+)-(%d+)-(%d+)")
    if anio and mes and dia then
        local resultado = dia .. "/" .. mes .. "/" .. anio
        return resultado
    end
    
    -- Si no coincide ningún patrón, devolver el original
    return fechaString
end

-- Registrar entrada/salida de servicio
local citizenCache = {}

RegisterNetEvent('sh-mdt:server:registrarServicio', function(accion)
    local src = source
    local player = QBCore.Functions.GetPlayer(src)
    if not player or player.PlayerData.job.name ~= 'police' then return end

    local citizenid = player.PlayerData.citizenid
    local nombre = player.PlayerData.charinfo.firstname or "Nombre"
    local apellido = player.PlayerData.charinfo.lastname or "Apellido"

    -- ✅ Usar caché
    local ciudadanoId = citizenCache[citizenid]
    if not ciudadanoId then
        local ciudadano = MySQL.single.await("SELECT id FROM sh_mdt_ciudadanos WHERE identifier = ?", { citizenid })
        if ciudadano then
            ciudadanoId = ciudadano.id
            citizenCache[citizenid] = ciudadano.id
        else
            return
        end
    end

    local estado = (accion == 'entrar') and 'Inicio de servicio' or 'Salida de servicio'
    MySQL.insert.await("INSERT INTO sh_mdt_tiempos (ciudadano_id, servicio, estado) VALUES (?, 'SERVICIO', ?)", { ciudadanoId, estado })
end)

-- CALLBACK SIMPLIFICADO (sin debug excesivo)

QBCore.Functions.CreateCallback('sh-mdt:tiempo:getOficiales', function(source, cb)
    local resultados = MySQL.query.await([[
        SELECT 
            t.fecha_inicio,
            t.estado,
            c.nombre,
            c.apellido
        FROM sh_mdt_tiempos t
        LEFT JOIN sh_mdt_ciudadanos c ON c.id = t.ciudadano_id
        ORDER BY t.fecha_inicio DESC
        LIMIT 50
    ]])

    local registros = {}

    if resultados and #resultados > 0 then
        for i, row in ipairs(resultados) do
            -- Usar la función de formateo mejorada
            local fechaFormateada = formatFecha(row.fecha_inicio)
            local nombreCompleto = (row.nombre or "Nombre") .. " " .. (row.apellido or "Apellido")
            local estado = row.estado or "Servicio"
            
            table.insert(registros, {
                texto = nombreCompleto .. " - " .. estado .. " - " .. fechaFormateada,
                nombre = nombreCompleto,
                estado = estado,
                fecha = fechaFormateada
            })
        end
    end
    cb(registros)
end)
