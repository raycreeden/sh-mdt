local QBCore = exports['qb-core']:GetCoreObject()

-------------------------------------
-- 📘 CRUD del Código Penal
-------------------------------------

QBCore.Functions.CreateCallback('codigo_penal:getArticles', function(source, cb)
    local res = MySQL.query.await('SELECT * FROM codigo_penal ORDER BY id ASC')
    cb(res or {})
end)

RegisterNetEvent('codigo_penal:createArticle', function(data)
    local xPlayer = QBCore.Functions.GetPlayer(source)
    if not xPlayer then return end
    if not data.codigo or not data.descripcion or not data.monto then return end
    MySQL.insert.await('INSERT INTO codigo_penal (codigo, descripcion, monto) VALUES (?, ?, ?)', {
        data.codigo, data.descripcion, tonumber(data.monto)
    })
    TriggerClientEvent('codigo_penal:syncArticles', source, MySQL.query.await('SELECT * FROM codigo_penal'))
end)

RegisterNetEvent('codigo_penal:deleteArticle', function(id)
    MySQL.update.await('DELETE FROM codigo_penal WHERE id = ?', { tonumber(id) })
    TriggerClientEvent('codigo_penal:syncArticles', source, MySQL.query.await('SELECT * FROM codigo_penal'))
end)

QBCore.Functions.CreateCallback('codigo_penal:getAll', function(source, cb)
    local res = MySQL.query.await('SELECT * FROM codigo_penal ORDER BY codigo ASC')
    cb(res or {})
end)

-------------------------------------
-- 🧾 MULTAS - PERSISTENCIA REAL
-------------------------------------

RegisterNetEvent('codigo_penal:server:aplicarMulta', function(ciudadanoId, codigo, descripcion, monto)
    local src = source
    local officer = QBCore.Functions.GetPlayer(src)
    if not officer then return end

    local ciudadano = MySQL.single.await('SELECT identifier FROM sh_mdt_ciudadanos WHERE id = ?', { ciudadanoId })
    if not ciudadano or not ciudadano.identifier then return end

    local citizenid = ciudadano.identifier
    local razon = ('Multa: %s'):format(descripcion) -- 🔹 igual que ciudadanos

    -- Insertar multa como IMPAGA
    MySQL.insert.await([[
        INSERT INTO sh_mdt_cargos (ciudadano_id, articulo_codigo, descripcion, estado, monto)
        VALUES (?, ?, ?, 'Impago', ?)
    ]], { ciudadanoId, codigo, descripcion, monto })

    local target = QBCore.Functions.GetPlayerByCitizenId(citizenid)
    if target then
        -- Si el ciudadano está online, crear factura normal
        TriggerClientEvent('codigo_penal:emitirFacturaRelay', src, target.PlayerData.source, razon, monto)
    else
        -- Si está offline, guardar la factura directamente
        MySQL.insert.await([[
            INSERT INTO player_facturas (receiver_citizenid, sender_citizenid, razon, valor)
            VALUES (?, ?, ?, ?)
        ]], { citizenid, officer.PlayerData.citizenid, razon, monto })
    end

    TriggerClientEvent('ciudadanos:syncMultas', src, ciudadanoId)
end)

-------------------------------------
-- ♻️ CARGA PERSISTENTE (REPLICA DE CIUDADANOS)
-------------------------------------

QBCore.Functions.CreateCallback('codigo_penal:getMultasCiudadano', function(source, cb, ciudadanoId)
    if not ciudadanoId then return cb({}) end

    -- Obtener identifier del ciudadano
    local ciudadano = MySQL.single.await('SELECT identifier FROM sh_mdt_ciudadanos WHERE id = ?', { ciudadanoId })
    if not ciudadano or not ciudadano.identifier then return cb({}) end

    -- Obtener todas las multas del ciudadano
    local multas = MySQL.query.await('SELECT id, articulo_codigo, descripcion, estado, monto, fecha FROM sh_mdt_cargos WHERE ciudadano_id = ?', { ciudadanoId }) or {}

    -- 🔁 Recalcular estado según existencia de factura
    for _, multa in ipairs(multas) do
        local razonBuscada = "Multa: " .. multa.descripcion
        local tieneFactura = MySQL.scalar.await([[
            SELECT COUNT(*) FROM player_facturas
            WHERE receiver_citizenid = ? AND razon = ?
        ]], { ciudadano.identifier, razonBuscada })

        if tieneFactura > 0 then
            MySQL.update('UPDATE sh_mdt_cargos SET estado = "Impago" WHERE id = ?', { multa.id })
            multa.estado = "Impago"
        else
            MySQL.update('UPDATE sh_mdt_cargos SET estado = "Pagado" WHERE id = ?', { multa.id })
            multa.estado = "Pagado"
        end
    end

    cb(multas)
end)

-------------------------------------
-- 🔁 SINCRONIZACIÓN CON sh-facturas
-------------------------------------

-- Cuando se paga una factura, marcar multa como pagada
AddEventHandler('sh-facturas:server:pagarFactura', function(id)
    local factura = MySQL.single.await('SELECT razon, receiver_citizenid FROM player_facturas WHERE id = ?', { id })
    if not factura then return end

    local razon = factura.razon or ''
    local cid = factura.receiver_citizenid
    if not cid then return end

    local ciudadano = MySQL.single.await('SELECT id FROM sh_mdt_ciudadanos WHERE identifier = ?', { cid })
    if not ciudadano or not ciudadano.id then return end

    MySQL.update.await([[
        UPDATE sh_mdt_cargos
        SET estado = 'Pagado'
        WHERE ciudadano_id = ? AND descripcion LIKE ?
    ]], { ciudadano.id, "%" .. razon .. "%" })
end)
