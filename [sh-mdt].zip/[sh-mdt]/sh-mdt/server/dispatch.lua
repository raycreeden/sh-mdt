local QBCore = exports['qb-core']:GetCoreObject()
local activeAlerts = {}
local alertId = 0

-- Función para generar ID único
function GenerateAlertId()
    alertId = alertId + 1
    return alertId
end

-- Evento para enviar alerta
RegisterServerEvent('sh-mdt:server:sendAlert')
AddEventHandler('sh-mdt:server:sendAlert', function(alertData)
    local src = source
    local player = QBCore.Functions.GetPlayer(src)
    
    if not player then return end
    
    -- Agregar información del remitente si no existe
    if not alertData.name then
        alertData.name = player.PlayerData.charinfo.firstname .. " " .. player.PlayerData.charinfo.lastname
    end
    
    if not alertData.number then
        alertData.number = player.PlayerData.charinfo.phone
    end
    
    -- Generar ID y timestamp
    alertData.id = GenerateAlertId()
    alertData.time = os.time()
    
    -- Agregar a alertas activas
    activeAlerts[alertData.id] = alertData
    
    -- Enviar a todos los jugadores policías
    for _, v in pairs(QBCore.Functions.GetPlayers()) do
        local player = QBCore.Functions.GetPlayer(v)
        if player and (player.PlayerData.job.name == 'police' or player.PlayerData.job.name == 'sheriff') then
            if not Config.Dispatch.OnDutyOnly or player.PlayerData.job.onduty then
                TriggerClientEvent('sh-mdt:client:showAlert', v, alertData)
            end
        end
    end
    
    -- Remover alerta después de 10 minutos
    SetTimeout(600000, function()
        activeAlerts[alertData.id] = nil
    end)
end)

-- Evento para obtener alertas activas
RegisterServerEvent('sh-mdt:server:getActiveAlerts')
AddEventHandler('sh-mdt:server:getActiveAlerts', function()
    local src = source
    local player = QBCore.Functions.GetPlayer(src)
    
    if player and (player.PlayerData.job.name == 'police' or player.PlayerData.job.name == 'sheriff') then
        -- Convertir tabla a array para enviar
        local alertsArray = {}
        for _, alert in pairs(activeAlerts) do
            table.insert(alertsArray, alert)
        end
        
        TriggerClientEvent('sh-mdt:client:showAlertList', src, alertsArray)
    end
end)

-- Evento para setFocus
RegisterServerEvent('sh-mdt:setFocus')
AddEventHandler('sh-mdt:setFocus', function(data)
    local src = source
    TriggerClientEvent('sh-mdt:client:setFocus', src, data.focus)
end)

-- ======================================================
-- 🔫 SISTEMA DE DETECCIÓN DE DISPAROS (SERVIDOR)
-- ======================================================

-- Evento para recibir alertas de disparos y enviar a todos los policías
RegisterServerEvent('sh-mdt:server:sendShootingAlert')
AddEventHandler('sh-mdt:server:sendShootingAlert', function(alertData)
    -- Generar ID único para la alerta
    alertData.id = GenerateAlertId()
    alertData.time = os.time()
    
    -- Enviar a todos los jugadores policías
    for _, v in pairs(QBCore.Functions.GetPlayers()) do
        local player = QBCore.Functions.GetPlayer(v)
        if player and (player.PlayerData.job.name == 'police' or player.PlayerData.job.name == 'sheriff') then
            if not Config.Dispatch.OnDutyOnly or player.PlayerData.job.onduty then
                TriggerClientEvent('sh-mdt:client:showShootingAlert', v, alertData)
            end
        end
    end
end)

-- ======================================================
-- 🔫 DETECCIÓN DE DISPAROS - SERVIDOR
-- ======================================================

-- Evento para cuando un jugador dispara
RegisterServerEvent('sh-mdt:server:playerShotWeapon')
AddEventHandler('sh-mdt:server:playerShotWeapon', function(coords, streetName, weaponHash)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if not Player then return end
    
    -- Crear alerta de disparos
    local alertData = {
        message = "🔫 DISPAROS DETECTADOS",
        codeName = 'shooting',
        code = 'DISPARO',
        priority = 2,
        coords = coords,
        street = streetName or "Ubicación desconocida",
        information = "Disparos Detectados En...",
        name = "Sistema de Detección",
        number = "AUTO",
        time = os.time()
    }
    
    -- 🔥 AGREGAR A ALERTAS ACTIVAS (PARA EL PANEL GRANDE)
    alertData.id = GenerateAlertId()
    activeAlerts[alertData.id] = alertData
    
    -- 🔥 ENVIAR ALERTA A TODOS LOS POLICÍAS (igual que /911)
    for _, v in pairs(QBCore.Functions.GetPlayers()) do
        local player = QBCore.Functions.GetPlayer(v)
        if player and (player.PlayerData.job.name == 'police' or player.PlayerData.job.name == 'sheriff') then
            if not Config.Dispatch.OnDutyOnly or player.PlayerData.job.onduty then
                TriggerClientEvent('sh-mdt:client:showAlert', v, alertData)
            end
        end
    end
    
    -- 🔥 REMOVER DESPUÉS DE 10 MINUTOS (IGUAL QUE /911)
    SetTimeout(600000, function()
        activeAlerts[alertData.id] = nil
    end)
end)

-- ======================================================
-- 🚗 SISTEMA DE ALERTA DE CARJACKING (con cooldown configurable)
-- ======================================================

local lastCarjackAlert = {}

RegisterServerEvent('sh-mdt:server:carjackAlert')
AddEventHandler('sh-mdt:server:carjackAlert', function(coords, streetName, plate, vehicleLabel)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    local currentTime = os.time()
    local identifier = Player.PlayerData.citizenid or src

    -- 🔒 Evitar spam por cooldown
    if lastCarjackAlert[identifier] and currentTime - lastCarjackAlert[identifier] < (Config.CarjackingAlert.Cooldown / 1000) then
        return
    end
    lastCarjackAlert[identifier] = currentTime

    -- 🔥 CONSTRUIR MENSAJE CON INFORMACIÓN COMPLETA
    local information = "Se acaba de robar un vehículo a un Civil\n"
    information = information .. "📋 Matrícula: " .. (plate or "DESCONOCIDA") .. "\n"
    information = information .. "🚗 Vehículo: " .. (vehicleLabel or "DESCONOCIDO") .. "\n"

    local alertData = {
        message = "🚗 ROBO DE VEHÍCULO",
        codeName = 'carjacking',
        code = 'Robo de Vehículo',
        priority = 2,
        coords = coords,
        street = streetName,
        information = information,
        name = "Sistema de Seguridad",
        number = "AUTO",
        time = os.time()
    }

    alertData.id = GenerateAlertId()
    activeAlerts[alertData.id] = alertData

    -- 🔊 Enviar alerta a policías y sheriffs
    for _, v in pairs(QBCore.Functions.GetPlayers()) do
        local player = QBCore.Functions.GetPlayer(v)
        if player and (player.PlayerData.job.name == 'police' or player.PlayerData.job.name == 'sheriff') then
            if not Config.Dispatch.OnDutyOnly or player.PlayerData.job.onduty then
                TriggerClientEvent('sh-mdt:client:showAlert', v, alertData)
            end
        end
    end

    -- Expira después de 10 minutos
    SetTimeout(600000, function()
        activeAlerts[alertData.id] = nil
    end)

    print(string.format(
        "[DISPATCH] 🚨 Robo de vehículo detectado: %s (%s) en %s",
        vehicleLabel or "Desconocido",
        plate or "Sin matrícula",
        streetName or "Ubicación desconocida"
    ))
end)

-- ======================================================
-- 💊 SISTEMA DE ALERTA POR VENTA DE DROGAS (INTEGRADO)
-- ======================================================

RegisterServerEvent('sh-mdt:server:reportDrugSale')
AddEventHandler('sh-mdt:server:reportDrugSale', function(alertData)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    -- Probabilidad extra de que llegue a la policía (seguridad adicional)
    if math.random(100) > (Config.DrugsDetect.PoliceCallChance or 30) then
        return
    end

    -- Verificar cantidad mínima de policías
    local minPolice = Config.DrugsDetect.MinimumDrugSalePolice or 0
    if minPolice > 0 then
        local cops = 0
        for _, pid in pairs(QBCore.Functions.GetPlayers()) do
            local p = QBCore.Functions.GetPlayer(pid)
            if p and (p.PlayerData.job.name == 'police' or p.PlayerData.job.name == 'sheriff') then
                if not Config.Dispatch.OnDutyOnly or p.PlayerData.job.onduty then
                    cops = cops + 1
                end
            end
        end
        if cops < minPolice then return end
    end

    -- Completar información
    alertData.name = Player.PlayerData.charinfo.firstname .. " " .. Player.PlayerData.charinfo.lastname
    alertData.number = Player.PlayerData.charinfo.phone
    alertData.id = GenerateAlertId()
    alertData.time = os.time()
    alertData.message = "💊 Venta de drogas en progreso"
    alertData.codeName = 'drugs'
    alertData.code = 'Venta de Droga'
    alertData.priority = 2
    alertData.information = "Se detectó una posible venta de drogas a un ciudadano."
    
    activeAlerts[alertData.id] = alertData

    -- Enviar a policías
    for _, pid in pairs(QBCore.Functions.GetPlayers()) do
        local p = QBCore.Functions.GetPlayer(pid)
        if p and (p.PlayerData.job.name == 'police' or p.PlayerData.job.name == 'sheriff') then
            if not Config.Dispatch.OnDutyOnly or p.PlayerData.job.onduty then
                TriggerClientEvent('sh-mdt:client:showAlert', pid, alertData)
            end
        end
    end

    SetTimeout(600000, function()
        activeAlerts[alertData.id] = nil
    end)
end)

-- Intento de robo de vehiculo ---
----------------------------------
----------------------------------
RegisterServerEvent('sh-mdt:server:vehicleTheftAlert')
AddEventHandler('sh-mdt:server:vehicleTheftAlert', function(coords, streetName, plate, vehicleLabel)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    local info = "Intento de robo de vehículo estacionado\n"
    info = info .. "📋 Matrícula: " .. (plate or "DESCONOCIDA") .. "\n"
    info = info .. "🚗 Vehículo: " .. (vehicleLabel or "DESCONOCIDO") .. "\n"

    local alertData = {
        message = "🚗 INTENTO DE ROBO DE VEHÍCULO",
        codeName = 'vehicletheft',
        code = 'Intento de Robo de Vehiculo',
        priority = 2,
        coords = coords,
        street = streetName,
        information = info,
        name = Player.PlayerData.charinfo and (Player.PlayerData.charinfo.firstname .. " " .. Player.PlayerData.charinfo.lastname) or "Desconocido",
        number = "LOCKPICK",
        time = os.time()
    }

    alertData.id = GenerateAlertId()
    activeAlerts[alertData.id] = alertData

    for _, v in pairs(QBCore.Functions.GetPlayers()) do
        local p = QBCore.Functions.GetPlayer(v)
        if p and (p.PlayerData.job.name == 'police' or p.PlayerData.job.name == 'sheriff') then
            if not Config.Dispatch.OnDutyOnly or p.PlayerData.job.onduty then
                TriggerClientEvent('sh-mdt:client:showAlert', v, alertData)
            end
        end
    end

    SetTimeout(600000, function()
        activeAlerts[alertData.id] = nil
    end)
end)

-- Hook del evento lockpick roto (se ejecuta en qb-vehiclekeys)
RegisterNetEvent('qb-vehiclekeys:server:breakLockpick', function(itemName)
    local src = source
    if itemName == 'lockpick' or itemName == 'advancedlockpick' then
        TriggerClientEvent('dispatch:client:LockpickBroken', src)
    end
end)

-- ======================================================
-- 💬 CHAT POLICIAL DESDE MDT
-- ======================================================

RegisterServerEvent('sh-mdt:server:sendPoliceChat')
AddEventHandler('sh-mdt:server:sendPoliceChat', function(msg)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player or Player.PlayerData.job.name ~= "police" or not Player.PlayerData.job.onduty then
        TriggerClientEvent("QBCore:Notify", src, "Debes estar en servicio policial.", "error")
        return
    end
    if not msg or msg == "" then return end

    -- Obtener nombre, apellido y grado
    local firstname = Player.PlayerData.charinfo.firstname or "Nombre"
    local lastname = Player.PlayerData.charinfo.lastname or "Apellido"
    local grade = Player.PlayerData.job.grade.label or Player.PlayerData.job.grade.name or "Rango"

    local finalMsg = ("[%s %s - %s]: %s"):format(firstname, lastname, grade, msg)

    -- Enviar a todos los policías activos
    for _, v in pairs(QBCore.Functions.GetPlayers()) do
        local target = QBCore.Functions.GetPlayer(v)
        if target and target.PlayerData.job.name == "police" and target.PlayerData.job.onduty then
            TriggerClientEvent("sh-mdt:client:receivePoliceChat", target.PlayerData.source, finalMsg)
        end
    end
end)

-- ======================================================
-- 🔹 Sincronizar chat desde otros recursos (como sh-radio)
-- ======================================================

