local QBCore = exports['qb-core']:GetCoreObject()

-- Buscar armas por serial
QBCore.Functions.CreateCallback('sh-mdt:server:buscarArmaSerial', function(source, cb, query)
    if not query or query == '' then return cb({}) end
    local q = '%' .. query .. '%'

    -- 🔄 Trae las armas y su estado robada desde la nueva tabla sh_mdt_armarob
    local result = MySQL.query.await([[
        SELECT 
            a.serial,
            a.tipo_arma AS weapon,
            c.nombre AS firstname,
            c.apellido AS lastname,
            IFNULL(r.robada, 0) AS robada
        FROM sh_mdt_armas a
        LEFT JOIN sh_mdt_ciudadanos c ON c.id = a.ciudadano_id
        LEFT JOIN sh_mdt_armarob r ON r.serial = a.serial
        WHERE a.serial LIKE ?
        LIMIT 50
    ]], { q }) or {}

    cb(result)
end)

-- Obtener dueño por serial
QBCore.Functions.CreateCallback('sh-mdt:server:getArmaOwner', function(source, cb, serial)
    if not serial then return cb({}) end

    -- 🔄 Buscamos también si está marcada como robada
    local arma = MySQL.single.await([[
        SELECT 
            a.serial,
            a.tipo_arma AS weapon,
            c.nombre,
            c.apellido,
            c.id AS ciudadano_id,
            IFNULL(r.robada, 0) AS robada
        FROM sh_mdt_armas a
        LEFT JOIN sh_mdt_ciudadanos c ON c.id = a.ciudadano_id
        LEFT JOIN sh_mdt_armarob r ON r.serial = a.serial
        WHERE a.serial = ? LIMIT 1
    ]], { serial })

    if not arma then
        return cb({ found = false, serial = serial })
    end

    cb({
        found = true,
        serial = arma.serial,
        weapon = arma.weapon or 'Desconocida',
        nombre = arma.nombre or 'Desconocido',
        apellido = arma.apellido or '',
        ciudadano_id = arma.ciudadano_id,
        robada = arma.robada == 1
    })
end)

-- Cambiar estado robada (y persistirlo en la nueva tabla)
RegisterNetEvent('sh-mdt:server:setArmaRobada', function(serial, robada)
    if not serial then return end
    local src = source
    local r = robada and 1 or 0

    -- 🧩 Insertar o actualizar el estado robada en la nueva tabla
    MySQL.insert.await([[
        INSERT INTO sh_mdt_armarob (serial, robada)
        VALUES (?, ?)
        ON DUPLICATE KEY UPDATE robada = VALUES(robada)
    ]], { serial, r })

    TriggerClientEvent('sh-mdt:client:notifyRegistroArma', src,
        ('Estado actualizado: %s → %s'):format(serial, r == 1 and 'Robada' or 'No robada'),
        'success'
    )
end)
