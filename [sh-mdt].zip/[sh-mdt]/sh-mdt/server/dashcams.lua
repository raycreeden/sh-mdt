local QBCore = exports['qb-core']:GetCoreObject()

-- Callback para obtener oficiales en servicio
QBCore.Functions.CreateCallback('sh-mdt:server:getOficialesDashcams', function(source, cb)
    local players = QBCore.Functions.GetPlayers()
    local oficiales = {}
    
    for i = 1, #players do
        local playerId = players[i]
        local player = QBCore.Functions.GetPlayer(playerId)
        
        if player then
            -- Verificar si es policía y está en servicio
            if player.PlayerData.job.name == 'police' and player.PlayerData.job.onduty then
                -- No incluir al propio jugador que está viendo
                if playerId ~= source then
                    -- 🔥 OBTENER BADGE NUMBER de metadata
                    local badgeNumber = player.PlayerData.metadata["badge_number"] or "000"
                    
                    table.insert(oficiales, {
                        serverId = playerId,
                        name = player.PlayerData.charinfo.firstname .. " " .. player.PlayerData.charinfo.lastname,
                        grade = player.PlayerData.job.grade.level,
                        callsign = badgeNumber, -- 🔥 USAR BADGE NUMBER
                        gradeName = player.PlayerData.job.grade.name
                    })
                end
            end
        end
    end
    
    cb(oficiales)
end)

-- Callback para obtener nombre del jugador
QBCore.Functions.CreateCallback('sh-mdt:server:getPlayerName', function(source, cb, targetServerId)
    local player = QBCore.Functions.GetPlayer(tonumber(targetServerId))
    
    if player then
        local name = player.PlayerData.charinfo.firstname .. " " .. player.PlayerData.charinfo.lastname
        cb(name)
    else
        cb("Desconocido")
    end
end)

-- Logs de quién ve a quién (opcional)
RegisterNetEvent('sh-mdt:server:logDashcamView')
AddEventHandler('sh-mdt:server:logDashcamView', function(targetServerId, action)
    local src = source
    local player = QBCore.Functions.GetPlayer(src)
    local target = QBCore.Functions.GetPlayer(targetServerId)
    
    if player and target then
        local viewerName = player.PlayerData.charinfo.firstname .. " " .. player.PlayerData.charinfo.lastname
        local targetName = target.PlayerData.charinfo.firstname .. " " .. target.PlayerData.charinfo.lastname
        
        if action == "start" then
            print("^2[sh-mdt]^7 " .. viewerName .. " está viendo la dashcam de " .. targetName)
        elseif action == "stop" then
            print("^2[sh-mdt]^7 " .. viewerName .. " dejó de ver la dashcam de " .. targetName)
        end
    end
end)