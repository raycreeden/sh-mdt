local QBCore = exports['qb-core']:GetCoreObject()

-- 🔍 Buscar vehículos por matrícula
QBCore.Functions.CreateCallback('sh-mdt:server:buscarVehiculoPlate', function(source, cb, query)
    if not query or query == '' then return cb({}) end
    local search = '%' .. query .. '%'

    local vehiculos = MySQL.query.await([[
        SELECT pv.plate, pv.vehicle, pv.busqueda, pv.citizenid,
               COALESCE(JSON_UNQUOTE(JSON_EXTRACT(p.charinfo, '$.firstname')), 'N/A') AS nombre,
               COALESCE(JSON_UNQUOTE(JSON_EXTRACT(p.charinfo, '$.lastname')), 'N/A') AS apellido
        FROM player_vehicles pv
        LEFT JOIN players p 
        ON pv.citizenid COLLATE utf8mb4_general_ci = p.citizenid COLLATE utf8mb4_general_ci
        WHERE pv.plate LIKE ?
        LIMIT 30
    ]], { search })

    local results = {}
    if vehiculos and #vehiculos > 0 then
        for _, v in ipairs(vehiculos) do
            table.insert(results, {
                plate = v.plate,
                model = v.vehicle,
                nombre = v.nombre,
                apellido = v.apellido,
                buscado = v.busqueda
            })
        end
    end
    cb(results)
end)


-- 📋 Obtener detalle de vehículo
QBCore.Functions.CreateCallback('sh-mdt:server:getVehiculoOwner', function(source, cb, plate)
    if not plate or plate == '' then return cb({}) end

    local res = MySQL.query.await([[
        SELECT pv.*, 
               COALESCE(JSON_UNQUOTE(JSON_EXTRACT(p.charinfo, '$.firstname')), 'N/A') AS nombre,
               COALESCE(JSON_UNQUOTE(JSON_EXTRACT(p.charinfo, '$.lastname')), 'N/A') AS apellido
        FROM player_vehicles pv
        LEFT JOIN players p 
        ON pv.citizenid COLLATE utf8mb4_general_ci = p.citizenid COLLATE utf8mb4_general_ci
        WHERE pv.plate = ?
        LIMIT 1
    ]], { plate })

    if res and res[1] then
        local v = res[1]
        cb({
            plate = v.plate,
            model = v.vehicle,
            nombre = v.nombre,
            apellido = v.apellido,
            ciudadano_id = v.citizenid,
            buscado = v.busqueda
        })
    else
        cb({})
    end
end)


-- 🚨 Evento: poner/quitar vehículo en búsqueda
RegisterNetEvent('sh-mdt:server:setVehiculoBuscado', function(plate, buscado)
    local src = source
    if not plate then return end

    local newStatus = (buscado == 1 or buscado == true) and 1 or 0
    local affected = MySQL.update.await(
        'UPDATE player_vehicles SET busqueda = ? WHERE plate = ?',
        { newStatus, plate }
    )

    if affected and affected > 0 then
        TriggerClientEvent('sh-mdt:client:notifyVehiculo', src,
            ('Vehículo %s actualizado correctamente.'):format(plate), 'success')
    else
        TriggerClientEvent('sh-mdt:client:notifyVehiculo', src,
            ('No se pudo actualizar el estado del vehículo %s.'):format(plate), 'error')
    end
end)
