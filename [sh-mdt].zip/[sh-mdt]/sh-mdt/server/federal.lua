local QBCore = exports['qb-core']:GetCoreObject()
local FederalPlayers = {}

-- 🔹 Cargar datos federales al iniciar (asíncrono y limitado)
Citizen.CreateThread(function()
    Citizen.Wait(10000)
    MySQL.Async.fetchAll("SELECT * FROM sh_mdt_federal WHERE time > 0 LIMIT 500", {}, function(result)
        for i = 1, #result do
            local federalData = result[i]
            FederalPlayers[federalData.citizenid] = {
                citizenid = federalData.citizenid,
                time = federalData.time,
                initial = federalData.initial,
                name = federalData.name,
                online = false
            }
        end
    end)
end)

-- 🔹 Obtener lista de federales
QBCore.Functions.CreateCallback('getFederalList', function(source, cb)
    for citizenid, federalData in pairs(FederalPlayers) do
        local player = QBCore.Functions.GetPlayerByCitizenId(citizenid)
        FederalPlayers[citizenid].online = (player ~= nil)
    end
    cb(FederalPlayers)
end)

-- 🔹 Liberar federal
QBCore.Functions.CreateCallback('liberarFederal', function(source, cb, data)
    local citizenid = data.citizenid

    if FederalPlayers[citizenid] then
        local targetPlayer = QBCore.Functions.GetPlayerByCitizenId(citizenid)
        if targetPlayer then
            TriggerClientEvent('sh-mdt:client:endFederal', targetPlayer.PlayerData.source)
        end

        FederalPlayers[citizenid] = nil
        MySQL.Async.execute('DELETE FROM sh_mdt_federal WHERE citizenid = ?', { citizenid })
        cb(true)
    else
        cb(false)
    end
end)

-- 🔹 Obtener estado federal
QBCore.Functions.CreateCallback('sh-mdt:server:getFederalStatus', function(source, cb)
    local player = QBCore.Functions.GetPlayer(source)
    if not player then return cb(nil) end

    local citizenid = player.PlayerData.citizenid
    local federalData = FederalPlayers[citizenid]
    cb((federalData and federalData.time and federalData.time > 0) and federalData or nil)
end)

-- 🔹 Enviar a prisión federal
RegisterNetEvent('sh-mdt:server:sendToFederal', function(targetServerId, minutes)
    local src = source
    local player = QBCore.Functions.GetPlayer(src)
    if not player then return end

    local targetPlayer = QBCore.Functions.GetPlayer(tonumber(targetServerId))
    if not targetPlayer then
        TriggerClientEvent('sh-mdt:client:federalConfirmation', src, "❌ Jugador no encontrado")
        return
    end

    local citizenid = targetPlayer.PlayerData.citizenid
    local officerName = player.PlayerData.charinfo.firstname .. " " .. player.PlayerData.charinfo.lastname
    local targetName = targetPlayer.PlayerData.charinfo.firstname .. " " .. targetPlayer.PlayerData.charinfo.lastname

    if FederalPlayers[citizenid] then
        MySQL.Async.execute('UPDATE sh_mdt_federal SET time = ?, initial = ?, name = ? WHERE citizenid = ?', {
            minutes, minutes, targetName, citizenid
        }, function()
            FederalPlayers[citizenid].time = minutes
            FederalPlayers[citizenid].initial = minutes
            FederalPlayers[citizenid].name = targetName
            FederalPlayers[citizenid].online = true
        end)
    else
        MySQL.Async.execute('INSERT INTO sh_mdt_federal (citizenid, time, initial, name) VALUES (?, ?, ?, ?)', {
            citizenid, minutes, minutes, targetName
        }, function()
            FederalPlayers[citizenid] = {
                citizenid = citizenid,
                time = minutes,
                initial = minutes,
                name = targetName,
                online = true
            }
        end)
    end

    TriggerClientEvent('sh-mdt:client:goToFederal', targetServerId, minutes)
    TriggerClientEvent('sh-mdt:client:federalConfirmation', src,
        "✔ " .. targetName .. " enviado a prisión federal por " .. minutes .. " segundos")
end)

-- 🔹 Actualizar tiempo federal
RegisterNetEvent('sh-mdt:server:updateFederalTime', function(remainingTime)
    local src = source
    local player = QBCore.Functions.GetPlayer(src)
    if not player then return end

    local citizenid = player.PlayerData.citizenid
    if FederalPlayers[citizenid] then
        FederalPlayers[citizenid].time = remainingTime
        MySQL.Async.execute('UPDATE sh_mdt_federal SET time = ? WHERE citizenid = ?', { remainingTime, citizenid })
    end
end)

-- 🔹 Completar federal
RegisterNetEvent('sh-mdt:server:completeFederal', function()
    local src = source
    local player = QBCore.Functions.GetPlayer(src)
    if not player then return end

    local citizenid = player.PlayerData.citizenid
    if FederalPlayers[citizenid] then
        FederalPlayers[citizenid] = nil
        MySQL.Async.execute('DELETE FROM sh_mdt_federal WHERE citizenid = ?', { citizenid })
    end
end)

-- 🔹 Revisar al conectar
RegisterNetEvent('QBCore:Server:OnPlayerLoaded', function()
    local src = source
    local player = QBCore.Functions.GetPlayer(src)
    if not player then return end

    local citizenid = player.PlayerData.citizenid
    Citizen.Wait(8000)

    if FederalPlayers[citizenid] and FederalPlayers[citizenid].time > 0 then
        local timeLeft = FederalPlayers[citizenid].time
        FederalPlayers[citizenid].online = true
        TriggerClientEvent('sh-mdt:client:goToFederal', src, timeLeft)
    end
end)

-- 🔹 Manejar desconexión
AddEventHandler('playerDropped', function(reason)
    local src = source
    local player = QBCore.Functions.GetPlayer(src)
    if player then
        local citizenid = player.PlayerData.citizenid
        if FederalPlayers[citizenid] then
            FederalPlayers[citizenid].online = false
        end
    end
end)

-- 🔹 Comando debug (asíncrono)
RegisterCommand('debugfederal', function(source, args)
    local count = 0
    for _, data in pairs(FederalPlayers) do
        if data.time > 0 then count = count + 1 end
    end

    MySQL.Async.fetchAll("SELECT citizenid, time, name FROM sh_mdt_federal WHERE time > 0", {}, function(dbResult)
        print(("[sh-mdt] Federales activos en memoria: %s | En base de datos: %s"):format(count, #dbResult))
    end)
end, false)
