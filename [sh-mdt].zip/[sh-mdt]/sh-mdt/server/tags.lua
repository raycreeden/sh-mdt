local QBCore = exports['qb-core']:GetCoreObject()

-- Variables globales del servidor para compartir tags
local sharedTags = {
    agentes = {},
    informes = {}
}

-- Cargar tags desde BD al iniciar
local function loadTagsFromDB()
    local agentesTags = MySQL.query.await('SELECT tag_name FROM sh_mdt_tags WHERE tag_type = "agentes"')
    local informesTags = MySQL.query.await('SELECT tag_name FROM sh_mdt_tags WHERE tag_type = "informes"')
    
    sharedTags.agentes = {}
    sharedTags.informes = {}
    
    for _, row in ipairs(agentesTags or {}) do
        table.insert(sharedTags.agentes, row.tag_name)
    end
    
    for _, row in ipairs(informesTags or {}) do
        table.insert(sharedTags.informes, row.tag_name)
    end
    
    print("[TAGS] Tags cargados desde BD: Agentes("..#sharedTags.agentes.."), Informes("..#sharedTags.informes..")")
end

-- Crear tabla si no existe
CreateThread(function()
    MySQL.query([[
        CREATE TABLE IF NOT EXISTS sh_mdt_tags (
            id INT AUTO_INCREMENT PRIMARY KEY,
            tag_type VARCHAR(50) NOT NULL,
            tag_name VARCHAR(100) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY unique_tag (tag_type, tag_name)
        )
    ]])
    
    -- Cargar tags existentes
    loadTagsFromDB()
end)

-- Callback: obtener todos los tags
QBCore.Functions.CreateCallback('tags:getAll', function(source, cb)
    cb(sharedTags)
end)

-- Agregar tag
RegisterNetEvent('tags:add', function(tipo, nombre)
    if not tipo or not nombre then return end
    nombre = tostring(nombre)
    tipo = tostring(tipo)

    -- Verificar si el tipo es válido
    if tipo ~= "agentes" and tipo ~= "informes" then
        print("[TAGS] Tipo de tag inválido: " .. tipo)
        return
    end

    sharedTags[tipo] = sharedTags[tipo] or {}

    -- Evitar duplicados en memoria
    for _, v in ipairs(sharedTags[tipo]) do
        if v == nombre then
            return
        end
    end

    -- Guardar en BD
    local success = MySQL.insert.await(
        'INSERT IGNORE INTO sh_mdt_tags (tag_type, tag_name) VALUES (?, ?)',
        {tipo, nombre}
    )

    if success then
        -- Actualizar memoria solo si se guardó en BD
        table.insert(sharedTags[tipo], nombre)
        
        -- Avisar a todos los clientes que hay cambios
        TriggerClientEvent('tags:updateAll', -1, sharedTags)
        print("[TAGS] Tag agregado: " .. tipo .. " - " .. nombre)
    end
end)

-- Eliminar tag
RegisterNetEvent('tags:delete', function(tipo, nombre)
    if not tipo or not nombre then return end
    tipo = tostring(tipo)
    
    if tipo ~= "agentes" and tipo ~= "informes" then
        return
    end

    local tags = sharedTags[tipo] or {}

    -- Eliminar de BD
    local deleted = MySQL.query.await(
        'DELETE FROM sh_mdt_tags WHERE tag_type = ? AND tag_name = ?',
        {tipo, nombre}
    )

    if deleted and deleted.affectedRows > 0 then
        -- Eliminar de memoria
        for i, v in ipairs(tags) do
            if v == nombre then
                table.remove(tags, i)
                break
            end
        end
        sharedTags[tipo] = tags

        -- Avisar a todos los clientes que hay cambios
        TriggerClientEvent('tags:updateAll', -1, sharedTags)
        print("[TAGS] Tag eliminado: " .. tipo .. " - " .. nombre)
    end
end)

-- Comando para forzar recarga de tags (útil para debug)
RegisterCommand('reloadtags', function(source, args, rawCommand)
    if source ~= 0 then
        local Player = QBCore.Functions.GetPlayer(source)
        if not Player or Player.PlayerData.job.name ~= 'police' then
            return
        end
    end
    
    loadTagsFromDB()
    TriggerClientEvent('tags:updateAll', -1, sharedTags)
    print("[TAGS] Tags recargados manualmente")
end, false)