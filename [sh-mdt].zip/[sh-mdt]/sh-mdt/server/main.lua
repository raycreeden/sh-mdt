local QBCore = exports['qb-core']:GetCoreObject()

-- callback: tiene item
QBCore.Functions.CreateCallback('sh-mdt:server:hasItem', function(source, cb, itemName)
    local Player = QBCore.Functions.GetPlayer(source)
    if not Player then cb(false) return end
    local item = Player.Functions.GetItemByName(itemName)
    cb(item ~= nil)
end)

-- contar policías on-duty
local function CountPoliceOnDuty()
    local count = 0
    for _, src in pairs(QBCore.Functions.GetPlayers()) do
        local ply = QBCore.Functions.GetPlayer(src)
        if ply and ply.PlayerData.job and ply.PlayerData.job.name == Config.AllowedJob and ply.PlayerData.job.onduty then
            count = count + 1
        end
    end
    return count
end

RegisterNetEvent('sh-mdt:server:requestOnDutyCount', function()
    local src = source
    TriggerClientEvent('sh-mdt:client:setOnDutyCount', src, CountPoliceOnDuty())
end)

-- cuando alguien togglea duty desde cualquier lado, refrescar a todos los MDT abiertos
RegisterNetEvent('QBCore:Client:OnJobUpdate', function() -- por compatibilidad; puedes también enganchar tu evento de duty
    local count = CountPoliceOnDuty()
    for _, src in pairs(QBCore.Functions.GetPlayers()) do
        TriggerClientEvent('sh-mdt:client:setOnDutyCount', src, count)
    end
end)

---------------------------------------------------------------
-- SISTEMA DE ARMARIOS POLICIALES - TODOS INDIVIDUALES
---------------------------------------------------------------

if not Config.PoliceArmorySystem.enabled then
    return
end

-- 🔹 Inventario Policial (COMPARTIDO - solo este)
RegisterNetEvent("sh-mdt:server:abrirInventario", function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player or Player.PlayerData.job.name ~= "police" then
        TriggerClientEvent('QBCore:Notify', src, "No autorizado.", "error")
        return
    end

    -- Este es el ÚNICO que se comparte (como pediste)
    exports['qb-inventory']:OpenInventory(src, "stash", "police_inventory", {
        label = "Inventario Policial",
        maxweight = 1000000,
        slots = 50,
    })
end)

-- 🔹 Armamento Policial (INDIVIDUAL - NO COMPARTIDO)
RegisterNetEvent("sh-mdt:server:abrirArmoryStorage", function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player or Player.PlayerData.job.name ~= "police" then
        TriggerClientEvent('QBCore:Notify', src, "No autorizado.", "error")
        return
    end

    local citizenId = Player.PlayerData.citizenid
    local playerName = Player.PlayerData.charinfo.firstname
    
    -- Crear inventario personalizado en lugar de stash compartido
    local inventoryName = "police_armory_" .. citizenId
    
    exports['qb-inventory']:CreateInventory(inventoryName, {
        label = "Armamento de " .. playerName,
        maxweight = 1000000,
        slots = 50
    })
    
    exports['qb-inventory']:OpenInventory(src, inventoryName)
end)

-- 🔹 Evidencias (INDIVIDUAL - NO COMPARTIDO)
RegisterNetEvent("sh-mdt:server:abrirEvidencia", function(evidenceId)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player or Player.PlayerData.job.name ~= "police" then
        TriggerClientEvent('QBCore:Notify', src, "No autorizado.", "error")
        return
    end

    if not evidenceId or evidenceId == "" then
        TriggerClientEvent('QBCore:Notify', src, "Debe ingresar un nombre o número válido.", "error")
        return
    end

    local citizenId = Player.PlayerData.citizenid
    local playerName = Player.PlayerData.charinfo.firstname
    local cleanId = string.gsub(evidenceId, "%s+", "_")
    cleanId = string.gsub(cleanId, "[^%w_%-]", "")
    
    -- Crear inventario personalizado en lugar de stash compartido
    local inventoryName = "evidence_" .. citizenId .. "_" .. cleanId

    exports['qb-inventory']:CreateInventory(inventoryName, {
        label = "Evidencia " .. evidenceId .. " - " .. playerName,
        maxweight = 100000,
        slots = 30
    })
    
    exports['qb-inventory']:OpenInventory(src, inventoryName)
end)

-- 🔹 Equipamiento Policial (TIENDA - COMPARTIDA)
RegisterNetEvent("sh-mdt:server:abrirEquipamientoPolicial", function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player or Player.PlayerData.job.name ~= "police" then
        TriggerClientEvent('QBCore:Notify', src, "No autorizado.", "error")
        return
    end

    local items = Config.EquipamientoPolicial['police']
    if not items or #items == 0 then
        TriggerClientEvent('QBCore:Notify', src, "No hay equipamiento definido.", "error")
        return
    end

    exports['qb-inventory']:CreateShop({
        name = "police_equipamiento",
        label = "Equipamiento Policial",
        slots = #items,
        coords = Config.PoliceArmorySystem.coords,
        items = items,
    })

    exports['qb-inventory']:OpenShop(src, "police_equipamiento")
end)

-- ==========================================================
-- 🔹 SISTEMA DE PROCESADOS - SERVIDOR
-- ==========================================================

-- Salir si el sistema está desactivado
if not Config.ProcessedSystem or not Config.ProcessedSystem.enabled then
    return
end

-------------------------------------------------------
-- 🔹 ABRIR EXPEDIENTE DE PROCESADO (INDIVIDUAL)
-------------------------------------------------------
RegisterNetEvent("sh-mdt:server:abrirProcesado", function(processedId)
    local src = source

    if not processedId or processedId == "" then
        TriggerClientEvent('QBCore:Notify', src, "Debe ingresar un nombre o ID válido.", "error")
        return
    end

    -- Limpiar el ID (quitar espacios y caracteres especiales)
    local cleanId = string.gsub(processedId, "%s+", "_")
    cleanId = string.gsub(cleanId, "[^%w_%-]", "")
    
    -- 🔒 Crear inventario INDIVIDUAL para el procesado usando CreateInventory
    local inventoryName = "procesado_" .. cleanId

    exports['qb-inventory']:CreateInventory(inventoryName, {
        label = "Expediente: " .. processedId,
        maxweight = 50000,  -- 50kg de peso
        slots = 20,         -- 20 slots disponibles
    })
    
    -- Abrir el inventario individual del procesado
    exports['qb-inventory']:OpenInventory(src, inventoryName)
end)

-------------------------------------------------------
-- 🔹 COMANDO ADMIN PARA LIMPIAR PROCESADOS (OPCIONAL)
-------------------------------------------------------
RegisterCommand("limpiarprocesado", function(source, args, rawCommand)
    local src = source
    local processedId = args[1]
    
    if not processedId then
        TriggerClientEvent('QBCore:Notify', src, "Uso: /limpiarprocesado [nombre_procesado]", "error")
        return
    end

    -- Verificar permisos de admin
    if not IsPlayerAceAllowed(src, "command.cleanprocessed") then
        TriggerClientEvent('QBCore:Notify', src, "No tienes permisos para esto.", "error")
        return
    end

    local cleanId = string.gsub(processedId, "%s+", "_")
    cleanId = string.gsub(cleanId, "[^%w_%-]", "")
    local inventoryName = "procesado_" .. cleanId

    -- Limpiar el inventario del procesado
    exports['qb-inventory']:RemoveInventory(inventoryName)
    
    TriggerClientEvent('QBCore:Notify', src, "Expediente de " .. processedId .. " limpiado correctamente.", "success")
end, false)

-- ==========================================================
-- 🔹 SISTEMA DE HUELLAS DIGITALES - SERVIDOR
-- ==========================================================

-- Salir si el sistema está desactivado
if not Config.FingerprintSystem or not Config.FingerprintSystem.enabled then
    return
end


-------------------------------------------------------
-- 🔹 COMANDO ADMIN PARA VER UBICACIONES
-------------------------------------------------------
RegisterCommand("verhuellas", function(source, args, rawCommand)
    local src = source
    
    if not IsPlayerAceAllowed(src, "command.seehuellas") then
        TriggerClientEvent('QBCore:Notify', src, "No tienes permisos para esto.", "error")
        return
    end
    
    local locations = Config.FingerprintSystem.locations
    TriggerClientEvent('QBCore:Notify', src, "Ubicaciones de huellas: " .. #locations, "info")
    
end, false)

