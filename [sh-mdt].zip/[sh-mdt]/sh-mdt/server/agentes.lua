local QBCore = exports['qb-core']:GetCoreObject()

-- Callback: devolver oficiales (CORREGIDO)
-- Callback: devolver oficiales (VERSIÓN CORREGIDA - SOLO POLICÍAS ACTIVOS)
QBCore.Functions.CreateCallback('sh-mdt:server:getOficiales', function(source, cb)
    local oficiales = {}

    -- 🔥 CORRECCIÓN: Buscar solo jugadores que actualmente tienen job.name = 'police'
    -- Esto evita mostrar ex-policías que todavía tienen "police" en su historial
    local players = QBCore.Functions.GetQBPlayers()
    
    for _, player in pairs(players) do
        if player and player.PlayerData and player.PlayerData.job then
            -- Solo incluir si el trabajo actual es police
            if player.PlayerData.job.name == 'police' then
                local charinfo = player.PlayerData.charinfo or {}
                local meta = player.PlayerData.metadata or {}
                local badge = meta["badge_number"] or "N/A"
                
                local state = player.PlayerData.job.onduty and "duty" or "offduty"
                local gradeLevel = 0
                local gradeName = "Oficial"

                -- Procesar grade
                if player.PlayerData.job.grade then
                    if type(player.PlayerData.job.grade) == "table" then
                        gradeLevel = player.PlayerData.job.grade.level or 0
                        gradeName = player.PlayerData.job.grade.name or "Oficial"
                    else
                        gradeLevel = tonumber(player.PlayerData.job.grade) or 0
                        gradeName = "Oficial"
                    end
                end

                table.insert(oficiales, {
                    serverId = player.PlayerData.source,
                    name = ("%s %s"):format(charinfo.firstname or "Desconocido", charinfo.lastname or ""),
                    grade = gradeLevel,
                    gradeName = gradeName,
                    callsign = badge,
                    status = state
                })
            end
        end
    end

    -- 🔥 OPCIÓN ALTERNATIVA: También incluir policías desconectados desde la base de datos
    -- Pero solo si realmente los necesitas mostrar cuando están offline
    local data = MySQL.query.await("SELECT citizenid, charinfo, job, metadata FROM players WHERE JSON_EXTRACT(job, '$.name') = 'police'")
    
    for _, row in ipairs(data) do
        local charinfo = json.decode(row.charinfo or "{}")
        local jobData = json.decode(row.job or "{}")
        local meta = json.decode(row.metadata or "{}")
        local badge = meta["badge_number"] or "N/A"

        -- Verificar si el jugador está online (ya incluido arriba)
        local online = QBCore.Functions.GetPlayerByCitizenId(row.citizenid)
        
        -- Si no está online, agregarlo como desconectado
        if not online then
            local gradeLevel = 0
            local gradeName = "Oficial"

            if jobData.grade then
                if type(jobData.grade) == "table" then
                    gradeLevel = jobData.grade.level or 0
                    gradeName = jobData.grade.name or "Oficial"
                else
                    gradeLevel = tonumber(jobData.grade) or 0
                    gradeName = "Oficial"
                end
            end

            table.insert(oficiales, {
                serverId = 0, -- 0 indica desconectado
                name = ("%s %s"):format(charinfo.firstname or "Desconocido", charinfo.lastname or ""),
                grade = gradeLevel,
                gradeName = gradeName,
                callsign = badge,
                status = "offline"
            })
        end
    end

    -- Ordenar por grade (mayor a menor)
    table.sort(oficiales, function(a, b)
        return (a.grade or 0) > (b.grade or 0)
    end)

    cb(oficiales)
end)

-- Obtener perfil de un agente
QBCore.Functions.CreateCallback('sh-mdt:server:getAgentProfile', function(source, cb, targetServerId)
    local player = QBCore.Functions.GetPlayer(tonumber(targetServerId))
    if not player then
        cb({})
        return
    end

    local badge = (player.PlayerData.metadata and player.PlayerData.metadata["badge_number"]) or "N/A"
    local tags = (player.PlayerData.metadata and player.PlayerData.metadata["tags_agentes_asignados"]) or {}

    cb({
        serverId = tonumber(targetServerId),
        name = player.PlayerData.charinfo.firstname .. " " .. player.PlayerData.charinfo.lastname,
        grade = (player.PlayerData.job.grade and player.PlayerData.job.grade.level) or 0,
        gradeName = (player.PlayerData.job.grade and player.PlayerData.job.grade.name) or 'Oficial',
        callsign = badge,
        tags = tags
    })
end)

-- Devolver job grades disponibles (basado en un job 'police' del server)
QBCore.Functions.CreateCallback('sh-mdt:server:getJobGrades', function(source, cb)
    local grades = {}
    local jobDef = QBCore.Shared.Jobs["police"]

    if jobDef and jobDef.grades then
        for k, v in pairs(jobDef.grades) do
            local gradeLevel = tonumber(v.grade) or tonumber(k) or 0
            local gradeName = v.label or v.name or tostring(k)
            table.insert(grades, { level = gradeLevel, name = gradeName })
        end
    end

    -- Evita error si hay nil
    table.sort(grades, function(a, b)
        return (a.level or 0) < (b.level or 0)
    end)

    cb(grades)
end)

-- Cambiar grade de target (promover/descender)
RegisterNetEvent('sh-mdt:server:setPlayerGrade', function(targetServerId, newGrade)
    local src = source
    local srcPlayer = QBCore.Functions.GetPlayer(src)
    if not srcPlayer then return end

    local allowedGrade = tonumber(Config.PromotionMinGrade) or 4
    local srcGrade = 0

    if srcPlayer.PlayerData.job and srcPlayer.PlayerData.job.grade then
        if type(srcPlayer.PlayerData.job.grade) == "table" then
            srcGrade = tonumber(srcPlayer.PlayerData.job.grade.level) or 0
        else
            srcGrade = tonumber(srcPlayer.PlayerData.job.grade) or 0
        end
    end

    if srcGrade < allowedGrade then
        TriggerClientEvent('sh-mdt:client:gradeResponse', src, false, "No tienes permiso para cambiar rangos")
        return
    end

    local target = QBCore.Functions.GetPlayer(targetServerId)
    if not target then
        TriggerClientEvent('sh-mdt:client:gradeResponse', src, false, "Jugador no encontrado")
        return
    end

    local jobName = target.PlayerData.job.name
    local res, err = pcall(function()
        target.Functions.SetJob(jobName, tonumber(newGrade))
    end)

    if res then
        TriggerClientEvent('sh-mdt:client:gradeResponse', src, true, "Rango actualizado correctamente")
        TriggerClientEvent('QBCore:Notify', targetServerId, "Tu rango ha cambiado", "success")
    else
        TriggerClientEvent('sh-mdt:client:gradeResponse', src, false, "Error al cambiar rango")
    end
end)

-- Etiquetas: agregar/elimnar (se guardan en metadata.tags_agentes)
RegisterNetEvent('sh-mdt:server:addTagToAgent')
AddEventHandler('sh-mdt:server:addTagToAgent', function(targetServerId, tag)
    local src = source
    local target = QBCore.Functions.GetPlayer(targetServerId)
    if not target then return end

    local meta = target.PlayerData.metadata or {}
meta["tags_agentes_asignados"] = meta["tags_agentes_asignados"] or {}
-- evitar duplicados
local exists = false
for _, t in ipairs(meta["tags_agentes_asignados"]) do if t == tag then exists = true break end end
if not exists then table.insert(meta["tags_agentes_asignados"], tag) end
target.Functions.SetMetaData("tags_agentes_asignados", meta["tags_agentes_asignados"])
TriggerClientEvent('QBCore:Notify', src, "Tag asignado al agente", "success")

end)

-- Eliminar SOLO la etiqueta del agente (sin tocar las etiquetas globales)
RegisterNetEvent('sh-mdt:server:removeTagFromAgent')
AddEventHandler('sh-mdt:server:removeTagFromAgent', function(targetServerId, tag)
    local src = source
    local target = QBCore.Functions.GetPlayer(targetServerId)
    if not target then return end

    -- Obtener metadata actual del agente
    local meta = target.PlayerData.metadata or {}
    meta["tags_agentes_asignados"] = meta["tags_agentes_asignados"] or {}

    -- Crear una nueva lista sin el tag eliminado
    local newTags = {}
    for _, t in ipairs(meta["tags_agentes_asignados"]) do
        if t ~= tag then
            table.insert(newTags, t)
        end
    end

    -- Guardar la nueva lista en metadata
    target.Functions.SetMetaData("tags_agentes_asignados", newTags)

    -- Notificación al usuario que hizo la acción
    TriggerClientEvent('QBCore:Notify', src, "Tag removido del agente", "success")
end)

-- Tag/registrar como agente (opcional: marca en metadata)
RegisterNetEvent('sh-mdt:server:addAgent')
AddEventHandler('sh-mdt:server:addAgent', function(targetServerId)
    local src = source
    local srcPlayer = QBCore.Functions.GetPlayer(src)
    if not srcPlayer then return end

    local allowedGrade = Config.PromotionMinGrade or 5
    local srcGrade = srcPlayer.PlayerData.job.grade and (srcPlayer.PlayerData.job.grade.level or srcPlayer.PlayerData.job.grade) or 0

    if tonumber(srcGrade) < tonumber(allowedGrade) then
        TriggerClientEvent('QBCore:Notify', src, "No tienes permiso para agregar agentes", "error")
        return
    end

    local target = QBCore.Functions.GetPlayer(targetServerId)
    if not target then
        TriggerClientEvent('QBCore:Notify', src, "Jugador no encontrado", "error")
        return
    end

    -- Aplicar trabajo de policía rango 0
    local success, err = pcall(function()
        target.Functions.SetJob('police', 0)
    end)

    if success then
        TriggerClientEvent('QBCore:Notify', src, "Agente agregado correctamente", "success")
        TriggerClientEvent('QBCore:Notify', targetServerId, "Has sido incorporado al cuerpo policial", "success")
    else
        TriggerClientEvent('QBCore:Notify', src, "Error al agregar agente", "error")
    end
end)

-- Opcional: eliminar agente (por ahora solo lo hace el server si lo llamas desde NUI)
RegisterNetEvent('sh-mdt:server:removeAgent')
AddEventHandler('sh-mdt:server:removeAgent', function(targetServerId)
    local src = source
    local srcPlayer = QBCore.Functions.GetPlayer(src)
    local allowedGrade = Config.PromotionMinGrade or 5
    local srcGrade = srcPlayer and srcPlayer.PlayerData.job.grade.level or 0
    if srcGrade < allowedGrade then
        TriggerClientEvent('QBCore:Notify', src, "No tienes permiso", "error")
        return
    end

    local target = QBCore.Functions.GetPlayer(targetServerId)
    if not target then
        TriggerClientEvent('QBCore:Notify', src, "Jugador no encontrado", "error")
        return
    end

    -- Ejemplo: marcarlo como no-en servicio: (si quieres remover job o marcar metadata)
    target.Functions.SetMetaData("is_agent_registered", false)
    TriggerClientEvent('QBCore:Notify', src, "Agente eliminado/registrado como no-agente", "success")
end)

RegisterNetEvent('sh-mdt:server:despedirAgent', function(targetServerId)
    local src = source
    local srcPlayer = QBCore.Functions.GetPlayer(src)
    if not srcPlayer then 
        return 
    end

    local allowedGrade = Config.PromotionMinGrade or 5
    local srcGrade = 0
    if srcPlayer.PlayerData.job and srcPlayer.PlayerData.job.grade then
        if type(srcPlayer.PlayerData.job.grade) == "table" then
            srcGrade = srcPlayer.PlayerData.job.grade.level or 0
        else
            srcGrade = tonumber(srcPlayer.PlayerData.job.grade) or 0
        end
    end

    if tonumber(srcGrade) < tonumber(allowedGrade) then
        TriggerClientEvent('QBCore:Notify', src, "No tienes permiso para despedir agentes", "error")
        return
    end

    local target = QBCore.Functions.GetPlayer(targetServerId)
    if not target then
        TriggerClientEvent('QBCore:Notify', src, "Jugador no encontrado", "error")
        return
    end

    -- Verificar que el target sea policía antes de despedir
    if target.PlayerData.job.name ~= 'police' then
        TriggerClientEvent('QBCore:Notify', src, "Este jugador no es un agente policial", "error")
        return
    end

    -- Despedir: cambiar trabajo a unemployed 0
    local success = target.Functions.SetJob('unemployed', 0)

    if success then
        -- 🔥 LIMPIAR METADATA relacionada con policía
        local meta = target.PlayerData.metadata or {}
        meta["badge_number"] = nil
        meta["tags_agentes_asignados"] = nil
        target.Functions.SetMetaData("badge_number", nil)
        target.Functions.SetMetaData("tags_agentes_asignados", nil)
        
        TriggerClientEvent('QBCore:Notify', src, "Agente despedido correctamente", "success")
        TriggerClientEvent('QBCore:Notify', targetServerId, "Has sido despedido del cuerpo policial", "error")
        
        -- 🔥 NOTIFICAR A TODOS LOS CLIENTES PARA ACTUALIZAR
        TriggerClientEvent('sh-mdt:client:refreshAgentes', -1)
        
        
        -- 🔥 ACTUALIZAR INMEDIATAMENTE en la base de datos
        MySQL.update('UPDATE players SET job = ? WHERE citizenid = ?', {
            json.encode({name = "unemployed", label = "Civil", grade = {name = "Civil", level = 0}, onduty = false}),
            target.PlayerData.citizenid
        })
        
    else
        TriggerClientEvent('QBCore:Notify', src, "Error al despedir agente", "error")
    end
end)