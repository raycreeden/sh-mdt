local QBCore = exports['qb-core']:GetCoreObject()

-- Obtener ciudadanos en búsqueda y captura
RegisterNetEvent('sh-mdt:server:getBusquedaCaptura', function()
    local src = source
    local ciudadanos = {}

    local result = MySQL.Sync.fetchAll("SELECT * FROM sh_mdt_ciudadanos WHERE captura = 1", {})
    
    if result and #result > 0 then
        for _, ciudadano in ipairs(result) do
            -- Obtener información adicional del jugador si está online
            local player = QBCore.Functions.GetPlayerByCitizenId(ciudadano.identifier)
            local online = false
            local serverId = nil

            if player then
                online = true
                serverId = player.PlayerData.source
            end

            table.insert(ciudadanos, {
                id = ciudadano.id,
                identifier = ciudadano.identifier,
                nombre = ciudadano.nombre,
                apellido = ciudadano.apellido,
                fecha_nac = ciudadano.fecha_nac,
                nacionalidad = ciudadano.nacionalidad,
                altura = ciudadano.altura,
                peligroso = ciudadano.peligroso,
                captura = ciudadano.captura,
                online = online,
                server_id = serverId
            })
        end
    end

    TriggerClientEvent('sh-mdt:client:receiveBusquedaCaptura', src, ciudadanos)
end)