local QBCore = exports['qb-core']:GetCoreObject()
local Casings = {}
local BloodDrops = {}
local FingerDrops = {}
local PlayerStatus = {}

-- Functions
local function CreateBloodId()
    local bloodId = math.random(10000, 99999)
    while BloodDrops[bloodId] do
        bloodId = math.random(10000, 99999)
    end
    return bloodId
end

local function CreateFingerId()
    local fingerId = math.random(10000, 99999)
    while FingerDrops[fingerId] do
        fingerId = math.random(10000, 99999)
    end
    return fingerId
end

local function CreateCasingId()
    local caseId = math.random(10000, 99999)
    while Casings[caseId] do
        caseId = math.random(10000, 99999)
    end
    return caseId
end

-- Callbacks
QBCore.Functions.CreateCallback('police:GetPlayerStatus', function(_, cb, playerId)
    local Player = QBCore.Functions.GetPlayer(playerId)
    local statList = {}
    if Player then
        if PlayerStatus[Player.PlayerData.source] and next(PlayerStatus[Player.PlayerData.source]) then
            for k, v in pairs(PlayerStatus[Player.PlayerData.source]) do
                if v.time > 0 then
                    statList[#statList + 1] = v.text
                end
            end
        end
    end
    cb(statList)
end)

-- Events
RegisterNetEvent('evidence:server:UpdateStatus', function(data)
    local src = source
    PlayerStatus[src] = data
end)

-- EVENTO CORREGIDO: Crear sangre
RegisterNetEvent('evidence:server:CreateBloodDrop', function(citizenid, bloodtype, coords)
    local bloodId = CreateBloodId()
    BloodDrops[bloodId] = {
        dna = citizenid,
        bloodtype = bloodtype,
        coords = coords  -- Guardar coordenadas también en servidor
    }
    TriggerClientEvent('evidence:client:AddBlooddrop', -1, bloodId, citizenid, bloodtype, coords)
end)

RegisterNetEvent('evidence:server:CreateFingerDrop', function(data)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player or not data or not data.coords then return end

    local fingerId = CreateFingerId()
    local fingerprint = Player.PlayerData.metadata['fingerprint']

    FingerDrops[fingerId] = {
        fingerprint = fingerprint,
        coords = data.coords,
        vehicle = data.netId or nil
    }

    TriggerClientEvent('evidence:client:AddFingerPrint', -1, fingerId, fingerprint, data.coords, data.netId)
end)

RegisterNetEvent('evidence:server:ClearBlooddrops', function(blooddropList)
    if blooddropList and next(blooddropList) then
        for _, v in pairs(blooddropList) do
            TriggerClientEvent('evidence:client:RemoveBlooddrop', -1, v)
            BloodDrops[v] = nil
        end
    end
end)

-- Evento para añadir sangre al inventario
RegisterNetEvent('evidence:server:AddBlooddropToInventory', function(bloodId, bloodInfo)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if not Player then return end
    
    if Player.PlayerData.job.name ~= 'police' then
        TriggerClientEvent('QBCore:Notify', src, 'No eres policía', 'error')
        return
    end
    
    if not BloodDrops[bloodId] then
        TriggerClientEvent('QBCore:Notify', src, 'La evidencia ya fue recolectada', 'error')
        return
    end
    
    local hasBag = Player.Functions.GetItemByName('empty_evidence_bag')
    if not hasBag or hasBag.amount < 1 then
        TriggerClientEvent('QBCore:Notify', src, 'Necesitas una bolsa de evidencia vacía', 'error')
        return
    end
    
    if Player.Functions.RemoveItem('empty_evidence_bag', 1) then
        if Player.Functions.AddItem('filled_evidence_bag', 1, nil, bloodInfo) then
            TriggerClientEvent('qb-inventory:client:ItemBox', src, QBCore.Shared.Items['filled_evidence_bag'], 'add')
            TriggerClientEvent('evidence:client:RemoveBlooddrop', -1, bloodId)
            BloodDrops[bloodId] = nil
            TriggerClientEvent('QBCore:Notify', src, 'Muestra de sangre recolectada', 'success')
        else
            Player.Functions.AddItem('empty_evidence_bag', 1)
            TriggerClientEvent('QBCore:Notify', src, 'Error al recolectar la evidencia', 'error')
        end
    else
        TriggerClientEvent('QBCore:Notify', src, 'Error al usar la bolsa de evidencia', 'error')
    end
end)

-- Evento para añadir huella al inventario
RegisterNetEvent('evidence:server:AddFingerprintToInventory', function(fingerId, fingerInfo)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if not Player then return end
    
    if Player.PlayerData.job.name ~= 'police' then
        TriggerClientEvent('QBCore:Notify', src, 'No eres policía', 'error')
        return
    end
    
    if not FingerDrops[fingerId] then
        TriggerClientEvent('QBCore:Notify', src, 'La evidencia ya fue recolectada', 'error')
        return
    end
    
    local hasBag = Player.Functions.GetItemByName('empty_evidence_bag')
    if not hasBag or hasBag.amount < 1 then
        TriggerClientEvent('QBCore:Notify', src, 'Necesitas una bolsa de evidencia vacía', 'error')
        return
    end
    
    if Player.Functions.RemoveItem('empty_evidence_bag', 1) then
        if Player.Functions.AddItem('filled_evidence_bag', 1, nil, fingerInfo) then
            TriggerClientEvent('qb-inventory:client:ItemBox', src, QBCore.Shared.Items['filled_evidence_bag'], 'add')
            TriggerClientEvent('evidence:client:RemoveFingerprint', -1, fingerId)
            FingerDrops[fingerId] = nil
            TriggerClientEvent('QBCore:Notify', src, 'Huella digital recolectada', 'success')
        else
            Player.Functions.AddItem('empty_evidence_bag', 1)
            TriggerClientEvent('QBCore:Notify', src, 'Error al recolectar la evidencia', 'error')
        end
    else
        TriggerClientEvent('QBCore:Notify', src, 'Error al usar la bolsa de evidencia', 'error')
    end
end)

RegisterNetEvent('evidence:server:CreateCasing', function(weapon, coords)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end
    
    local casingId = CreateCasingId()
    local weaponInfo = QBCore.Shared.Weapons[weapon]
    local serieNumber = nil
    
    if weaponInfo then
        local weaponItem = Player.Functions.GetItemByName(weaponInfo['name'])
        if weaponItem then
            if weaponItem.info and weaponItem.info.serie then
                serieNumber = weaponItem.info.serie
            end
        end
    end
    
    Casings[casingId] = {
        weapon = weapon,
        coords = coords,
        serie = serieNumber
    }
    
    TriggerClientEvent('evidence:client:AddCasing', -1, casingId, weapon, coords, serieNumber)
end)

RegisterNetEvent('evidence:server:ClearCasings', function(casingList)
    if casingList and next(casingList) then
        for _, v in pairs(casingList) do
            TriggerClientEvent('evidence:client:RemoveCasing', -1, v)
            Casings[v] = nil
        end
    end
end)

-- Evento para añadir casquillo al inventario
RegisterNetEvent('evidence:server:AddCasingToInventory', function(casingId, casingInfo)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if not Player then return end
    
    if Player.PlayerData.job.name ~= 'police' then
        TriggerClientEvent('QBCore:Notify', src, 'No eres policía', 'error')
        return
    end
    
    if not Casings[casingId] then
        TriggerClientEvent('QBCore:Notify', src, 'La evidencia ya fue recolectada', 'error')
        return
    end
    
    local hasBag = Player.Functions.GetItemByName('empty_evidence_bag')
    if not hasBag or hasBag.amount < 1 then
        TriggerClientEvent('QBCore:Notify', src, 'Necesitas una bolsa de evidencia vacía', 'error')
        return
    end
    
    if Player.Functions.RemoveItem('empty_evidence_bag', 1) then
        if Player.Functions.AddItem('filled_evidence_bag', 1, nil, casingInfo) then
            TriggerClientEvent('qb-inventory:client:ItemBox', src, QBCore.Shared.Items['filled_evidence_bag'], 'add')
            TriggerClientEvent('evidence:client:RemoveCasing', -1, casingId)
            Casings[casingId] = nil
            TriggerClientEvent('QBCore:Notify', src, 'Casquillo recolectado', 'success')
        else
            Player.Functions.AddItem('empty_evidence_bag', 1)
            TriggerClientEvent('QBCore:Notify', src, 'Error al recolectar la evidencia', 'error')
        end
    else
        TriggerClientEvent('QBCore:Notify', src, 'Error al usar la bolsa de evidencia', 'error')
    end
end)



-- INICIALIZACIÓN CORREGIDA de metadatos:
RegisterNetEvent('QBCore:Server:OnPlayerLoaded', function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if Player then
        -- CORREGIDO: Inicialización segura de bloodtype
        if not Player.PlayerData.metadata['bloodtype'] then
            local bloodTypes = {'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'}
            local bloodTypesCount = #bloodTypes
            if bloodTypesCount > 0 then
                local randomIndex = math.random(1, bloodTypesCount)
                local randomBlood = bloodTypes[randomIndex]
                Player.Functions.SetMetaData('bloodtype', randomBlood)
            else
            end
        end
        
        -- Inicializar huella digital si no existe
        if not Player.PlayerData.metadata['fingerprint'] then
            local fingerprint = Player.PlayerData.citizenid .. math.random(1000, 9999)
            Player.Functions.SetMetaData('fingerprint', fingerprint)
        end
    end
end)

-- Eventos para limpiar evidencias individualmente
RegisterNetEvent('evidence:server:RemoveCasing', function(casingId)
    if Casings[casingId] then
        TriggerClientEvent('evidence:client:RemoveCasing', -1, casingId)
        Casings[casingId] = nil
    end
end)

RegisterNetEvent('evidence:server:RemoveBlooddrop', function(bloodId)
    if BloodDrops[bloodId] then
        TriggerClientEvent('evidence:client:RemoveBlooddrop', -1, bloodId)
        BloodDrops[bloodId] = nil
    end
end)

RegisterNetEvent('evidence:server:RemoveFingerprint', function(fingerId)
    if FingerDrops[fingerId] then
        TriggerClientEvent('evidence:client:RemoveFingerprint', -1, fingerId)
        FingerDrops[fingerId] = nil
    end
end)

-- EVENTO NUEVO: Crear sangre para NPCs
RegisterNetEvent('evidence:server:CreateBloodDropForNPC', function(bloodtype, coords, npcId)
    local bloodId = CreateBloodId()
    local npcCitizenId = "NPC_" .. (npcId or "UNKNOWN") .. "_" .. math.random(1000, 9999)
    
    BloodDrops[bloodId] = {
        dna = npcCitizenId,
        bloodtype = bloodtype,
        coords = coords,
        isNPC = true
    }
    TriggerClientEvent('evidence:client:AddBlooddrop', -1, bloodId, npcCitizenId, bloodtype, coords)
end)

-- Evento para manejar daño a NPCs
RegisterNetEvent('evidence:server:OnNPCDamage', function(npcId, coords, weapon)
    local bloodTypes = {'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'}
    local randomBlood = bloodTypes[math.random(1, #bloodTypes)]
    
    -- Crear sangre para el NPC
    TriggerEvent('evidence:server:CreateBloodDropForNPC', randomBlood, coords, npcId)
    
end)

-- ==================================================
-- SISTEMA DETECTOR DE ESTADOS - SERVIDOR
-- ==================================================

-- Función para obtener el texto del estado
function GetStatusText(statusKey)
    local StatusTexts = {
        ['fight'] = 'Manos rojas',
        ['widepupils'] = 'Pupilas dilatadas',
        ['redeyes'] = 'Ojos rojos', 
        ['weedsmell'] = 'Olor a marihuana',
        ['gunpowder'] = 'Pólvora en manos',
        ['chemicals'] = 'Olor a químicos',
        ['heavybreath'] = 'Respiración pesada',
        ['sweat'] = 'Sudoración excesiva',
        ['handbleed'] = 'Manos sangrando',
        ['confused'] = 'Confusión',
        ['alcohol'] = 'Olor a alcohol',
        ['heavyalcohol'] = 'Olor fuerte a alcohol',
        ['agitated'] = 'Agitación'
    }
    
    return StatusTexts[statusKey]
end

-- Evento para verificar estados de jugador
RegisterServerEvent('detector:server:checkPlayerStatus')
AddEventHandler('detector:server:checkPlayerStatus', function(targetServerId)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    local TargetPlayer = QBCore.Functions.GetPlayer(targetServerId)
    
    if not Player or not TargetPlayer then
        TriggerClientEvent('QBCore:Notify', src, 'Error: Jugador no encontrado', 'error')
        return
    end
    
    -- Verificar que sea policía
    if Player.PlayerData.job.name ~= 'police' then
        TriggerClientEvent('QBCore:Notify', src, 'No autorizado', 'error')
        return
    end
    
    -- Verificar que el jugador tenga el item pol_detector
    local detectorItem = Player.Functions.GetItemByName('pol_detector')
    if not detectorItem then
        TriggerClientEvent('QBCore:Notify', src, 'No tienes el detector', 'error')
        return
    end
    
    -- Obtener estados del jugador objetivo
    local targetSrc = TargetPlayer.PlayerData.source
    local statusList = {}
    
    -- Verificar si el jugador objetivo tiene estados activos
    if PlayerStatus[targetSrc] then
        for statusKey, statusData in pairs(PlayerStatus[targetSrc]) do
            if statusData and statusData.time > 0 then
                -- Traducir el key del estado a texto
                local statusText = GetStatusText(statusKey)
                if statusText then
                    table.insert(statusList, statusText)
                end
            end
        end
    else
    end
    
    -- Enviar resultados al cliente
    TriggerClientEvent('detector:client:showResults', src, statusList)
end)

-- Registrar el item como usable
QBCore.Functions.CreateUseableItem('pol_detector', function(source, item)
    local Player = QBCore.Functions.GetPlayer(source)
    
    if not Player then return end
    
    -- Verificar que sea policía
    if Player.PlayerData.job.name ~= 'police' then
        TriggerClientEvent('QBCore:Notify', source, 'Solo la policía puede usar esto', 'error')
        return
    end
    
    TriggerClientEvent('qb-items:client:useDetector', source)
end)