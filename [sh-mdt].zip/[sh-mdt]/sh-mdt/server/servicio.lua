-- server/servicio.lua
local QBCore = exports['qb-core']:GetCoreObject()

RegisterNetEvent('sh-mdt:server:toggleDuty', function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player or Player.PlayerData.job.name ~= Config.AllowedJob then return end
    -- Usamos el toggle del core (si tu framework ya lo usa)
    TriggerClientEvent('QBCore:Client:OnDuty', src)  -- opcional, si tu base lo usa
    Player.Functions.SetJobDuty(not Player.PlayerData.job.onduty)
    -- devolver nuevo conteo a todos
    local count = 0
    for _, s in pairs(QBCore.Functions.GetPlayers()) do
        local p = QBCore.Functions.GetPlayer(s)
        if p and p.PlayerData.job.name == Config.AllowedJob and p.PlayerData.job.onduty then
            count = count + 1
        end
    end
    for _, s in pairs(QBCore.Functions.GetPlayers()) do
        TriggerClientEvent('sh-mdt:client:setOnDutyCount', s, count)
    end
end)
