local QBCore = exports['qb-core']:GetCoreObject()

-- 🔥 NUEVO: Función auxiliar para formatear tipos de licencia
local function formatearTipoLicencia(tipo)
    return Config.Licencias.LicenciasTradicionales[tipo] or string.upper(tipo)
end

-- 🔥 NUEVO: Función para sincronizar licencias del inventario
local function sincronizarLicenciasInventario(ciudadanoId, citizenid, result)
    local playerData = MySQL.single.await("SELECT inventory FROM players WHERE citizenid = ?", { citizenid })
    if not playerData or not playerData.inventory then return end
    
    local inventory = json.decode(playerData.inventory)
    if not inventory then return end
    
    for _, item in pairs(inventory) do
        if item and item.name and Config.Licencias.LicenciasInventario[item.name] then
            local tipoLicencia = Config.Licencias.LicenciasInventario[item.name]
            
            -- Verificar si ya existe
            local existe = MySQL.scalar.await([[
                SELECT COUNT(*) FROM sh_mdt_licencias 
                WHERE ciudadano_id = ? AND tipo = ?
            ]], { ciudadanoId, tipoLicencia })
            
            if existe == 0 then
                MySQL.insert.await([[
                    INSERT IGNORE INTO sh_mdt_licencias (ciudadano_id, tipo, estado) 
                    VALUES (?, ?, ?)
                ]], { ciudadanoId, tipoLicencia, "VÁLIDA" })
                table.insert(result, {
                    type = tipoLicencia,
                    status = "VÁLIDA"
                })
            end
        end
    end
end

-- Buscar ciudadanos (VERSIÓN CORREGIDA - EVITA DUPLICADOS)
QBCore.Functions.CreateCallback('sh-mdt:server:buscarCiudadanos', function(source, cb, query)
    local like = "%" .. query .. "%"
    
    -- Buscar directamente en players para obtener datos actualizados
    local players = MySQL.query.await([[
        SELECT citizenid, charinfo
        FROM players
        WHERE LOWER(JSON_UNQUOTE(JSON_EXTRACT(charinfo, '$.firstname'))) LIKE LOWER(?) 
           OR LOWER(JSON_UNQUOTE(JSON_EXTRACT(charinfo, '$.lastname'))) LIKE LOWER(?)
        LIMIT 30
    ]], { like, like })

    local result = {}
    
    for _, p in ipairs(players or {}) do
        local info = json.decode(p.charinfo)
        
        -- 🔥 PRIMERO BUSCAR SI YA EXISTE ESTE CIUDADANO
        local ciudadanoExistente = MySQL.single.await("SELECT id FROM sh_mdt_ciudadanos WHERE identifier = ?", { p.citizenid })
        
        if ciudadanoExistente then
            -- 🔥 SI EXISTE: ACTUALIZAR DATOS Y USAR EL ID EXISTENTE
            MySQL.update.await([[
                UPDATE sh_mdt_ciudadanos 
                SET nombre = ?, apellido = ?, fecha_nac = ?, nacionalidad = ?, altura = ?
                WHERE identifier = ?
            ]], {
                info.firstname, info.lastname, info.birthdate or nil, info.nationality or 'Desconocida', info.height or 0,
                p.citizenid
            })
            
            table.insert(result, {
                id = ciudadanoExistente.id,  -- 🔥 USAR EL ID EXISTENTE
                nombre = info.firstname,
                apellido = info.lastname
            })
        else
            -- 🔥 SI NO EXISTE: CREAR NUEVO REGISTRO
            local insertResult = MySQL.insert.await([[
                INSERT INTO sh_mdt_ciudadanos (identifier, nombre, apellido, fecha_nac, nacionalidad, altura)
                VALUES (?, ?, ?, ?, ?, ?)
            ]], {
                p.citizenid, info.firstname, info.lastname, info.birthdate or nil, info.nationality or 'Desconocida', info.height or 0
            })
            
            if insertResult then
                table.insert(result, {
                    id = insertResult,
                    nombre = info.firstname,
                    apellido = info.lastname
                })
            end
        end
    end

    -- Si no hay resultados de players, buscar en sh_mdt_ciudadanos
    if #result == 0 then
        result = MySQL.query.await([[
            SELECT id, nombre, apellido 
            FROM sh_mdt_ciudadanos
            WHERE LOWER(nombre) LIKE LOWER(?) OR LOWER(apellido) LIKE LOWER(?)
            LIMIT 30
        ]], { like, like })
    end

    cb(result or {})
end)


-- Obtener perfil completo (VERSIÓN CORREGIDA)
QBCore.Functions.CreateCallback('sh-mdt:server:getCiudadanoPerfil', function(source, cb, id)
    --print("DEBUG - Buscando perfil con ID:", id)
    

    local perfil = MySQL.single.await("SELECT * FROM sh_mdt_ciudadanos WHERE id = ?", { id })
    if not perfil then 
        --print("DEBUG - No se encontró perfil para ID:", id)
        return cb(nil) 
    end

    perfil.id = id

    -- Obtener datos adicionales desde la tabla players
    local playerData = MySQL.single.await("SELECT charinfo, job, money, citizenid FROM players WHERE citizenid = ?", { perfil.identifier })
    if playerData then
        local info = json.decode(playerData.charinfo or "{}")
        perfil.telefono = info.phone or "Desconocido"
        perfil.cuenta_bancaria = info.account or "N/A"
        perfil.job = playerData.job and json.decode(playerData.job).label or "Desempleado"
        perfil.genero = info.gender == 0 and "Masculino" or info.gender == 1 and "Femenino" or "Desconocido"
        
        -- 🔥 AGREGAR SERVER_ID
        local serverId = "No en línea"
        for _, player in ipairs(GetPlayers()) do
            local playerSrc = tonumber(player)
            local xPlayer = QBCore.Functions.GetPlayer(playerSrc)
            if xPlayer and xPlayer.PlayerData.citizenid == perfil.identifier then
                serverId = tostring(playerSrc)
                break
            end
        end
        perfil.server_id = serverId
    else
        perfil.telefono = "Desconocido"
        perfil.cuenta_bancaria = "N/A" 
        perfil.job = "Desempleado"
        perfil.genero = perfil.genero or "Desconocido"
        perfil.server_id = "No disponible" -- 🔥 AGREGAR TAMBIÉN AQUÍ
    end

    -- Obtener notas (desde sh_mdt_notas)
    local notas = MySQL.query.await("SELECT id, titulo, texto, fecha FROM sh_mdt_notas WHERE ciudadano_id = ?", { id })
    perfil.notas = notas or {}

    -- Obtener multas/cargos (desde sh_mdt_cargos)  
    local cargos = MySQL.query.await("SELECT id, articulo_codigo, descripcion, fecha, estado FROM sh_mdt_cargos WHERE ciudadano_id = ?", { id })
    perfil.cargos = cargos or {}

    --print("DEBUG - Perfil enviado al cliente:")
    --print("- Server ID:", perfil.server_id)
    --print("- Notas encontradas:", #perfil.notas)
    --print("- Multas encontradas:", #perfil.cargos)
    cb(perfil)
end)

-- Añadir cargo/multa (ACTUALIZADO CON MONTO)
RegisterNetEvent('sh-mdt:server:addCargo', function(id, articulo, descripcion, monto)
    local montoNum = tonumber(monto) or 0
    
    -- Insertar el cargo en el MDT con estado "Impago" por defecto Y MONTO
    MySQL.insert("INSERT INTO sh_mdt_cargos (ciudadano_id, articulo_codigo, descripcion, estado, monto) VALUES (?, ?, ?, 'Impago', ?)", {
        id, articulo, descripcion, montoNum
    })
end)

-- Actualizar flags
RegisterNetEvent('sh-mdt:server:updateFlags', function(id, peligroso, captura)
    MySQL.update("UPDATE sh_mdt_ciudadanos SET peligroso = ?, captura = ? WHERE id = ?", { peligroso, captura, id })
end)

QBCore.Functions.CreateCallback('sh-mdt:server:getTabData', function(source, cb, data)
    local id = data.id
    local tab = data.tab
    if not id then return cb({}) end

    local result = {}

    -- Obtener el citizenid del ciudadano
    local ciudadano = MySQL.single.await("SELECT identifier FROM sh_mdt_ciudadanos WHERE id = ?", { id })
    if not ciudadano then return cb({}) end

if tab == "vehiculos" then
    -- 🔥 Leer directamente desde la tabla principal de QB-Core
    result = MySQL.query.await([[
        SELECT plate, vehicle AS model 
        FROM player_vehicles
        WHERE citizenid = ?
    ]], { ciudadano.identifier })

    -- Si querés que también aparezca el nombre del dueño (por ejemplo en el MDT general)
    for _, v in ipairs(result or {}) do
        v.nombre = perfil and perfil.nombre or "Desconocido"
        v.apellido = perfil and perfil.apellido or ""
    end
        
elseif tab == "licencias" then
    result = MySQL.query.await("SELECT tipo as type, estado as status FROM sh_mdt_licencias WHERE ciudadano_id = ?", { id })
    
    -- Si no hay licencias, sincronizar
    if #result == 0 then
        local playerData = MySQL.single.await("SELECT metadata, inventory FROM players WHERE citizenid = ?", { ciudadano.identifier })
        
        if playerData then
            -- Licencias tradicionales
            if playerData.metadata then
                local metadata = json.decode(playerData.metadata)
                if metadata.licences then
                    for licenseType, status in pairs(metadata.licences) do
                        if status then
                            local tipoFormateado = formatearTipoLicencia(licenseType)
                            local estado = status and "VÁLIDA" or "SUSPENDIDA"
                            MySQL.insert.await([[
                                INSERT IGNORE INTO sh_mdt_licencias (ciudadano_id, tipo, estado) 
                                VALUES (?, ?, ?)
                            ]], { id, tipoFormateado, estado })
                            table.insert(result, {
                                type = tipoFormateado,
                                status = estado
                            })
                        end
                    end
                end
            end
            
            -- 🔥 NUEVO: Licencias del inventario
            sincronizarLicenciasInventario(id, ciudadano.identifier, result)
        end
    end
        
elseif tab == "armas" then
    -- 🔥 SOLUCIÓN SIMPLE: SIEMPRE sincronizar con el inventario actual
    local playerData = MySQL.single.await("SELECT inventory FROM players WHERE citizenid = ?", { ciudadano.identifier })
    local armasCount = 0
    
    -- Primero limpiar armas antiguas de este ciudadano
    MySQL.query.await("DELETE FROM sh_mdt_armas WHERE ciudadano_id = ?", { id })
    
    if playerData and playerData.inventory then
        local inventory = json.decode(playerData.inventory)
        
        for _, item in pairs(inventory or {}) do
            if item and item.name then
                local itemInfo = QBCore.Shared.Items[item.name]
                if itemInfo then
                    -- Verificar si es arma (mismo método que ya tenías)
                    local isWeapon = itemInfo.weapon or 
                                    string.find(string.lower(item.name), "weapon_") or
                                    string.find(string.lower(itemInfo.label or ""), "arma") or
                                    string.find(string.lower(itemInfo.label or ""), "pistol") or
                                    string.find(string.lower(itemInfo.label or ""), "rifle") or
                                    string.find(string.lower(itemInfo.label or ""), "shotgun")
                    
                    if isWeapon then
                        armasCount = armasCount + 1
                        
                        -- 🔥 INSERTAR SIEMPRE (sin IGNORE)
                        MySQL.insert.await([[
                            INSERT INTO sh_mdt_armas (ciudadano_id, tipo_arma, serial) 
                            VALUES (?, ?, ?)
                        ]], { id, itemInfo.label or item.name, item.info and item.info.serie or "N/A" })
                    end
                end
            end
        end
    end
    
    -- 🔥 Obtener las armas actualizadas
    result = MySQL.query.await("SELECT tipo_arma as weapon, serial FROM sh_mdt_armas WHERE ciudadano_id = ?", { id })
        
    elseif tab == "propiedades" then
        result = MySQL.query.await("SELECT direccion as label, valor as precio FROM sh_mdt_propiedades WHERE ciudadano_id = ?", { id })
        
        -- Si no hay propiedades, sincronizar desde apartments
        if #result == 0 then
            --print("🔍 Buscando propiedades en apartments...")
            
            -- Usar la tabla apartments con los campos correctos
            local propiedades = MySQL.query.await("SELECT label, name, type FROM apartments WHERE citizenid = ?", { ciudadano.identifier })
            --print("🏠 Propiedades encontradas en apartments:", propiedades and #propiedades or 0)
            
            if propiedades and #propiedades > 0 then
                for _, propiedad in ipairs(propiedades) do
                    -- Insertar en sh_mdt_propiedades
                    MySQL.insert.await([[
                        INSERT IGNORE INTO sh_mdt_propiedades (ciudadano_id, direccion, tipo) 
                        VALUES (?, ?, ?)
                    ]], { id, propiedad.label or propiedad.name, propiedad.type or "Apartamento" })
                end
                -- Devolver los datos formateados
                result = {}
                for _, prop in ipairs(propiedades) do
                    table.insert(result, {
                        label = prop.label or prop.name,
                        tipo = prop.type or "Apartamento",
                        precio = "N/A" -- apartments no tiene precio en la tabla
                    })
                end
            else
                --print("❌ No se encontraron propiedades en apartments")
                result = {}
            end
        end
        
    elseif tab == "notas" then
        result = MySQL.query.await("SELECT id, titulo, texto, fecha FROM sh_mdt_notas WHERE ciudadano_id = ?", { id })
        
elseif tab == "multas" then
    local multasCiudadano = MySQL.query.await([[
        SELECT id, articulo_codigo, descripcion, estado FROM sh_mdt_cargos WHERE ciudadano_id = ?
    ]], { id })
    
    -- Verificar cada multa y actualizar estado
    for _, multa in ipairs(multasCiudadano or {}) do
        local razonBuscada = "Multa: " .. multa.descripcion
        
        local existeFactura = MySQL.scalar.await([[
            SELECT COUNT(*) FROM player_facturas 
            WHERE receiver_citizenid = ? AND razon = ?
        ]], { ciudadano.identifier, razonBuscada })
        
        if existeFactura > 0 then
            -- Si EXISTE factura, está IMPAGA (la factura sigue pendiente)
            MySQL.update('UPDATE sh_mdt_cargos SET estado = "Impago" WHERE id = ?', { multa.id })
        else
            -- Si NO existe factura, está PAGADA (la factura se eliminó al pagarse)
            MySQL.update('UPDATE sh_mdt_cargos SET estado = "Pagado" WHERE id = ?', { multa.id })
        end
    end
    
    -- 🔥 ACTUALIZADO: Obtener multas con monto incluido
    result = MySQL.query.await("SELECT id, articulo_codigo, descripcion, fecha, estado, monto FROM sh_mdt_cargos WHERE ciudadano_id = ?", { id })
end

    cb(result or {})
end)

-- SOLO MANTENER ESTA VERSIÓN: Editar
RegisterNetEvent('sh-mdt:server:editarNota', function(notaId, titulo, texto)
    --print("📝 Editando nota ID:", notaId, "Título:", titulo, "Texto:", texto)
    MySQL.update("UPDATE sh_mdt_notas SET titulo = ?, texto = ? WHERE id = ?", {
        titulo, texto, notaId
    })
end)

-- Eliminar multa
RegisterNetEvent('sh-mdt:server:eliminarMulta', function(multaId)
    MySQL.query('DELETE FROM sh_mdt_cargos WHERE id = ?', { multaId })
end)

-- Guardar notas
RegisterNetEvent('sh-mdt:server:guardarNotas', function(id, notas, titulo)
    local tituloNota = titulo or "Nota rápida"
    
    --print("Guardando nota - ID:", id, "Título:", tituloNota, "Texto:", notas)
    
    MySQL.insert("INSERT INTO sh_mdt_notas (ciudadano_id, titulo, texto) VALUES (?, ?, ?)", {
        id, tituloNota, notas
    })
end)

-- Eliminar nota
RegisterNetEvent('sh-mdt:server:eliminarNota', function(notaId)
    --print("🗑️ Eliminando nota de BD, ID:", notaId)
    MySQL.query('DELETE FROM sh_mdt_notas WHERE id = ?', { notaId })
end)

-- Evento para sincronizar datos iniciales
RegisterNetEvent('sh-mdt:server:syncCiudadanoData', function(ciudadanoId)
    local ciudadano = MySQL.single.await("SELECT identifier FROM sh_mdt_ciudadanos WHERE id = ?", { ciudadanoId })
    if not ciudadano then return end

    --print("🔄 Sincronizando datos para ciudadano ID:", ciudadanoId, "CitizenID:", ciudadano.identifier)

    -- Sincronizar vehículos desde player_vehicles
    local vehiculos = MySQL.query.await("SELECT plate, vehicle as model FROM player_vehicles WHERE citizenid = ?", { ciudadano.identifier })
    for _, vehiculo in ipairs(vehiculos or {}) do
        MySQL.insert.await([[
            INSERT IGNORE INTO sh_mdt_vehiculos (ciudadano_id, plate, model) 
            VALUES (?, ?, ?)
        ]], { ciudadanoId, vehiculo.plate, vehiculo.model })
    end
    --print("🚗 Vehículos sincronizados:", #vehiculos)

    -- Sincronizar propiedades desde player_houses
    local propiedades = MySQL.query.await("SELECT label, value as precio FROM player_houses WHERE citizenid = ?", { ciudadano.identifier })
    for _, propiedad in ipairs(propiedades or {}) do
        MySQL.insert.await([[
            INSERT IGNORE INTO sh_mdt_propiedades (ciudadano_id, direccion, valor) 
            VALUES (?, ?, ?)
        ]], { ciudadanoId, propiedad.label, propiedad.precio })
    end
    --print("🏠 Propiedades sincronizadas:", #propiedades)

    -- Sincronizar licencias desde metadata
    local playerData = MySQL.single.await("SELECT metadata FROM players WHERE citizenid = ?", { ciudadano.identifier })
    if playerData and playerData.metadata then
        local metadata = json.decode(playerData.metadata)
        if metadata.licences then
            for licenseType, status in pairs(metadata.licences) do
                if status then
                    MySQL.insert.await([[
                        INSERT IGNORE INTO sh_mdt_licencias (ciudadano_id, tipo, estado) 
                        VALUES (?, ?, ?)
                    ]], { ciudadanoId, string.upper(licenseType), "VÁLIDA" })
                end
            end
        end
    end

    -- Sincronizar armas desde inventory
    if playerData and playerData.inventory then
        local inventory = json.decode(playerData.inventory)
        for _, item in pairs(inventory or {}) do
            if item and item.name then
                local itemInfo = QBCore.Shared.Items[item.name]
                if itemInfo and itemInfo.weapon then
                    MySQL.insert.await([[
                        INSERT IGNORE INTO sh_mdt_armas (ciudadano_id, tipo_arma, serial) 
                        VALUES (?, ?, ?)
                    ]], { ciudadanoId, itemInfo.label or item.name, item.info and item.info.serie or "N/A" })
                end
            end
        end
    end
    --print("✅ Sincronización completada para ID:", ciudadanoId)
end)

-- 🔥 NUEVO: Evento para agregar licencia manualmente
RegisterNetEvent('sh-mdt:server:agregarLicencia', function(ciudadanoId, tipoLicencia, estado)
    estado = estado or "VÁLIDA"
    MySQL.insert.await([[
        INSERT INTO sh_mdt_licencias (ciudadano_id, tipo, estado) 
        VALUES (?, ?, ?)
        ON DUPLICATE KEY UPDATE estado = ?
    ]], { ciudadanoId, tipoLicencia, estado, estado })
end)

-- 🔥 NUEVO: Evento para suspender licencia
RegisterNetEvent('sh-mdt:server:suspenderLicencia', function(ciudadanoId, tipoLicencia)
    MySQL.update("UPDATE sh_mdt_licencias SET estado = 'SUSPENDIDA' WHERE ciudadano_id = ? AND tipo = ?", {
        ciudadanoId, tipoLicencia
    })
end)

-- 🔥 NUEVO: Evento para validar licencia  
RegisterNetEvent('sh-mdt:server:validarLicencia', function(ciudadanoId, tipoLicencia)
    MySQL.update("UPDATE sh_mdt_licencias SET estado = 'VÁLIDA' WHERE ciudadano_id = ? AND tipo = ?", {
        ciudadanoId, tipoLicencia
    })
end)

-- 🔥 NUEVO: Evento para revocar licencia
RegisterNetEvent('sh-mdt:server:revocarLicencia', function(ciudadanoId, tipoLicencia)
    MySQL.update("UPDATE sh_mdt_licencias SET estado = 'REVOCADA' WHERE ciudadano_id = ? AND tipo = ?", {
        ciudadanoId, tipoLicencia
    })
end)

-- 🔥 EVENTO SIMPLE para sincronizar armas manualmente
RegisterNetEvent('sh-mdt:server:syncArmasManual', function(ciudadanoId)
    local ciudadano = MySQL.single.await("SELECT identifier FROM sh_mdt_ciudadanos WHERE id = ?", { ciudadanoId })
    if not ciudadano then return end

    -- Forzar recarga de la pestaña de armas
    TriggerEvent('sh-mdt:server:getTabData', {id = ciudadanoId, tab = "armas"})
end)