local QBCore = exports['qb-core']:GetCoreObject()
local MySQL = MySQL

-- 🧩 Obtener evidencias del inventario del jugador
QBCore.Functions.CreateCallback('informes:getPlayerEvidencias', function(source, cb)
    local Player = QBCore.Functions.GetPlayer(source)
    if not Player then return cb({ fotos = {}, informes = {} }) end

    local fotos, informes = {}, {}
    for slot, item in pairs(Player.PlayerData.items or {}) do
        if item.name == 'fotos_pol' then
            fotos[#fotos+1] = {
                slot = slot,
                label = item.label or 'Foto Policial',
                image = item.image or 'fotos.png',
                url = item.info and item.info.url or nil
            }
        elseif item.name == 'infopol_evid' then
            informes[#informes+1] = {
                slot = slot,
                label = item.label or 'Informe de Evidencias',
                image = item.image or 'infopol.png',
                url = item.info and item.info.url or nil
            }
        end
    end

    cb({ fotos = fotos, informes = informes })
end)

-- 🧠 Cache de última consulta para cada jugador
local lastQueryTime = {}

-- 📋 Obtener lista de informes (OPTIMIZADO)
QBCore.Functions.CreateCallback('sh-mdt:server:getInformes', function(source, cb, q)
    local src = source
    local now = os.time()
    if lastQueryTime[src] and now - lastQueryTime[src] < 3 then
        return cb({}) -- evita spam cada 3 seg
    end
    lastQueryTime[src] = now

    local like = (q and #q > 0) and ("%" .. q .. "%") or nil
    local limit = 50 -- ⚙️ podés subirlo a 100 si querés

    local query, params
    if like then
        query = [[
            SELECT id, creator_name, created_at, title, description, tags
            FROM sh_mdt_informespol
            WHERE title LIKE ? OR creator_name LIKE ?
            ORDER BY created_at DESC
            LIMIT ?
        ]]
        params = { like, like, limit }
    else
        query = [[
            SELECT id, creator_name, created_at, title, description, tags
            FROM sh_mdt_informespol
            ORDER BY created_at DESC
            LIMIT ?
        ]]
        params = { limit }
    end

    local rows = MySQL.query.await(query, params) or {}

    for _, r in ipairs(rows) do
        if r.tags then
            local ok, decoded = pcall(json.decode, r.tags)
            r.tags = ok and decoded or {}
        end
    end

    cb(rows)
end)

-- 💾 Guardar informe (OPTIMIZADO)
QBCore.Functions.CreateCallback('sh-mdt:server:createInforme', function(source, cb, payload)
    local src = source
    local xPlayer = QBCore.Functions.GetPlayer(src)
    if not xPlayer then return cb({ success = false, error = "no_player" }) end

    local name = ("%s %s"):format(
        xPlayer.PlayerData.charinfo.firstname,
        xPlayer.PlayerData.charinfo.lastname
    )

    payload.extra = { evidencias = payload.evidencias or {} }

    local ok, id = pcall(function()
        return MySQL.insert.await([[
            INSERT INTO sh_mdt_informespol
            (creator_identifier, creator_name, created_at, title, description, agents_involved, victims, implicated, vehicle, tags, extra)
            VALUES (?, ?, NOW(), ?, ?, ?, ?, ?, ?, ?, ?)
        ]], {
            xPlayer.PlayerData.citizenid,
            name,
            payload.title or "Sin título",
            payload.description or "",
            json.encode(payload.agents or {}),
            json.encode(payload.victims or {}),
            json.encode(payload.implicated or {}),
            payload.vehicle or "",
            json.encode(payload.tags or {}),
            json.encode(payload.extra or {})
        })
    end)

    if ok and id then
        cb({ success = true, id = id })
    else
        cb({ success = false, error = 'db_error' })
    end
end)

-- 🔍 Obtener detalle de informe por ID
QBCore.Functions.CreateCallback('sh-mdt:server:getInformeById', function(source, cb, id)
    local r = MySQL.single.await('SELECT * FROM sh_mdt_informespol WHERE id = ?', { id })
    if not r then return cb(nil) end

    -- Decodificar campos
    local fields = { 'agents_involved', 'victims', 'implicated', 'tags', 'extra' }
    for _, f in ipairs(fields) do
        if r[f] then
            local ok, decoded = pcall(json.decode, r[f])
            r[f] = ok and decoded or {}
        else
            r[f] = {}
        end
    end

    cb(r)
end)
