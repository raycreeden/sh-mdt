local QBCore = exports['qb-core']:GetCoreObject()

-- Evento para crear el item de foto
RegisterNetEvent('sh-camara:servidor:crearFotoItem', function(imageURL)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if not Player then return end
    
    -- Información de la foto
    local fotoInfo = {
        imagen_url = imageURL,
        fecha = os.date('%d/%m/%Y %H:%M:%S'),
        agente = Player.PlayerData.charinfo.firstname .. ' ' .. Player.PlayerData.charinfo.lastname,
        ciudadano = Player.PlayerData.citizenid
    }
    
    -- Agregar el item de foto al inventario SILENCIOSAMENTE
    if Player.Functions.AddItem('fotos_pol', 1, nil, fotoInfo) then
        -- Solo el ItemBox (sin notify)
        TriggerClientEvent('qb-inventory:client:ItemBox', src, QBCore.Shared.Items['fotos_pol'], 'add')
        
        -- Log en consola (opcional, solo para debugging)
    end
    -- Si no hay espacio, no hacemos nada (no mostramos error)
end)

-- Evento cuando se usa el item de cámara (SOLO PARA POLICÍAS)
QBCore.Functions.CreateUseableItem('pol_camera', function(source, item)
    local Player = QBCore.Functions.GetPlayer(source)
    if not Player then return end
    
    -- Verificar si el jugador es policía
    if Player.PlayerData.job.name ~= 'police' then
        TriggerClientEvent('QBCore:Notify', source, 'Solo el departamento de policía puede usar este equipo', 'error')
        return
    end
    
    -- Verificar si el jugador tiene el item
    local cameraItem = Player.Functions.GetItemByName('pol_camera')
    if cameraItem then
        TriggerClientEvent('sh-camara:cliente:usarCamara', source)
    else
        TriggerClientEvent('QBCore:Notify', source, Config.Camara.Mensajes.SinCamara, 'error')
    end
end)

-- Evento cuando se usa el item de foto
QBCore.Functions.CreateUseableItem('fotos_pol', function(source, item)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if not Player or not item.info then 
        return 
    end
    
    -- Enviar la información de la foto al cliente para abrir el visor
    TriggerClientEvent('sh-camara:cliente:verFoto', src, item.info.imagen_url, item.info.fecha, item.info.agente)
end)

-- Comando para administradores para dar cámara (SOLO A POLICÍAS)
QBCore.Commands.Add('darcamara', 'Dar cámara policial a un policía', {{name = 'id', help = 'ID del jugador'}}, true, function(source, args)
    local src = source
    local targetId = tonumber(args[1])
    
    if not targetId then
        TriggerClientEvent('QBCore:Notify', src, 'ID de jugador inválido', 'error')
        return
    end
    
    local Target = QBCore.Functions.GetPlayer(targetId)
    if not Target then
        TriggerClientEvent('QBCore:Notify', src, 'Jugador no encontrado', 'error')
        return
    end
    
    -- Verificar que el objetivo sea policía
    if Target.PlayerData.job.name ~= 'police' then
        TriggerClientEvent('QBCore:Notify', src, 'Solo puedes dar cámaras a miembros del departamento de policía', 'error')
        return
    end
    
    if Target.Functions.AddItem('pol_camera', 1) then
        TriggerClientEvent('qb-inventory:client:ItemBox', targetId, QBCore.Shared.Items['pol_camera'], 'add')
        TriggerClientEvent('QBCore:Notify', targetId, 'Recibiste una cámara policial', 'success')
        TriggerClientEvent('QBCore:Notify', src, 'Cámara entregada correctamente', 'success')
        
    else
        TriggerClientEvent('QBCore:Notify', src, 'Error al entregar la cámara', 'error')
    end
end, 'admin')

