local QBCore = exports['qb-core']:GetCoreObject()

-- Callback para obtener huellas del inventario del jugador
QBCore.Functions.CreateCallback('sh-evidencias:servidor:obtenerHuellas', function(source, cb)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    local huellas = {}
    
    if not Player then 
        cb(huellas) 
        return 
    end
    
    local items = Player.PlayerData.items
    for slot, item in pairs(items) do
        if item.name == 'filled_evidence_bag' and item.info and item.info.type == 'fingerprint' then
            table.insert(huellas, {
                id = slot,
                fingerprint = item.info.fingerprint,
                street = item.info.street or "Ubicación desconocida",
                info = item.info
            })
        end
    end
    
    cb(huellas)
end)

-- Callback para obtener sangre del inventario del jugador
QBCore.Functions.CreateCallback('sh-evidencias:servidor:obtenerSangre', function(source, cb)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    local sangre = {}
    
    if not Player then cb(sangre) return end
    
    local items = Player.PlayerData.items
    for slot, item in pairs(items) do
        if item.name == 'filled_evidence_bag' and item.info and item.info.type == 'blood' then
            table.insert(sangre, {
                id = slot,
                citizenid = item.info.dnalabel,
                bloodtype = item.info.bloodtype,
                street = item.info.street or "Ubicación desconocida",
                info = item.info
            })
        end
    end
    
    cb(sangre)
end)

-- Callback para obtener casquillos del inventario del jugador
QBCore.Functions.CreateCallback('sh-evidencias:servidor:obtenerCasquillos', function(source, cb)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    local casquillos = {}
    
    if not Player then cb(casquillos) return end
    
    local items = Player.PlayerData.items
    for slot, item in pairs(items) do
        if item.name == 'filled_evidence_bag' and item.info and item.info.type == 'casing' then
            table.insert(casquillos, {
                id = slot,
                weapon = item.info.ammotype,
                serie = item.info.serie,
                street = item.info.street or "Ubicación desconocida",
                info = item.info
            })
        end
    end
    
    cb(casquillos)
end)

-- 🔥 NUEVA FUNCIÓN: Buscar jugador por huella (hash)
local function BuscarJugadorPorHuella(huellaHash)
    local players = QBCore.Functions.GetQBPlayers()
    
    for _, player in pairs(players) do
        if player.PlayerData.metadata and player.PlayerData.metadata.fingerprint then
            -- Crear hash de la huella del jugador para comparar
            local playerFingerprintHash = player.PlayerData.metadata.fingerprint
            
            -- Si la huella coincide exactamente
            if playerFingerprintHash == huellaHash then
                return {
                    nombre = player.PlayerData.charinfo.firstname .. " " .. player.PlayerData.charinfo.lastname,
                    ciudadano = player.PlayerData.citizenid,
                    esNPC = false
                }
            end
            
            -- También verificar si el hash contiene el citizenid (por si acaso)
            if string.find(huellaHash, player.PlayerData.citizenid) then
                return {
                    nombre = player.PlayerData.charinfo.firstname .. " " .. player.PlayerData.charinfo.lastname,
                    ciudadano = player.PlayerData.citizenid,
                    esNPC = false
                }
            end
        end
    end
    
    return nil
end

-- 🔥 NUEVA FUNCIÓN: Buscar jugador por ADN (hash)
local function BuscarJugadorPorADN(dnaHash)
    local players = QBCore.Functions.GetQBPlayers()
    
    for _, player in pairs(players) do
        local playerCitizenId = player.PlayerData.citizenid
        
        -- Verificar coincidencia directa
        if dnaHash == playerCitizenId then
            return {
                nombre = player.PlayerData.charinfo.firstname .. " " .. player.PlayerData.charinfo.lastname,
                ciudadano = playerCitizenId,
                esNPC = false
            }
        end
        
        -- Verificar si el hash contiene el citizenid
        if string.find(dnaHash, playerCitizenId) then
            return {
                nombre = player.PlayerData.charinfo.firstname .. " " .. player.PlayerData.charinfo.lastname,
                ciudadano = playerCitizenId,
                esNPC = false
            }
        end
        
        -- Crear hash del citizenid para comparar (como lo hace tu sistema)
        local testHash = string.gsub(playerCitizenId, ".", function(c)
            return string.format('%02x', string.byte(c))
        end)
        
        if testHash == dnaHash then
            return {
                nombre = player.PlayerData.charinfo.firstname .. " " .. player.PlayerData.charinfo.lastname,
                ciudadano = playerCitizenId,
                esNPC = false
            }
        end
    end
    
    return nil
end

-- 🔥 FUNCIÓN ACTUALIZADA: Obtener información del ciudadano
local function ObtenerInfoCiudadano(identificador, tipo)
    if not identificador then
        return {
            nombre = "NO IDENTIFICADO",
            ciudadano = "DESCONOCIDO",
            esNPC = true
        }
    end
    
    -- 🔥 BUSCAR JUGADOR SEGÚN EL TIPO DE IDENTIFICADOR
    local infoJugador = nil
    
    if tipo == "huella" then
        infoJugador = BuscarJugadorPorHuella(identificador)
    elseif tipo == "sangre" then
        infoJugador = BuscarJugadorPorADN(identificador)
    end
    
    -- Si encontramos un jugador
    if infoJugador then
        return infoJugador
    end
    
    -- Si empieza con "NPC_" es un NPC
    if string.sub(identificador, 1, 4) == "NPC_" then
        return {
            nombre = "CIUDADANO NO REGISTRADO (NPC)",
            ciudadano = identificador,
            esNPC = true
        }
    end
    
    -- Si es un hash largo (probablemente ADN/huella de jugador pero no encontrado)
    if string.len(identificador) >= 20 then
        return {
            nombre = "CIUDADANO NO IDENTIFICADO",
            ciudadano = "CÓDIGO: " .. string.sub(identificador, 1, 8) .. "...",
            esNPC = false  -- Es jugador pero no lo encontramos
        }
    end
    
    -- Si no se encuentra
    return {
        nombre = "CIUDADANO NO REGISTRADO",
        ciudadano = identificador,
        esNPC = true
    }
end

-- 🔥 FUNCIÓN CORREGIDA: Obtener información del arma por serial
local function ObtenerInfoArma(serial)
    if not serial or serial == "Serial no visible" or serial == "NO DISPONIBLE" then
        return {
            propietario = "NO IDENTIFICADO",
            arma = "DESCONOCIDA",
            arma_label = "DESCONOCIDA"
        }
    end
    
    -- Buscar en todos los jugadores el arma con ese serial
    local players = QBCore.Functions.GetQBPlayers()
    for _, player in pairs(players) do
        if player.PlayerData.items then
            for _, item in pairs(player.PlayerData.items) do
                if item.info and item.info.serie == serial then
                    -- 🔥 OBTENER EL LABEL DEL ARMA
                    local armaLabel = "DESCONOCIDA"
                    if QBCore.Shared.Items[item.name] then
                        armaLabel = QBCore.Shared.Items[item.name].label or item.name
                    else
                        armaLabel = item.name
                    end
                    
                    return {
                        propietario = player.PlayerData.charinfo.firstname .. " " .. player.PlayerData.charinfo.lastname,
                        ciudadano = player.PlayerData.citizenid,
                        arma = item.name,
                        arma_label = armaLabel
                    }
                end
            end
        end
    end
    
    return {
        propietario = "NO IDENTIFICADO", 
        arma = "DESCONOCIDA",
        arma_label = "DESCONOCIDA"
    }
end

-- 🔥 NUEVA FUNCIÓN: Obtener nombre del arma desde el tipo
local function ObtenerNombreArma(tipoArma)
    if not tipoArma or tipoArma == "DESCONOCIDA" then
        return "DESCONOCIDA"
    end
    
    -- Buscar en las armas compartidas de QBCore
    for weaponName, weaponData in pairs(QBCore.Shared.Items) do
        if weaponName == tipoArma then
            return weaponData.label or weaponName
        end
    end
    
    return tipoArma
end

-- Evento para crear informe de huella
RegisterNetEvent('sh-evidencias:servidor:crearInformeHuella')
AddEventHandler('sh-evidencias:servidor:crearInformeHuella', function(huella)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if not Player then return end
    
    -- Verificar por slot específico
    local itemData = Player.Functions.GetItemBySlot(huella.id)
    if not itemData or itemData.name ~= 'filled_evidence_bag' then
        TriggerClientEvent('QBCore:Notify', src, 'Ya no tienes esta evidencia en tu inventario', 'error')
        return
    end
    
    -- Obtener información del propietario de la huella
    local infoPropietario = ObtenerInfoCiudadano(huella.fingerprint, "huella")
    
    -- Crear información del informe
    local informeInfo = {
        tipo = "HUELLA DIGITAL",
        fecha = os.date('%d/%m/%Y %H:%M:%S'),
        agente = Player.PlayerData.charinfo.firstname .. " " .. Player.PlayerData.charinfo.lastname,
        
        -- Información específica de huella
        codigo_huella = huella.fingerprint or "NO DISPONIBLE",
        propietario = infoPropietario.nombre,
        ciudadano = infoPropietario.ciudadano,
        es_npc = infoPropietario.esNPC,
        ubicacion = huella.street or "Ubicación desconocida"
    }
    
    -- Crear el item de informe
    if Player.Functions.AddItem('infopol_evid', 1, nil, informeInfo) then
        -- Remover por slot específico
        Player.Functions.RemoveItem('filled_evidence_bag', 1, huella.id)
        TriggerClientEvent('qb-inventory:client:ItemBox', src, QBCore.Shared.Items['infopol_evid'], 'add')
        TriggerClientEvent('QBCore:Notify', src, Config.AnalisisEvidencias.Mensajes.EvidenciaCreada, 'success')
        
        print(string.format('[SH-EVIDENCIAS] %s creó informe de huella: %s -> %s', 
            GetPlayerName(src), huella.fingerprint, infoPropietario.nombre))
    else
        TriggerClientEvent('QBCore:Notify', src, Config.AnalisisEvidencias.Mensajes.Error, 'error')
    end
end)

-- Evento para crear informe de sangre
RegisterNetEvent('sh-evidencias:servidor:crearInformeSangre')
AddEventHandler('sh-evidencias:servidor:crearInformeSangre', function(sangre)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if not Player then return end
    
    -- Verificar por slot específico
    local itemData = Player.Functions.GetItemBySlot(sangre.id)
    if not itemData or itemData.name ~= 'filled_evidence_bag' then
        TriggerClientEvent('QBCore:Notify', src, 'Ya no tienes esta evidencia en tu inventario', 'error')
        return
    end
    
    -- Obtener información del propietario de la sangre
    local infoPropietario = ObtenerInfoCiudadano(sangre.citizenid, "sangre")
    
    -- Crear información del informe
    local informeInfo = {
        tipo = "MUESTRA DE SANGRE",
        fecha = os.date('%d/%m/%Y %H:%M:%S'),
        agente = Player.PlayerData.charinfo.firstname .. " " .. Player.PlayerData.charinfo.lastname,
        
        -- Información específica de sangre
        tipo_sangre = sangre.bloodtype or "NO IDENTIFICADO",
        codigo_adn = sangre.citizenid,
        propietario = infoPropietario.nombre,
        ciudadano = infoPropietario.ciudadano,
        es_npc = infoPropietario.esNPC,
        ubicacion = sangre.street or "Ubicación desconocida"
    }
    
    -- Crear el item de informe
    if Player.Functions.AddItem('infopol_evid', 1, nil, informeInfo) then
        -- Remover por slot específico
        Player.Functions.RemoveItem('filled_evidence_bag', 1, sangre.id)
        TriggerClientEvent('qb-inventory:client:ItemBox', src, QBCore.Shared.Items['infopol_evid'], 'add')
        TriggerClientEvent('QBCore:Notify', src, Config.AnalisisEvidencias.Mensajes.EvidenciaCreada, 'success')
        
        print(string.format('[SH-EVIDENCIAS] %s creó informe de sangre: %s -> %s', 
            GetPlayerName(src), sangre.citizenid, infoPropietario.nombre))
    else
        TriggerClientEvent('QBCore:Notify', src, Config.AnalisisEvidencias.Mensajes.Error, 'error')
    end
end)

-- 🔥 EVENTO CORREGIDO: Crear informe de casquillo
RegisterNetEvent('sh-evidencias:servidor:crearInformeCasquillo')
AddEventHandler('sh-evidencias:servidor:crearInformeCasquillo', function(casquillo)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if not Player then return end
    
    -- Verificar por slot específico
    local itemData = Player.Functions.GetItemBySlot(casquillo.id)
    if not itemData or itemData.name ~= 'filled_evidence_bag' then
        TriggerClientEvent('QBCore:Notify', src, 'Ya no tienes esta evidencia en tu inventario', 'error')
        return
    end
    
    -- Obtener información del arma
    local infoArma = ObtenerInfoArma(casquillo.serie)
    
    -- 🔥 OBTENER EL NOMBRE DEL ARMA USANDO EL LABEL
    local nombreArma = ObtenerNombreArma(casquillo.weapon)
    
    -- Crear información del informe
    local informeInfo = {
        tipo = "CASQUILLO DE BALA",
        fecha = os.date('%d/%m/%Y %H:%M:%S'),
        agente = Player.PlayerData.charinfo.firstname .. " " .. Player.PlayerData.charinfo.lastname,
        
        -- Información específica de casquillo
        tipo_arma = nombreArma, -- 🔥 USAR EL LABEL EN LUGAR DEL NAME
        serial_arma = casquillo.serie or "NO DISPONIBLE",
        propietario_arma = infoArma.propietario,
        ciudadano_arma = infoArma.ciudadano or "NO IDENTIFICADO",
        nombre_arma = infoArma.arma_label, -- 🔥 USAR EL LABEL EN LUGAR DEL NAME
        ubicacion = casquillo.street or "Ubicación desconocida"
    }
    
    -- Crear el item de informe
    if Player.Functions.AddItem('infopol_evid', 1, nil, informeInfo) then
        -- Remover por slot específico
        Player.Functions.RemoveItem('filled_evidence_bag', 1, casquillo.id)
        TriggerClientEvent('qb-inventory:client:ItemBox', src, QBCore.Shared.Items['infopol_evid'], 'add')
        TriggerClientEvent('QBCore:Notify', src, Config.AnalisisEvidencias.Mensajes.EvidenciaCreada, 'success')
        
        print(string.format('[SH-EVIDENCIAS] %s creó informe de casquillo: %s -> %s', 
            GetPlayerName(src), nombreArma, infoArma.propietario))
    else
        TriggerClientEvent('QBCore:Notify', src, Config.AnalisisEvidencias.Mensajes.Error, 'error')
    end
end)

-- Evento para usar el item de informe
QBCore.Functions.CreateUseableItem('infopol_evid', function(source, item)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if not Player or not item.info then return end
    
    -- Verificar que la información del informe existe
    if not item.info.tipo then
        TriggerClientEvent('QBCore:Notify', src, 'Informe corrupto o sin datos', 'error')
        return
    end
    
    -- Mostrar información del informe en un mensaje
    local mensaje = string.format(
        "=== INFORME POLICIAL ===\n" ..
        "Tipo: %s\n" ..
        "Fecha: %s\n" ..
        "Agente: %s\n" ..
        "Ubicación: %s\n",
        item.info.tipo or "N/A",
        item.info.fecha or "N/A", 
        item.info.agente or "N/A",
        item.info.ubicacion or "N/A"
    )
    
    -- Agregar información específica según el tipo
    if item.info.tipo == "HUELLA DIGITAL" then
        mensaje = mensaje .. string.format(
            "Código Huella: %s\n" ..
            "Propietario: %s\n" ..
            "Ciudadano: %s\n" ..
            "Tipo: %s",
            item.info.codigo_huella or "N/A",
            item.info.propietario or "N/A",
            item.info.ciudadano or "N/A",
            item.info.es_npc and "NPC" or "CIUDADANO"
        )
    elseif item.info.tipo == "MUESTRA DE SANGRE" then
        mensaje = mensaje .. string.format(
            "Tipo Sangre: %s\n" ..
            "Código ADN: %s\n" ..
            "Propietario: %s\n" ..
            "Tipo: %s",
            item.info.tipo_sangre or "N/A",
            item.info.codigo_adn or "N/A",
            item.info.propietario or "N/A", 
            item.info.es_npc and "NPC" or "CIUDADANO"
        )
    elseif item.info.tipo == "CASQUILLO DE BALA" then
        mensaje = mensaje .. string.format(
            "Tipo Arma: %s\n" ..
            "Serial Arma: %s\n" ..
            "Propietario: %s\n" ..
            "Arma: %s",
            item.info.tipo_arma or "N/A",
            item.info.serial_arma or "N/A",
            item.info.propietario_arma or "N/A",
            item.info.nombre_arma or "N/A"
        )
    end
    
    TriggerClientEvent('QBCore:Notify', src, mensaje, 'primary', 10000)
    
    -- También mostrar en consola para debugging
    print(string.format("[SH-EVIDENCIAS] %s revisó informe: %s", 
        GetPlayerName(src), item.info.tipo or "N/A"))
end)