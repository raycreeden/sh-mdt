local QBCore = exports['qb-core']:GetCoreObject()

-- Puedes agregar logs o permisos aquí si necesitas