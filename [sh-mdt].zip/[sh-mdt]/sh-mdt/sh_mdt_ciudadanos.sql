

CREATE TABLE `sh_mdt_ciudadanos` (
  `id` int(11) NOT NULL,
  `identifier` varchar(50) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `apellido` varchar(100) DEFAULT NULL,
  `fecha_nac` date DEFAULT NULL,
  `nacionalidad` varchar(50) DEFAULT NULL,
  `altura` int(11) DEFAULT NULL,
  `peligroso` tinyint(1) DEFAULT 0,
  `captura` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

CREATE TABLE IF NOT EXISTS `sh_mdt_notas` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `ciudadano_id` INT NOT NULL,
  `titulo` VARCHAR(100),
  `texto` TEXT,
  `fecha` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS `sh_mdt_cargos` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `ciudadano_id` INT NOT NULL,
  `articulo_codigo` VARCHAR(50),
  `descripcion` TEXT,
  `estado` VARCHAR(20) DEFAULT 'Impago',
  `monto` DECIMAL(10,2) DEFAULT 0,
  `fecha` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Primero asegurar que sh_mdt_ciudadanos tenga PRIMARY KEY
ALTER TABLE `sh_mdt_ciudadanos` 
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY;

CREATE TABLE IF NOT EXISTS `sh_mdt_vehiculos_busqueda` (
  `plate` VARCHAR(20) NOT NULL,
  `busqueda` TINYINT(1) NOT NULL DEFAULT 0,
  `last_update` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`plate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `player_vehicles`
ADD COLUMN busqueda TINYINT(1) NOT NULL DEFAULT 0 AFTER citizenid;


-- Tabla para licencias en MDT
CREATE TABLE IF NOT EXISTS `sh_mdt_licencias` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `ciudadano_id` INT NOT NULL,
  `tipo` VARCHAR(50),
  `estado` VARCHAR(50),
  `fecha_emision` DATE,
  `fecha_vencimiento` DATE,
  FOREIGN KEY (ciudadano_id) REFERENCES sh_mdt_ciudadanos(id)
);

-- 🔫 Tabla de armas registradas en el MDT
CREATE TABLE IF NOT EXISTS `sh_mdt_armas` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `ciudadano_id` INT NOT NULL,
  `tipo_arma` VARCHAR(100) DEFAULT NULL,
  `serial` VARCHAR(100) NOT NULL,
  `fecha_registro` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_serial` (`serial`),                
  INDEX `idx_ciudadano_id` (`ciudadano_id`),    
  FOREIGN KEY (`ciudadano_id`) REFERENCES `sh_mdt_ciudadanos`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 🚨 Tabla para registrar si un arma está marcada como robada
CREATE TABLE IF NOT EXISTS `sh_mdt_armarob` (
  `serial` VARCHAR(100) NOT NULL,
  `robada` TINYINT(1) NOT NULL DEFAULT 0,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`serial`)                       
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla para propiedades en MDT
CREATE TABLE IF NOT EXISTS `sh_mdt_propiedades` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `ciudadano_id` INT NOT NULL,
  `direccion` VARCHAR(200),
  `tipo` VARCHAR(50),
  `valor` DECIMAL(15,2),
  `fecha_compra` DATE,
  FOREIGN KEY (ciudadano_id) REFERENCES sh_mdt_ciudadanos(id)
);

CREATE TABLE IF NOT EXISTS `sh_mdt_tiempos` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `ciudadano_id` INT NOT NULL,
  `servicio` VARCHAR(50) NOT NULL,
  `fecha_inicio` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `fecha_fin` TIMESTAMP NULL,
  `tiempo_total` INT DEFAULT 0 COMMENT 'Tiempo en segundos',
  `estado` VARCHAR(20) DEFAULT 'Activo'
);

-- Ejecuta esto en tu phpMyAdmin o gestor de BD:
CREATE TABLE IF NOT EXISTS `sh_mdt_federal` (
  `citizenid` VARCHAR(50) NOT NULL,
  `time` INT(11) NOT NULL,
  `initial` INT(11) NOT NULL,
  `name` VARCHAR(100) NOT NULL,
  `date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`citizenid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

CREATE TABLE IF NOT EXISTS `codigo_penal` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `codigo` VARCHAR(64) NOT NULL,
  `descripcion` TEXT NOT NULL,
  `monto` INT DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `sh_mdt_informespol` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `creator_identifier` VARCHAR(50) NOT NULL, 
  `creator_name` VARCHAR(150) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `report_date` DATE DEFAULT NULL,
  `report_time` TIME DEFAULT NULL,
  `title` VARCHAR(200) DEFAULT NULL,
  `description` TEXT,
  `agents_involved` JSON DEFAULT NULL,  
  `victims` JSON DEFAULT NULL,          
  `implicated` JSON DEFAULT NULL,      
  `vehicle` VARCHAR(200) DEFAULT NULL,
  `tags` JSON DEFAULT NULL,            
  `extra` JSON DEFAULT NULL,
  
  KEY `idx_created_at` (`created_at` DESC),
  KEY `idx_creator_name` (`creator_name`(100)),
  KEY `idx_title` (`title`(100)),
  
  FULLTEXT KEY `ft_title_creator_desc` (`title`, `creator_name`, `description`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `sh_mdt_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tag_type` varchar(50) NOT NULL,
  `tag_name` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_tag` (`tag_type`,`tag_name`)
);