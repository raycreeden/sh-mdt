window.addEventListener('message', (e) => {
  const data = e.data || {};

  if (data.action === 'open') {
    document.getElementById('wrap').classList.remove('hidden');
    document.getElementById('slogan').textContent = data.slogan || '';
  }

  if (data.action === 'close') {
    document.getElementById('wrap').classList.add('hidden');
    hideCiudadanos();
  }

  if (data.action === 'setOnDutyCount') {
    document.getElementById('onduty-count').textContent = data.count ?? 0;
  }

  if (data.action === 'ciudadanos:showResults') {
    renderCiudadanosResults(data.results || []);
  }

  // 🔥 Nuevo bloque: abrir perfil del ciudadano cuando llega desde el servidor
  if (data.action === 'ciudadanos:showProfile') {
    showCiudadanoPerfil(data.data);
  }

  // --- Cargar contenido de pestañas ---
  if (data.action === 'ciudadanos:tabData') {
    renderTabContent(data.tab, data.data);
  }

  // Recibir datos de búsqueda y captura
  if (data.action === 'busquedacaptura:showResults') {
    renderBusquedaCaptura(data.ciudadanos || []);
  }

  // Ocultar panel de búsqueda y captura
  if (data.action === 'busquedacaptura:hidePanel') {
    hideBusquedaCaptura();
  }

if (data.action === 'dashcams:stoppedSpectating') {
  restaurarSloganNormal();

  // ✅ Asegurar que el NUI vuelva a mostrarse correctamente
  document.body.style.display = "block"; // ← vuelve visible el NUI
  const wrap = document.getElementById("wrap");
  if (wrap) {
    wrap.classList.remove("hidden");
  }

    if (data.action === 'ciudadanos:refreshMultas') {
    const ciudadanoId = data.ciudadanoId;
    post('ciudadanos:getMultas', { id: ciudadanoId }, (multas) => {
      renderMultas(multas);
    });
  }
  // Opcional: enfocar el NUI otra vez si querés volver a interactuar
  fetch(`https://${GetParentResourceName()}/setFocus`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ focus: true })
  });
}



  // 🔥 Ocultar completamente el MDT (tablet)
  if (data.action === "hideAll") {
    const wrap = document.getElementById("wrap");
    if (wrap) {
      wrap.classList.add("hidden");
    }
    document.body.style.display = "none"; // Fuerza cierre total visual
  }
});


// Función post mejorada con mejor manejo de errores
function post(name, payload = {}, callback = null) {
    fetch(`https://${GetParentResourceName()}/${name}`, { 
        method:'POST', 
        headers:{'Content-Type':'application/json'}, 
        body: JSON.stringify(payload) 
    })
    .then(resp => {
        if (!resp.ok) {
            console.error(`❌ Error HTTP ${resp.status} en: ${name}`);
            throw new Error(`HTTP error! status: ${resp.status}`);
        }
        return resp.json();
    })
    .then(data => {
        if (callback) {
            callback(data);
        }
    })
    .catch(error => {
        console.error('❌ Error en post ' + name + ':', error);
        if (callback) {
            callback(null);
        }
    });
}

document.getElementById('btn-servicio').addEventListener('click', () => post('btn:servicio'));


document.getElementById('btn-ciudadanos').addEventListener('click', () => {
  document.getElementById('panel-ciudadanos').classList.remove('hidden');
  post('btn:buscar-ciudadano');
});

document.getElementById('btn-search-ciudadano').addEventListener('click', () => {
  const query = document.getElementById('ciudadano-query').value.trim();
  if (query.length >= 3) {
    post('ciudadanos:search', { query });
  } else {
    //alert("Debes ingresar al menos 3 letras.");
  }
});

function renderCiudadanosResults(list) {
  const ul = document.getElementById('ciudadano-results');
  ul.innerHTML = '';
  if (!list.length) {
    ul.innerHTML = '<li>No se encontraron resultados</li>';
    return;
  }
  list.forEach(c => {
    const li = document.createElement('li');
    li.textContent = `${c.nombre} ${c.apellido}`;
    li.onclick = () => {
      post('ciudadanos:openProfile', { id: c.id });
    };
    ul.appendChild(li);
  });
}

function hideCiudadanos() {
  document.getElementById('panel-ciudadanos').classList.add('hidden');
}

document.addEventListener('keydown', (ev) => {
  if (ev.key === 'Escape') {
    document.getElementById('wrap').classList.add('hidden');
    hideCiudadanos();
    post('close');
  }
});

window.closeMDT = () => {
  document.getElementById('wrap').classList.add('hidden');
  hideCiudadanos();
  post('close');
};

function showCiudadanoPerfil(perfil) {
  
  hideCiudadanos();
  const panel = document.getElementById('panel-ciudadano-perfil');
  panel.classList.remove('hidden');

  // 🔥 GUARDAR EL ID PERMANENTE (oculto)
  panel.setAttribute('data-ciudadano-id', perfil.id);
  
  document.getElementById('perfil-nombre').textContent = perfil.nombre || 'No disponible';
  document.getElementById('perfil-apellido').textContent = perfil.apellido || 'No disponible';
  document.getElementById('perfil-genero').textContent = perfil.genero || 'No disponible';
  document.getElementById('perfil-nacionalidad').textContent = perfil.nacionalidad || 'No disponible';
  document.getElementById('perfil-fecha').textContent = formatFechaNacimiento(perfil.fecha_nac) || 'No disponible';
  
  // 🔥 SOLO MOSTRAR SERVER ID (ocultamos el ID de BD visualmente)
  document.getElementById('perfil-id').textContent = perfil.server_id || 'No disponible';
  
  document.getElementById('perfil-telefono').textContent = perfil.telefono || 'No disponible';
  document.getElementById('perfil-cuenta').textContent = perfil.cuenta_bancaria || 'No disponible';
  document.getElementById('perfil-trabajo').textContent = perfil.job || 'No disponible';

  document.getElementById('perfil-peligroso').value = perfil.peligroso ? 1 : 0;
  document.getElementById('perfil-captura').value = perfil.captura ? 1 : 0;

  document.getElementById('tab-content').innerHTML = '<p>Selecciona una categoría.</p>';

  document.getElementById('btn-guardar-flags').onclick = () => {
    const ciudadanoId = panel.getAttribute('data-ciudadano-id');
    post('ciudadanos:updateFlags', {
      id: ciudadanoId,
      peligroso: document.getElementById('perfil-peligroso').value,
      captura: document.getElementById('perfil-captura').value,
    });
  };
}

function hideCiudadanoPerfil() {
  document.getElementById('panel-ciudadano-perfil').classList.add('hidden');
}

function showTab(tab, event) {
  const content = document.getElementById('tab-content');
  const actions = document.getElementById('tab-actions');

  content.innerHTML = `<p>Cargando ${tab}...</p>`;
  
  const ciudadanoId = document.getElementById('panel-ciudadano-perfil').getAttribute('data-ciudadano-id');
  
  post('ciudadanos:getTab', { tab, id: ciudadanoId });

  // 🔥 REMOVER clase active de todos los botones
  document.querySelectorAll('.perfil-tabs .btn.small').forEach(btn => {
    btn.classList.remove('active');
  });
  
  // 🔥 AGREGAR clase active al botón clickeado
  if (event && event.target) {
    event.target.classList.add('active');
  } else {
    document.querySelectorAll('.perfil-tabs .btn.small').forEach(btn => {
      if (btn.textContent.toLowerCase().includes(tab.toLowerCase())) {
        btn.classList.add('active');
      }
    });
  }

  // 🔥 CORREGIDO: LIMPIAR Y RECONSTRUIR LOS BOTONES DE ACCIÓN CADA VEZ
  actions.innerHTML = ''; // 🔥 LIMPIAR PRIMERO
  actions.style.display = "none";

  if (tab === "notas") {
    actions.style.display = "flex";
    
    const btnAddNota = document.createElement('button');
    btnAddNota.id = 'btn-add-nota';
    btnAddNota.className = 'btn small';
    btnAddNota.textContent = '╋ Agregar Nota';
    btnAddNota.onclick = () => {
      abrirFormularioNota();
    };
    
    actions.appendChild(btnAddNota);
  } 
else if (tab === "multas") {
  actions.style.display = "flex";

  // 🔹 Botón original: agregar multa manual
  const btnAddMulta = document.createElement('button');
  btnAddMulta.id = 'btn-add-multa';
  btnAddMulta.className = 'btn small';
  btnAddMulta.textContent = '╋ Agregar Multa';
  btnAddMulta.onclick = () => {
    const ciudadanoId = document
      .getElementById('panel-ciudadano-perfil')
      .getAttribute('data-ciudadano-id');
    post('ciudadanos:openMultaInput', { id: ciudadanoId });
  };
  actions.appendChild(btnAddMulta);

  // 🔹 NUEVO BOTÓN: Multa desde Base de Datos
  const btnMultaBD = document.createElement('button');
  btnMultaBD.id = 'btn-multa-bd';
  btnMultaBD.className = 'btn small';
  btnMultaBD.textContent = 'Multa Base de Datos';
  btnMultaBD.onclick = () => {
    const ciudadanoId = document
      .getElementById('panel-ciudadano-perfil')
      .getAttribute('data-ciudadano-id');

    // Pedir al servidor los artículos del Código Penal
    post('codigo_penal:getAll', {}, (articulos) => {
      if (!articulos || !articulos.length) {
  showTemporaryMessage("No hay artículos cargados en la base de datos.", "error");
  return;
}


      // Crear modal
      let html = `<div id="modal-multa-bd" class="modal">
        <div class="modal-content">
          <h3>Seleccionar Artículo</h3>
          <select id="select-articulo" style="width:100%; padding:0.5vw; margin-bottom:1vw;">`;

articulos.forEach(a => {
  html += `<option value="${a.id}" data-codigo="${a.codigo}" data-desc="${a.descripcion}" data-monto="${a.monto}">
    ${a.codigo} - ${a.descripcion} ($${a.monto})
  </option>`;
});

      html += `</select>
          <button id="btn-aplicar-multa-bd" class="btn small">Aplicar Multa</button>
          <button id="btn-cerrar-multa-bd" class="btn small" style="background:#555;">Cancelar</button>
        </div>
      </div>`;

      document.body.insertAdjacentHTML('beforeend', html);

      document.getElementById('btn-cerrar-multa-bd').onclick = () => {
        document.getElementById('modal-multa-bd').remove();
      };

      document.getElementById('btn-aplicar-multa-bd').onclick = () => {
        const select = document.getElementById('select-articulo');
        const opt = select.options[select.selectedIndex];
        const codigo = opt.getAttribute('data-codigo');
        const descripcion = opt.getAttribute('data-desc');
        const monto = parseInt(opt.getAttribute('data-monto'));

fetch(`https://${GetParentResourceName()}/codigo_penal:aplicarMulta`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json; charset=UTF-8' },
    body: JSON.stringify({
        ciudadanoId: ciudadanoId,
        codigo: codigo,
        descripcion: descripcion,
        monto: monto
    })
});


        document.getElementById('modal-multa-bd').remove();
        setTimeout(() => showTab('multas'), 500);
      };
    });
  };
  actions.appendChild(btnMultaBD);
}

  else if (tab === "licencias") {
    actions.style.display = "flex";
    
    const btnAddLicencia = document.createElement('button');
    btnAddLicencia.id = 'btn-add-licencia';
    btnAddLicencia.className = 'btn small btn-licencia'; // 🔥 Agregar clase específica
    btnAddLicencia.textContent = '╋ Agregar Licencia';
    btnAddLicencia.onclick = () => {
      const ciudadanoId = document.getElementById('panel-ciudadano-perfil').getAttribute('data-ciudadano-id');
      post('ciudadanos:agregarLicencia', { id: ciudadanoId });
    };
    
    actions.appendChild(btnAddLicencia);
  }
}


// En app.js - modificar la parte donde se reciben los datos de las pestañas

// 🔥 NUEVO: Función para formatear fechas
function formatFecha(fechaStr) {
  if (!fechaStr) return 'Fecha no disponible';
  const fecha = new Date(fechaStr);
  return fecha.toLocaleDateString('es-ES', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

// 🔥 NUEVO: Función para renderizar el contenido de cada pestaña
function renderTabContent(tab, data) {
    const content = document.getElementById('tab-content');
    
    if (!data || !data.length) {
        content.innerHTML = `<p style="text-align:center; color:#666; padding:2vw;">No hay ${tab} disponibles.</p>`;
        return;
    }

    let html = '';
    
if (tab === "notas") {
    data.forEach(item => {
        html += `
            <div class="nota-item">
                <div class="nota-header">
                    <div class="nota-titulo">${item.titulo || 'Nota'}</div>
                    <div class="nota-actions">
                        <button class="btn-ver-nota" onclick='verNotaCompleta(${JSON.stringify(item).replace(/'/g, "&#39;")})'>👁</button>
                        <button class="btn-editar-nota" onclick='abrirModalNota(${JSON.stringify(item).replace(/'/g, "&#39;")})'>✎</button>
                        <button class="btn-eliminar-nota" onclick="eliminarNota(${item.id})">✖</button>
                    </div>
                </div>
                <div class="nota-texto">${item.texto || ''}</div>
                <div class="nota-fecha">${formatFecha(item.fecha)}</div>
            </div>
        `;
    });
}
else if (tab === "multas") {
    data.forEach(item => {
        // 🔥 NUEVO: Obtener y formatear el monto
        const monto = item.monto || 0;
        const montoFormateado = monto.toLocaleString('es-ES');
        const estado = item.estado || 'Impago';
        const estadoClass = estado === 'Pagado' ? 'estado-pagado' : 'estado-impago';
        const estadoIcon = estado === 'Pagado' ? '' : '';
        
        html += `
            <div class="multa-item">
                <div class="nota-header">
                    <div class="multa-articulo">Artículo: ${item.articulo_codigo || 'N/A'}</div>
                    <button class="btn-eliminar-nota" onclick="eliminarMulta(${item.id})">X</button>
                </div>
                <div class="multa-descripcion">${item.descripcion || ''}</div>
                <div class="multa-info">
                    <div class="multa-monto ${estadoClass}">
                        ${estadoIcon} $${montoFormateado}
                    </div>
                    <div class="multa-estado ${estadoClass}">
                        ${estado}
                    </div>
                </div>
                <div class="multa-fecha">
                    ${formatFecha(item.fecha)}
                </div>
            </div>
        `;
    });
}
else if (tab === "vehiculos") {
    data.forEach(item => {
        html += `
            <div class="nota-item">
                <div class="vehiculo-info">
                    <div class="vehiculo-linea">
                        <span class="vehiculo-label">Matrícula:</span>
                        <span class="vehiculo-valor">${item.plate || 'N/A'}</span>
                    </div>
                    <div class="vehiculo-linea">
                        <span class="vehiculo-label">Modelo:</span>
                        <span class="vehiculo-valor">${item.model || item.name || 'N/A'}</span>
                    </div>
                </div>
            </div>
        `;
    });
}
else if (tab === "licencias") {
    data.forEach(item => {
        const estadoClass = item.status === 'VÁLIDA' ? 'estado-valida' : 
                           item.status === 'SUSPENDIDA' ? 'estado-suspendida' : 
                           item.status === 'REVOCADA' ? 'estado-revocada' : 'estado-default';
        
        html += `
            <div class="nota-item">
                <div class="licencia-info">
                    <div class="licencia-linea">
                        <span class="licencia-label">Tipo:</span>
                        <span class="licencia-valor">${item.type || item.tipo || 'N/A'}</span>
                    </div>
                    <div class="licencia-linea">
                        <span class="licencia-label">Estado:</span>
                        <span class="licencia-valor ${estadoClass}">${item.status || item.estado || 'N/A'}</span>
                    </div>
                    <div class="licencia-acciones">
    <button class="btn-accion btn-validar" onclick="cambiarEstadoLicencia('${item.type || item.tipo}', 'validar')">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="white">
            <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
        </svg>
    </button>
    <button class="btn-accion btn-suspender" onclick="cambiarEstadoLicencia('${item.type || item.tipo}', 'suspender')">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="white">
            <path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/>
        </svg>
    </button>
    <button class="btn-accion btn-revocar" onclick="cambiarEstadoLicencia('${item.type || item.tipo}', 'revocar')">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="white">
            <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>
        </svg>
    </button>
</div>
                </div>
            </div>
        `;
    });
}
else if (tab === "armas") {
    data.forEach(item => {
        const serial = item.serial || 'N/A';
        html += `
            <div class="nota-item">
                <div class="arma-info">
                    <div class="arma-linea">
                        <span class="arma-label">Arma:</span>
                        <span class="arma-valor">${item.weapon || item.tipo_arma || 'N/A'}</span>
                    </div>
                    <div class="arma-linea">
                        <span class="arma-label">Serial:</span>
                        <span class="arma-valor">${serial}</span>
                        <button class="btn small btn-copiar-serial" onclick="copiarSerial('${serial}')">Copiar</button>
                    </div>
                </div>
            </div>
        `;
    });
}
else if (tab === "propiedades") {
    data.forEach(item => {
        let propiedadHtml = `
            <div class="nota-item">
                <div class="propiedad-info">
                    <div class="propiedad-linea">
                        <span class="propiedad-label">Dirección:</span>
                        <span class="propiedad-valor">${item.label || item.direccion || 'N/A'}</span>
                    </div>
                    <div class="propiedad-linea">
                        <span class="propiedad-label">Tipo:</span>
                        <span class="propiedad-valor">${item.tipo || 'Apartamento'}</span>
                    </div>
        `;
        
        if (item.precio && item.precio !== 'N/A') {
            propiedadHtml += `
                    <div class="propiedad-linea">
                        <span class="propiedad-label">Valor:</span>
                        <span class="propiedad-valor">$${item.precio}</span>
                    </div>
            `;
        }
        
        propiedadHtml += `
                </div>
            </div>
        `;
        html += propiedadHtml;
    });
}
    content.innerHTML = html;
}


function showTemporaryMessage(text, type = "info") {
    const msg = document.createElement("div");
    msg.className = `temp-msg ${type}`;
    msg.textContent = text;
    Object.assign(msg.style, {
        position: "fixed",
        bottom: "2vw",
        right: "2vw",
        background: type === "success" ? "#0b2e4d" : "#8b1820",
        color: "#fff",
        padding: "0.8vw 1.2vw",
        borderRadius: "0.5vw",
        zIndex: "9999",
        fontWeight: "bold",
        boxShadow: "0 0 0.8vw rgba(0,0,0,0.4)"
    });
    document.body.appendChild(msg);
    setTimeout(() => msg.remove(), 2000);
}


function copiarSerial(serial) {
    if (!serial || serial === 'N/A') {
        showTemporaryMessage("❌ Serial no disponible para copiar", "error");
        return;
    }

    try {
        // ✅ Método compatible con CEF (NUI)
        const textarea = document.createElement("textarea");
        textarea.value = serial;
        textarea.style.position = "fixed";  // Evita scroll
        textarea.style.opacity = "0";       // Invisible
        document.body.appendChild(textarea);
        textarea.focus();
        textarea.select();
        const success = document.execCommand("copy");
        document.body.removeChild(textarea);

        if (success) {
            showTemporaryMessage(`Serial copiado: ${serial}`, "success");
        } else {
            showTemporaryMessage("❌ No se pudo copiar el serial", "error");
        }

    } catch (err) {
        console.error("Error al copiar serial:", err);
        showTemporaryMessage("❌ Error interno al copiar", "error");
    }
}

// 🔥 NUEVO: Función para cambiar estado de licencia
function cambiarEstadoLicencia(tipoLicencia, accion) {
    const ciudadanoId = document.getElementById('panel-ciudadano-perfil').getAttribute('data-ciudadano-id');
    
    if (accion === 'validar') {
        post('ciudadanos:validarLicencia', { id: ciudadanoId, tipo: tipoLicencia });
    } else if (accion === 'suspender') {
        post('ciudadanos:suspenderLicencia', { id: ciudadanoId, tipo: tipoLicencia });
    } else if (accion === 'revocar') {
        post('ciudadanos:revocarLicencia', { id: ciudadanoId, tipo: tipoLicencia });
    }
    
    // Recargar después de un delay
    setTimeout(() => {
        showTab('licencias');
    }, 500);
}

// 🔥 FUNCIONES PARA ELIMINAR - VERIFICAR QUE ESTÉN BIEN
function eliminarNota(notaId, ciudadanoId) {
  
  post('ciudadanos:eliminarNota', { 
    id: notaId,
    ciudadanoId: ciudadanoId 
  });
  
  // Recargar las notas después de un breve delay
  setTimeout(() => {
    showTab('notas');
  }, 300);
}

function eliminarMulta(multaId, ciudadanoId) {
  
  // ❌ ERROR: Estás llamando a 'ciudadanos:eliminarNota' en lugar de 'ciudadanos:eliminarMulta'
  post('ciudadanos:eliminarMulta', {  // 🔥 CORREGIR
    id: multaId
  });
  
  setTimeout(() => {
    showTab('multas');
  }, 300);
}


// Modificar el event listener para usar la nueva función
window.addEventListener('message', (e) => {
  const data = e.data || {};
  // ... otros actions ...
  
  if (data.action === 'ciudadanos:tabData') {
    renderTabContent(data.tab, data.data);
  }
});

function formatFechaNacimiento(fechaStr) {
  if (!fechaStr) return 'No disponible';
  
  // Si ya es una fecha legible, devolverla tal cual
  if (typeof fechaStr === 'string' && fechaStr.includes('-')) {
    return fechaStr;
  }
  
  // Si es un timestamp de MySQL (YYYY-MM-DD HH:MM:SS)
  if (typeof fechaStr === 'string' && fechaStr.includes(' ')) {
    const fechaPartes = fechaStr.split(' ')[0].split('-');
    if (fechaPartes.length === 3) {
      return `${fechaPartes[2]}/${fechaPartes[1]}/${fechaPartes[0]}`; // DD/MM/YYYY
    }
  }
  
  // Si es un timestamp numérico
  const fecha = new Date(fechaStr);
  if (isNaN(fecha.getTime())) {
    return 'No disponible';
  }
  
  return fecha.toLocaleDateString('es-ES', {
    day: '2-digit',
    month: '2-digit', 
    year: 'numeric'
  });
}

function editarNota(notaId, ciudadanoId, textoActual) {
  const nuevoTexto = prompt("Editar nota:", textoActual);
  if (nuevoTexto && nuevoTexto.trim() !== "") {
    post('ciudadanos:editarNota', { 
      id: notaId, 
      ciudadanoId: ciudadanoId, 
      texto: nuevoTexto 
    });
    setTimeout(() => {
      showTab('notas');
    }, 300);
  }
}

// Abrir modal de nota (nuevo o edición)
function abrirModalNota(nota = null) {
  const modal = document.getElementById('nota-modal');
  modal.classList.remove('hidden');

  if (nota) {
    document.getElementById('nota-modal-titulo').textContent = "🖍 Editar Nota";
    document.getElementById('nota-id').value = nota.id;
    document.getElementById('nota-titulo').value = nota.titulo;
    document.getElementById('nota-texto').value = nota.texto;
  } else {
    document.getElementById('nota-modal-titulo').textContent = "➕ Nueva Nota";
    document.getElementById('nota-id').value = "";
    document.getElementById('nota-titulo').value = "";
    document.getElementById('nota-texto').value = "";
  }
}

// Cerrar modal
function cerrarModalNota() {
  document.getElementById('nota-modal').classList.add('hidden');
}

// En la función de guardar nota del modal - BUSCAR Y REEMPLAZAR:
document.getElementById('btn-save-nota').onclick = () => {
  const id = document.getElementById('nota-id').value;
  const titulo = document.getElementById('nota-titulo').value.trim();
  const texto = document.getElementById('nota-texto').value.trim();
  
  // 🔥 CORREGIR: Usar el ID de BD en lugar del Server ID
  const ciudadanoId = document.getElementById('panel-ciudadano-perfil').getAttribute('data-ciudadano-id');

  if (!titulo || !texto) {
    //alert("Debes completar todos los campos");
    return;
  }

  if (id) {
    post('ciudadanos:editarNota', { 
      id: id, 
      titulo: titulo, 
      texto: texto 
    });
  } else {
    // 🔥 CORREGIR: Usar el ID correcto
    post('ciudadanos:guardarNotas', { id: ciudadanoId, notas: texto, titulo });
  }

  cerrarModalNota();
  setTimeout(() => showTab('notas'), 400);
};

// Cancelar
document.getElementById('btn-cancel-nota').onclick = cerrarModalNota;

// 🔥 FUNCIONES PARA EL FORMULARIO INTEGRADO
function abrirFormularioNota() {
  document.getElementById('formulario-nota').classList.remove('hidden');
  // Limpiar campos
  document.getElementById('nota-titulo').value = '';
  document.getElementById('nota-descripcion').value = '';
}

function cerrarFormularioNota() {
  document.getElementById('formulario-nota').classList.add('hidden');
}

// 🔥 REEMPLAZAR ESTA FUNCIÓN COMPLETAMENTE:
function guardarNota() {
  const titulo = document.getElementById('nota-titulo').value.trim();
  const descripcion = document.getElementById('nota-descripcion').value.trim();
  
  // 🔥 CORREGIR: Usar el ID de BD en lugar del Server ID
  const ciudadanoId = document.getElementById('panel-ciudadano-perfil').getAttribute('data-ciudadano-id');

  if (!titulo || !descripcion) {
    alert('Por favor completa ambos campos');
    return;
  }

  // Enviar al servidor
  post('ciudadanos:guardarNotaIntegrado', { 
    id: ciudadanoId,  // 🔥 Ahora envía el ID correcto
    titulo: titulo,
    nota: descripcion
  });

  // Cerrar formulario y recargar notas
  cerrarFormularioNota();
  setTimeout(() => {
    showTab('notas');
  }, 500);
}

// 🔥 NUEVO: Función para abrir modal de ver nota
function verNotaCompleta(nota) {
  
  // Llenar el modal con los datos de la nota
  document.getElementById('ver-nota-titulo').textContent = nota.titulo || 'Sin título';
  document.getElementById('ver-nota-texto').textContent = nota.texto || 'Sin contenido';
  
  // Mostrar el modal
  document.getElementById('ver-nota-modal').classList.remove('hidden');
}

// 🔥 NUEVO: Función para cerrar modal de ver nota
function cerrarVerNota() {
  document.getElementById('ver-nota-modal').classList.add('hidden');
}


// ==================================================
// SISTEMA DE TIEMPO - PANEL SEPARADO
// ==================================================

// Mostrar panel de tiempo
function showPanelTiempo() {
  hideAllPanels();
  document.getElementById('panel-tiempo').classList.remove('hidden');
  cargarTiempoOficiales();
}

// Ocultar panel de tiempo
function hidePanelTiempo() {
  document.getElementById('panel-tiempo').classList.add('hidden');
}

// En cargarTiempoOficiales - agregar verificación
function cargarTiempoOficiales() {
  const lista = document.getElementById('lista-tiempo-oficiales');
  lista.innerHTML = '<p>Cargando registros...</p>';
  
  // Primero verificar que el callback está disponible
  post('tiempo:getOficiales', {}, function(registros) {
    
    if (!registros) {
      lista.innerHTML = '<p style="text-align:center;color:red;">Error: No se pudo conectar con el servidor</p>';
      return;
    }
    
    if (registros.length === 0) {
      lista.innerHTML = '<p style="text-align:center;color:#777;">No hay registros de servicio</p>';
      return;
    }

    let html = '';
    registros.forEach(registro => {
      html += `
        <div class="nota-item">
          <div class="nota-texto" style="text-align: center; font-weight: bold; padding: 1vw;">
            ${registro.texto || 'Registro de servicio'}
          </div>
        </div>
      `;
    });

    lista.innerHTML = html;
  });
}

// Buscar oficiales - VERSIÓN CORREGIDA
function buscarTiempoOficiales() {
  const query = document.getElementById('tiempo-query').value.trim();
  
  if (query.length < 2) {
    cargarTiempoOficiales();
    return;
  }
  
  const lista = document.getElementById('lista-tiempo-oficiales');
  lista.innerHTML = '<p>Buscando...</p>';
  
  // Primero cargar todos los registros
  post('tiempo:getOficiales', {}, function(registros) {
    if (!registros || !Array.isArray(registros)) {
      lista.innerHTML = '<p style="text-align:center;color:#666;">Error en la búsqueda</p>';
      return;
    }

    // Filtrar en el frontend
    const resultados = registros.filter(registro => {
      const texto = registro.texto ? registro.texto.toLowerCase() : '';
      return texto.includes(query.toLowerCase());
    });

    if (resultados.length === 0) {
      lista.innerHTML = '<p style="text-align:center;color:#666;">No se encontraron coincidencias para: ' + query + '</p>';
      return;
    }

    let html = '';
    resultados.forEach(registro => {
      html += `
        <div class="nota-item">
          <div class="nota-texto" style="text-align: center; font-weight: bold; padding: 1vw;">
            ${registro.texto || 'Registro de servicio'}
          </div>
        </div>
      `;
    });

    lista.innerHTML = html;
  });
}
// Ocultar todos los paneles
function hideAllPanels() {
  document.getElementById('panel-ciudadanos').classList.add('hidden');
  document.getElementById('panel-ciudadano-perfil').classList.add('hidden');
  document.getElementById('panel-tiempo').classList.add('hidden');
}

// ==================================================
// SISTEMA DE BÚSQUEDA Y CAPTURA
// ==================================================

// Mostrar panel de búsqueda y captura
function showBusquedaCaptura() {
  hideAllPanels();
  document.getElementById('panel-busqueda-captura').classList.remove('hidden');
  cargarBusquedaCaptura();
}

// Ocultar panel de búsqueda y captura
function hideBusquedaCaptura() {
  document.getElementById('panel-busqueda-captura').classList.add('hidden');
}

// Cargar lista de búsqueda y captura
function cargarBusquedaCaptura() {
  const lista = document.getElementById('lista-busqueda-captura');
  lista.innerHTML = '<p style="text-align:center;padding:2vw;">Cargando personas en búsqueda y captura...</p>';
  
  post('busquedacaptura:open', {}, function(ciudadanos) {
    if (!ciudadanos || !Array.isArray(ciudadanos)) {
      lista.innerHTML = '<p style="text-align:center;color:#666;">Error al cargar los datos</p>';
      return;
    }
    
    if (ciudadanos.length === 0) {
      lista.innerHTML = '<p style="text-align:center;color:#666;">No hay personas en búsqueda y captura activa</p>';
      return;
    }

    renderBusquedaCaptura(ciudadanos);
  });
}

// Renderizar la lista de búsqueda y captura
function renderBusquedaCaptura(ciudadanos) {
  const lista = document.getElementById('lista-busqueda-captura');
  let html = '';

  ciudadanos.forEach(ciudadano => {
    const estadoOnline = ciudadano.online ? 
      '<span style="color:blue; font-weight:bold;">● EN LÍNEA</span>' : 
      '<span style="color:red; font-weight:bold;">● OFFLINE</span>';
    
    const serverIdInfo = ciudadano.server_id ? 
      ` | Server ID: ${ciudadano.server_id}` : '';

    html += `
      <div class="nota-item" style="background: #fff5f5; border-color: #570006ff;">
        <div class="nota-header">
          <div class="nota-titulo" style="color: #4b0106ff;">
            ${ciudadano.nombre} ${ciudadano.apellido}
          </div>
          <div style="font-size:0.7vw;">
            ${estadoOnline}${serverIdInfo}
          </div>
        </div>
        <div class="nota-texto">
          <strong>Nacionalidad:</strong> ${ciudadano.nacionalidad || 'No disponible'}<br>
          <strong>Fecha Nac.:</strong> ${formatFechaNacimiento(ciudadano.fecha_nac)}<br>
          <strong>Altura:</strong> ${ciudadano.altura && ciudadano.altura !== 'NULL' && ciudadano.altura !== 0 ? ciudadano.altura + ' cm' : 'No registrada'}<br>
          <strong>Peligroso:</strong> ${ciudadano.peligroso ? 'SÍ' : 'NO'}
        </div>
        <div class="nota-fecha" style="display:none;"> <!-- 🔥 AGREGAR style="display:none;" -->
           Ciudadano ID: ${ciudadano.id}
        </div>
      </div>
    `;
  });

  lista.innerHTML = html;
}

// Agregar el event listener para el botón (al inicio del archivo)
document.addEventListener('DOMContentLoaded', function() {
  // ... otros event listeners ...
  
  const btnBusquedaCaptura = document.getElementById('btn-busqueda-captura');
  if (btnBusquedaCaptura) {
    btnBusquedaCaptura.addEventListener('click', showBusquedaCaptura);
  }
});

// Actualizar la función hideAllPanels para incluir el nuevo panel
function hideAllPanels() {
  document.getElementById('panel-ciudadanos').classList.add('hidden');
  document.getElementById('panel-ciudadano-perfil').classList.add('hidden');
  document.getElementById('panel-tiempo').classList.add('hidden');
  document.getElementById('panel-busqueda-captura').classList.add('hidden');
}

// ==================================================
// SISTEMA FEDERAL - FINAL FUNCIONAL
// ==================================================

// 🔹 Mostrar panel federal
function showFederal() {
  hideAllPanels();
  document.getElementById('panel-federal').classList.remove('hidden');
  document.getElementById('federal-message').innerHTML = '';
  document.getElementById('federal-serverid').value = '';
  document.getElementById('federal-time').value = '';
  cargarListaFederal();
  post('federal:open');
}

// 🔹 Ocultar panel federal
function hideFederal() {
  document.getElementById('panel-federal').classList.add('hidden');
}

// 🔹 Solicitar lista de presos federales al cliente
function cargarListaFederal() {
  const contenedor = document.getElementById('federal-list');
  contenedor.innerHTML = '<p style="text-align:center; color:#666;">Cargando lista federal...</p>';

  post('federal:getList', {}, (data) => {
    contenedor.innerHTML = '';

    if (!data || Object.keys(data).length === 0) {
      contenedor.innerHTML = '<p style="text-align:center; color:#666;">No hay personas en federal.</p>';
      return;
    }

    for (const id in data) {
      const p = data[id];
      if (p && p.time && p.time > 0) {
        const estado = p.online ? '🔵 En línea' : '🔴 Desconectado';
        const div = document.createElement('div');
        div.classList.add('federal-item');
        div.style.padding = '0.4vw';
        div.style.borderBottom = '0.1vw solid #ccc';
        div.innerHTML = `
          <b>${p.name || 'Desconocido'}</b><br>
          CID: ${p.citizenid}<br>
          Tiempo restante: ${p.time} seg<br>
          Estado: ${estado}
          <br><button class="btn-liberar-federal" onclick="liberarFederal('${p.citizenid}')">Liberar</button>
        `;

        contenedor.appendChild(div);
      }
    }
  });
}

// 🔹 Liberar preso federal (sin ventana emergente)
function liberarFederal(citizenid) {
  post('federal:liberar', { citizenid }, (ok) => {
    const msg = document.getElementById('federal-message');
    if (ok) {
      msg.innerHTML = 'Persona liberada correctamente';
      // Efecto visual corto
      msg.style.color = '#013d31ff';
      setTimeout(() => {
        msg.innerHTML = '';
        cargarListaFederal();
      }, 800);
    } else {
      msg.innerHTML = '❌ Error al liberar';
      msg.style.color = '#5a1414ff';
      setTimeout(() => { msg.innerHTML = ''; }, 1200);
    }
  });
}

// 🔹 Enviar jugador a federal
document.getElementById('btn-enviar-federal').addEventListener('click', function() {
  const serverId = document.getElementById('federal-serverid').value;
  const seconds = document.getElementById('federal-time').value;

  if (!serverId || !seconds) {
    document.getElementById('federal-message').innerHTML = '❌ Completa todos los campos';
    return;
  }

  if (seconds < 1) {
    document.getElementById('federal-message').innerHTML = '❌ El tiempo debe ser mayor a 0';
    return;
  }

  document.getElementById('federal-message').innerHTML = '⏳ Enviando...';

  post('federal:sendToFederal', {
    serverId: parseInt(serverId),
    minutes: parseInt(seconds)
  }, function() {
    setTimeout(cargarListaFederal, 1000);
  });
});

// 🔹 Mostrar mensajes desde el cliente (confirmación)
window.addEventListener('message', (e) => {
  const data = e.data || {};

  if (data.action === 'federal:showMessage') {
    document.getElementById('federal-message').innerHTML = data.message;
    if (data.message.includes('enviado') || data.message.includes('liberada')) {
      setTimeout(cargarListaFederal, 1000);
    }
  }

  if (data.action === 'federal:updateTimer') updateFederalTimer(data.minutes);
  if (data.action === 'federal:hideTimer') hideFederalTimer();
});

// 🔹 Timer HUD
function updateFederalTimer(seconds) {
  let timer = document.getElementById('federal-timer-hud');
  if (!timer) {
    timer = document.createElement('div');
    timer.id = 'federal-timer-hud';
    timer.className = 'federal-timer';
    document.body.appendChild(timer);
  }
  timer.innerHTML = `FEDERAL: ${seconds} SEG`;
  timer.style.display = 'block';
}

function hideFederalTimer() {
  const timer = document.getElementById('federal-timer-hud');
  if (timer) timer.style.display = 'none';
}

// 🔹 Botón principal
document.addEventListener('DOMContentLoaded', function() {
  const btnFederal = document.getElementById('btn-federal');
  if (btnFederal) btnFederal.addEventListener('click', showFederal);
});

// 🔹 Cerrar todos los paneles
function hideAllPanels() {
  document.getElementById('panel-ciudadanos').classList.add('hidden');
  document.getElementById('panel-ciudadano-perfil').classList.add('hidden');
  document.getElementById('panel-tiempo').classList.add('hidden');
  document.getElementById('panel-busqueda-captura').classList.add('hidden');
  document.getElementById('panel-federal').classList.add('hidden');
}

// ==================================================
// SISTEMA DE CÁMARAS DE SEGURIDAD
// ==================================================

// Mostrar panel de cámaras
function showPanelCamaras() {
  hideAllPanels();
  document.getElementById('panel-camaras').classList.remove('hidden');
  cargarListaCamaras();
}

// Ocultar panel de cámaras
function hidePanelCamaras() {
  document.getElementById('panel-camaras').classList.add('hidden');
}

// Cargar lista de cámaras
function cargarListaCamaras() {
  const lista = document.getElementById('lista-camaras');
  lista.innerHTML = '<p style="grid-column: 1 / 4; text-align:center; padding:2vw;">Cargando cámaras...</p>';
  
  post('camaras:getList', {}, function(camaras) {
    lista.innerHTML = '';
    
    if (!camaras || !Array.isArray(camaras)) {
      lista.innerHTML = '<p style="grid-column: 1 / 4; text-align:center; color:red;">Error al cargar cámaras</p>';
      return;
    }

    camaras.forEach(camara => {
      const botonCamara = document.createElement('button');
      botonCamara.className = 'btn tile';
      botonCamara.style.fontSize = '0.7vw';
      botonCamara.style.padding = '0.8vw 0.4vw';
      botonCamara.style.display = 'flex';
      botonCamara.style.flexDirection = 'column';
      botonCamara.style.alignItems = 'center';
      botonCamara.style.justifyContent = 'center';
      botonCamara.style.minHeight = '6vw';
      
    botonCamara.innerHTML = `
      <div class="camara-numero">CÁMARA ${camara.id}</div>
      <div class="camara-nombre">${camara.nombre}</div>
`;
      
      botonCamara.onclick = () => {
        post('camaras:activar', { id: camara.id });
        hidePanelCamaras();
        // Cerrar el MDT después de seleccionar cámara
        setTimeout(() => {
          document.getElementById('wrap').classList.add('hidden');
          post('close');
        }, 500);
      };
      
      lista.appendChild(botonCamara);
    });
  });
}

// ==================================================
// SISTEMA DE DASHCAMS
// ==================================================

// Mostrar panel de dashcams
function showPanelDashcams() {
  hideAllPanels();
  document.getElementById('panel-dashcams').classList.remove('hidden');
  cargarDashcamsOficiales();
}

// Ocultar panel de dashcams
function hidePanelDashcams() {
  document.getElementById('panel-dashcams').classList.add('hidden');
}

// Cargar lista de oficiales con dashcams
function cargarDashcamsOficiales() {
  const lista = document.getElementById('lista-dashcams');
  lista.innerHTML = '<p style="grid-column: 1 / 3; text-align:center; padding:2vw;">Cargando oficiales...</p>';
  
  post('dashcams:getOficiales', {}, function(oficiales) {
    lista.innerHTML = '';
    
    if (!oficiales || !Array.isArray(oficiales)) {
      lista.innerHTML = '<p style="grid-column: 1 / 3; text-align:center; color:red;">Error al cargar dashcams</p>';
      return;
    }

    if (oficiales.length === 0) {
      lista.innerHTML = '<p style="grid-column: 1 / 3; text-align:center; color:#666;">No hay oficiales en servicio</p>';
      return;
    }

    oficiales.forEach(oficial => {
      const botonDashcam = document.createElement('button');
      botonDashcam.className = 'btn tile dashcam-btn';
      
      botonDashcam.innerHTML = `
        <div class="dashcam-nombre">${oficial.name}</div>
        <div class="dashcam-info">
          <span class="dashcam-serverid">ID: ${oficial.serverId}</span>
          <span class="dashcam-callsign">Placa: ${oficial.callsign}</span>
        </div>
        <div class="dashcam-ver">VER DASHCAM</div>
      `;
      
      botonDashcam.onclick = () => {
        post('dashcams:spectate', { serverId: oficial.serverId });
        
        // Solo ocultar el panel, no cerrar el MDT completamente
        hidePanelDashcams();
      };
      
      lista.appendChild(botonDashcam);
    });
  });
}


// Función para restaurar el slogan normal
function restaurarSloganNormal() {
  const slogan = document.getElementById('slogan');
  slogan.style.color = '';
  slogan.style.fontWeight = '';
}
 
// Abrir panel Código Penal
document.addEventListener('DOMContentLoaded', () => {
  const btn = document.getElementById('btn-codigo-penal');
  if (btn) {
    btn.addEventListener('click', () => {
      hideAllPanels();
      document.getElementById('panel-codigo-penal').classList.remove('hidden');
      cargarCodigoPenal();
    });
  }

// Crear artículo
const crear = document.getElementById('cp-crear-btn');
if (crear) {
  crear.addEventListener('click', () => {
    const codigo = document.getElementById('cp-articulo').value.trim();
    const descripcion = document.getElementById('cp-descripcion').value.trim();
    const monto = parseInt(document.getElementById('cp-monto').value.trim()) || 0;

    if (!codigo || !descripcion) {
      return;
    }

    post('codigo:createArticle', { codigo, descripcion, monto }, (res) => {
      document.getElementById('cp-articulo').value = '';
      document.getElementById('cp-descripcion').value = '';
      document.getElementById('cp-monto').value = '';
      setTimeout(cargarCodigoPenal, 300);
    });
  });
}
});

// Cerrar panel
function hidePanelCodigoPenal() {
  document.getElementById('panel-codigo-penal').classList.add('hidden');
}

// Cargar artículos desde el client (post al resource)
function cargarCodigoPenal() {
  const cont = document.getElementById('cp-list');
  cont.innerHTML = '<p style="text-align:center;color:#666;">Cargando artículos...</p>';

  post('codigo:getArticles', {}, function(data) {
    if (!data || !Array.isArray(data) || data.length === 0) {
      cont.innerHTML = '<p style="text-align:center;color:#666;">No hay artículos cargados.</p>';
      return;
    }

    let html = '';
    data.forEach(a => {
html += `
  <div class="nota-item">
    <div class="nota-info">
      <div class="nota-titulo">Artículo: ${a.codigo}</div>
      <div class="nota-texto">${a.descripcion}</div>
      <div class="nota-monto">Monto: $${a.monto || 0}</div>
    </div>
    <div class="nota-actions">
      <button class="btn-eliminar-nota" onclick="eliminarArticulo(${a.id})">✖</button>
    </div>
  </div>
`;

    });

    cont.innerHTML = html;
  });
}

// Eliminar artículo
function eliminarArticulo(id) {
  if (!confirm('¿Eliminar articulo?')) return;
  post('codigo:deleteArticle', { id }, function(res) {
    setTimeout(cargarCodigoPenal, 250);
  });
}

// Recepción desde el client.lua cuando el server re-sync
window.addEventListener('message', (e) => {
  const data = e.data || {};
  if (data.action === 'codigo:sync' && document.getElementById('panel-codigo-penal') && !document.getElementById('panel-codigo-penal').classList.contains('hidden')) {
    // Re-render si estás viendo el panel
    const cont = document.getElementById('cp-list');
    const arr = data.articles || [];
    if (!arr.length) {
      cont.innerHTML = '<p style="text-align:center;color:#666;">No hay artículos cargados.</p>';
      return;
    }
    let html = '';
    arr.forEach(a => {
      html += `
        <div class="nota-item" style="display:flex; justify-content:space-between; align-items:center;">
          <div>
            <div class="nota-titulo">Artículo: ${a.codigo}</div>
            <div class="nota-texto">${a.descripcion}</div>
            <div class="nota-fecha" style="font-size:0.7vw; color:#666;">${a.created_at || ''}</div>
          </div>
          <div style="margin-left:1vw;">
            <button class="btn-eliminar-nota" onclick="eliminarArticulo(${a.id})">✖</button>
          </div>
        </div>
      `;
    });
    cont.innerHTML = html;
  }
});


// Botón Tags
document.getElementById('btn-tags').addEventListener('click', () => {
  hideAllPanels();
  document.getElementById('panel-tags').classList.remove('hidden');
  cargarTags();
});

function hidePanelTags() {
  document.getElementById('panel-tags').classList.add('hidden');
}

function cargarTags() {
  post('tags:getAll', {}, function(data) {
    renderTags(data);
  });
}

function renderTags(data) {
  const ag = document.getElementById('lista-tags-agentes');
  const inf = document.getElementById('lista-tags-informes');
  ag.innerHTML = ''; 
  inf.innerHTML = '';

  (data.agentes || []).forEach(t => {
    ag.innerHTML += `<li>${t} <button onclick="eliminarTag('agentes','${t}')">❌</button></li>`;
  });
  (data.informes || []).forEach(t => {
    inf.innerHTML += `<li>${t} <button onclick="eliminarTag('informes','${t}')">❌</button></li>`;
  });
}

// Crear tag (esto no se toca)
function crearTag(tipo) {
  const input = tipo === 'agentes' ? document.getElementById('tag-agente') : document.getElementById('tag-informe');
  const nombre = input.value.trim();
  if (!nombre) return;
  post('tags:add', { tipo, nombre }, () => {
    input.value = '';
    cargarTags();
  });
}

// Eliminar tag (esto tampoco se toca)
function eliminarTag(tipo, nombre) {
  post('tags:delete', { tipo, nombre }, cargarTags);
}

// ✅ ACTUALIZACIÓN EN VIVO AUTOMÁTICA
window.addEventListener('message', (event) => {
  const e = event.data;
  if (e.action === 'updateTags') {
    renderTags(e.data);
  }
});

// -----------------------------
// Registro de Armas - NUI Logic
// -----------------------------

// Abrir panel desde botón
document.getElementById('btn-registro-armas')?.addEventListener('click', () => {
  hideAllPanels();
  document.getElementById('panel-registro-armas').classList.remove('hidden');
});

// Cerrar panel
function hidePanelRegistroArmas() {
  document.getElementById('panel-registro-armas').classList.add('hidden');
  document.getElementById('registro-arma-results').innerHTML = '';
  document.getElementById('registro-arma-detalle').innerHTML = '<p style="text-align:center;color:#666;">Seleccione un serial para ver detalles.</p>';
}

// Buscar serials (botón)
document.getElementById('btn-search-registro-arma')?.addEventListener('click', () => {
  const q = document.getElementById('registro-arma-query').value.trim();
  if (!q || q.length < 1) {
    showTemporaryMessage("Ingrese al menos 1 carácter para buscar", "error");
    return;
  }
  post('registroarmas:search', { query: q }, (res) => {
    renderRegistroArmasResults(res && res.results ? res.results : []);
  });
});

function renderRegistroArmasResults(list) {
  const cont = document.getElementById('registro-arma-results');
  cont.innerHTML = '';
  if (!list || list.length === 0) {
    cont.innerHTML = '<p style="text-align:center;color:#666;">No se encontraron seriales.</p>';
    return;
  }
  let html = '';
  list.forEach(item => {
    html += `
      <div class="nota-item" style="cursor:pointer;" onclick="openRegistroArmaDetail('${item.serial.replace(/'/g, "\\'")}')">
        <div style="display:flex; justify-content:space-between; align-items:center;">
          <div><strong>${item.weapon || 'Desconocida'}</strong></div>
          <div>Serial: <span style="font-weight:700;">${item.serial}</span></div>
        </div>
      </div>
    `;
  });
  cont.innerHTML = html;
}

window.openRegistroArmaDetail = function(serial) {
  // pedir info al server via client
  post('registroarmas:getRecord', { serial }, (res) => {
    renderRegistroArmaDetail(res || {});
  });
};

function renderRegistroArmaDetail(data) {
  const cont = document.getElementById('registro-arma-detalle');
  if (!data || !data.serial) {
    cont.innerHTML = '<p style="text-align:center;color:#666;">No se encontró información.</p>';
    return;
  }

  if (data.found) {
    cont.innerHTML = `
      <div style="display:grid; grid-template-columns: 1fr auto; gap:0.6vw; align-items:center;">
        <div>
          <div><strong>Dueño:</strong> ${data.nombre} ${data.apellido}</div>
          <div><strong>Serial:</strong> ${data.serial}</div>
          <div><strong>Arma:</strong> ${data.weapon || 'N/A'}</div>
          <div><strong>Estado - Robada:</strong> <span id="registro-robada-valor">${data.robada ? 'Sí' : 'No'}</span></div>
        </div>
        <div style="display:flex; flex-direction:column; gap:0.4vw;">
          <button class="btn small" id="btn-toggle-robada">${data.robada ? 'Desmarcar Robada' : 'Marcar Robada'}</button>
        </div>
      </div>
    `;

    document.getElementById('btn-toggle-robada').onclick = () => {
      const newVal = !data.robada;
      post('registroarmas:setRobada', { serial: data.serial, robada: newVal }, (r) => {
        // actualizar UI localmente
        data.robada = newVal;
        document.getElementById('registro-robada-valor').textContent = newVal ? 'Sí' : 'No';
        document.getElementById('btn-toggle-robada').textContent = newVal ? 'Desmarcar Robada' : 'Marcar Robada';
        showTemporaryMessage('✅ Estado actualizado', 'success');
      });
    };

  } else {
    // No tiene dueño conocido
    cont.innerHTML = `
      <div style="display:grid; grid-template-columns: 1fr auto; gap:0.6vw;">
        <div>
          <div><strong>Serial:</strong> ${data.serial}</div>
          <div><strong>Arma:</strong> ${data.weapon || 'N/A'}</div>
          <div><strong>Dueño:</strong> No coincide con ningún registro</div>
          <div><strong>Estado - Robada:</strong> <span id="registro-robada-valor">${data.robada ? 'Sí' : 'No'}</span></div>
        </div>
        <div style="display:flex; flex-direction:column; gap:0.4vw;">
          <button class="btn small" id="btn-toggle-robada2">${data.robada ? 'Desmarcar Robada' : 'Marcar Robada'}</button>
        </div>
      </div>
    `;

    // En app.js - agregar después de la función hidePanelRegistroArmas

// Evento para buscar con Enter en registro de armas
document.getElementById('registro-arma-query')?.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        document.getElementById('btn-search-registro-arma').click();
    }
});

    document.getElementById('btn-toggle-robada2').onclick = () => {
      const newVal = !data.robada;
      post('registroarmas:setRobada', { serial: data.serial, robada: newVal }, (r) => {
        data.robada = newVal;
        document.getElementById('registro-robada-valor').textContent = newVal ? 'Sí' : 'No';
        document.getElementById('btn-toggle-robada2').textContent = newVal ? 'Desmarcar Robada' : 'Marcar Robada';
        showTemporaryMessage('✅ Estado actualizado', 'success');
      });
    };
  }
}

/* ---------------------------
   MÓDULO: BUSCAR VEHÍCULO (NUI)
   --------------------------- */

document.getElementById('btn-vehiculos').addEventListener('click', () => {
  hideAllPanels(); // Oculta todo antes de abrir este panel
  document.getElementById('panel-vehiculos').classList.remove('hidden');
});

document.getElementById('btn-search-vehiculo').addEventListener('click', () => {
  const query = document.getElementById('vehiculo-query').value.trim();
  if (!query || query.length < 1) return;
  post('vehiculos:search', { query });
});

// Renderizar resultados
function renderVehiculosResults(list) {
  const ul = document.getElementById('vehiculo-results');
  ul.innerHTML = '';
  // Siempre ocultamos el panel de detalle hasta seleccionar un vehículo
  document.getElementById('panel-vehiculo-detalle').classList.add('hidden');

  if (!list || !list.length) {
    ul.innerHTML = '<li style="padding:0.6vw;">No se encontraron vehículos</li>';
    return;
  }

  list.forEach(item => {
    const li = document.createElement('li');
    li.style.padding = '0.6vw';
    li.style.borderBottom = '0.1vw solid #ccc';
    li.style.cursor = 'pointer';
    li.innerHTML = `
      <div style="display:flex; justify-content:space-between; align-items:center;">
        <div>
          <div><strong>${item.plate || 'N/A'}</strong></div>
          <div style="font-size:0.8vw; color:#666;">${item.model || 'Desconocido'}</div>
        </div>
        <div style="font-size:0.8vw; color:#999;">${(item.nombre ? (item.nombre + ' ' + (item.apellido || '')) : 'Sin dueño')}</div>
      </div>`;
    li.onclick = () => post('vehiculos:getRecord', { plate: item.plate });
    ul.appendChild(li);
  });
}

// Recibir resultados desde client.lua
window.addEventListener('message', (e) => {
  const data = e.data || {};
  if (data.action === 'vehiculos:showResults') renderVehiculosResults(data.results || []);
  if (data.action === 'vehiculos:showRecord') showVehiculoDetalle(data.record || {});
});

// Mostrar detalle en panel derecho
function showVehiculoDetalle(record) {
  const detalle = document.getElementById('panel-vehiculo-detalle');
  detalle.classList.remove('hidden'); // ✅ mostrar solo cuando hay registro

  document.getElementById('vehiculo-plate').textContent = record.plate || '-';
  document.getElementById('vehiculo-model').textContent = record.model || '-';
  const ownerName = record.nombre ? `${record.nombre} ${record.apellido || ''}` : (record.owner_name || 'N/A');
  document.getElementById('vehiculo-owner').textContent = ownerName;

  const buscado = record.buscado === 1 || record.buscado === true;
  document.getElementById('vehiculo-buscado-label').textContent = buscado ? 'Sí' : 'No';

  // Botones de búsqueda
  document.getElementById('btn-set-buscado-yes').onclick = () => {
    post('vehiculos:setBuscado', { plate: record.plate, buscado: 1 }, (res) => {
      if (res?.ok) {
        document.getElementById('vehiculo-buscado-label').textContent = 'Sí';
        showTemporaryMessage('Vehículo puesto en búsqueda.', 'success');
      } else showTemporaryMessage('Error al actualizar búsqueda.', 'error');
    });
  };

  document.getElementById('btn-set-buscado-no').onclick = () => {
    post('vehiculos:setBuscado', { plate: record.plate, buscado: 0 }, (res) => {
      if (res?.ok) {
        document.getElementById('vehiculo-buscado-label').textContent = 'No';
        showTemporaryMessage('Vehículo removido de búsqueda.', 'success');
      } else showTemporaryMessage('Error al actualizar búsqueda.', 'error');
    });
  };
}

// Ocultar panel de Vehículos
function hidePanelVehiculos() {
  document.getElementById('panel-vehiculos').classList.add('hidden');
  document.getElementById('panel-vehiculo-detalle').classList.add('hidden'); // ✅ ocultar también detalle
  document.getElementById('vehiculo-query').value = '';
  document.getElementById('vehiculo-results').innerHTML = '';
  document.getElementById('vehiculo-plate').textContent = '-';
  document.getElementById('vehiculo-model').textContent = '-';
  document.getElementById('vehiculo-owner').textContent = '-';
  document.getElementById('vehiculo-buscado-label').textContent = 'No';
}

/* ---------------------------
   FIN MÓDULO BUSCAR VEHÍCULO
   --------------------------- */

// ------------------ BLOQUE AGENTES ------------------
document.getElementById('btn-agentes')?.addEventListener('click', () => {
  hideAllPanels();
  document.getElementById('panel-agentes').classList.remove('hidden');
  cargarAgentes();
});

// Escuchar actualizaciones desde el juego
window.addEventListener('message', (event) => {
    if (event.data.action === 'refreshAgentes') {
        cargarAgentes();
    }
});

function hidePanelAgentes() {
  document.getElementById('panel-agentes').classList.add('hidden');
  document.getElementById('lista-agentes').innerHTML = '';
  document.getElementById('agentes-search').value = '';
}

// Cargar lista desde server
function cargarAgentes() {
  const cont = document.getElementById('lista-agentes');
  cont.innerHTML = '<p style="grid-column:1 / -1; text-align:center;">Cargando agentes...</p>';

  post('agentes:getOficiales', {}, function(oficiales) {
    if (!oficiales || !Array.isArray(oficiales) || oficiales.length === 0) {
      cont.innerHTML = '<p style="grid-column:1 / -1; text-align:center; color:#666;">No hay agentes en servicio</p>';
      return;
    }
    renderAgentes(oficiales);
  });
}

function renderAgentes(oficiales) {
  const cont = document.getElementById('lista-agentes');
  cont.innerHTML = '';
  oficiales.forEach(o => {
    const div = document.createElement('div');
    div.className = 'nota-item';
    div.style.cursor = 'pointer';
    
    // Determinar el color según el estado
    let colorEstado;
    if (o.status === 'duty') {
      colorEstado = '#3d79ff'; // Azul para en servicio
    } else if (o.status === 'offduty') {
      colorEstado = '#ffa500'; // Naranja para fuera de servicio
    } else {
      colorEstado = '#ff4444'; // Rojo para desconectado
    }
    
    div.innerHTML = `
      <div style="display:flex; justify-content:space-between; align-items:center; gap:0.4vw;">
        <div style="flex:1;">
          <div class="agent-name" style="color:${colorEstado}; border-left: 0.3vw solid ${colorEstado}; padding-left: 0.5vw;">
            ${o.name || '-'}
          </div>
          <div style="font-size:0.8vw;">${o.gradeName || 'Rango'} · Placa: <b>${o.callsign || 'N/A'}</b></div>
          <div style="font-size:0.7vw; color:${colorEstado}; margin-top:0.2vw;">
            ${o.status === 'duty' ? '🟢 En servicio' : o.status === 'offduty' ? '🟠 Fuera de servicio' : '🔴 Desconectado'}
            ${o.serverId > 0 ? ` (ID: ${o.serverId})` : ''}
          </div>
        </div>
        <div style="display:flex; flex-direction:column; gap:0.3vw; align-items:flex-end;">
          <button class="btn small" onclick="abrirPerfilAgente(event, ${o.serverId})" ${o.serverId === 0 ? 'disabled' : ''}>Abrir</button>
          
        </div>
      </div>
    `;
    cont.appendChild(div);
  });
}

function despedirAgente(serverId) {
  if (serverId === 0) {
    showTemporaryMessage('No se puede despedir a un agente desconectado', 'error');
    return;
  }
  
  // Mostrar loading inmediatamente
  const cont = document.getElementById('lista-agentes');
  const originalContent = cont.innerHTML; // Guardar contenido original
  cont.innerHTML = '<p style="grid-column:1 / -1; text-align:center;">Despidiendo agente...</p>';
  
  post('agentes:despedirAgent', { serverId }, function(resp) {
    if (resp && resp.success) {
      showTemporaryMessage('Agente despedido correctamente', 'success');
      
      // Pequeño delay para que el servidor procese el cambio
      setTimeout(() => {
        cargarAgentes(); // Recargar la lista completa
      }, 1000);
      
    } else {
      showTemporaryMessage(resp?.error || 'No se pudo despedir al agente', 'error');
      // Restaurar contenido original en caso de error
      cont.innerHTML = originalContent;
    }
  });
}

// Buscar en frontend
document.getElementById('agentes-search')?.addEventListener('input', (ev) => {
  const q = ev.target.value.trim().toLowerCase();
  
  // Si está vacío, recargar desde servidor
  if (q.length < 1) { 
    cargarAgentes(); 
    return; 
  }

  // Filtrar localmente para mejor rendimiento
  const items = document.querySelectorAll('#lista-agentes .nota-item');
  let hasResults = false;
  
  items.forEach(item => {
    const text = item.textContent.toLowerCase();
    if (text.includes(q)) {
      item.style.display = 'block';
      hasResults = true;
    } else {
      item.style.display = 'none';
    }
  });
  
  // Mostrar mensaje si no hay resultados
  const noResults = document.getElementById('no-results-agentes') || 
    document.createElement('p');
  noResults.id = 'no-results-agentes';
  noResults.style.cssText = 'grid-column:1 / -1; text-align:center; color:#666;';
  noResults.textContent = 'No se encontraron agentes';
  
  if (!hasResults && items.length > 0) {
    document.getElementById('lista-agentes').appendChild(noResults);
  } else {
    noResults.remove();
  }
});

// Abrir perfil del agente
function abrirPerfilAgente(ev, serverId) {
  ev.stopPropagation();
  if (serverId === 0) {
    showTemporaryMessage('No se puede abrir perfil de agente desconectado', 'error');
    return;
  }
  
  post('agentes:getProfile', { serverId }, function(data) {
    if (!data || !data.serverId) {
      showTemporaryMessage('Error al cargar perfil del agente', 'error');
      return;
    }
    
    // Construcción del modal con toda la info del agente
    const html = `
      <div class="modal" id="modal-agente" data-serverid="${data.serverId}">
        <div class="modal-content">
          <h3>${data.name || 'Agente'}</h3>
          <p><b>Rango:</b> ${data.gradeName || '-'} (Nivel ${data.grade || 0})</p>
          <p><b>Placa:</b> ${data.callsign || '-'}</p>
          <p><b>Server ID:</b> ${data.serverId}</p>
          <div style="margin-top:0.5vw;">
            <b>Tags:</b>
            ${
              data.tags && data.tags.length > 0
                ? data.tags.map(t => `
                    <span class="tag-chip">
                      ${t}
                      <button onclick="eliminarTagAgente('${t}', ${data.serverId})" style="background:none; border:none; color:white; cursor:pointer;">✖</button>
                    </span>
                  `).join(' ')
                : '<span style="color:#888;">Sin etiquetas</span>'
            }
          </div>
          <div style="display:flex; gap:0.5vw; margin-top:0.8vw; flex-wrap:wrap;">
            <button class="btn small" onclick="mostrarAscenso(${data.serverId})">Ascender/Descender</button>
            <button class="btn small" onclick="abrirTagSelector(${data.serverId})">Agregar Tag</button>
            <button class="btn small danger" onclick="despedirAgente(${data.serverId})">Despedir</button>
            <button class="btn small" onclick="document.getElementById('modal-agente').remove()">Cerrar</button>
          </div>
        </div>
      </div>
    `;
    document.body.insertAdjacentHTML('beforeend', html);
  });
}

// Mostrar selector de rangos (petición para obtener rangos del server)
function mostrarAscenso(targetServerId) {
  post('agentes:getRanks', {}, function(ranks) {
    if (!ranks || !Array.isArray(ranks)) return;
    // construir select
    let options = '';
    ranks.forEach(r => { options += `<option value="${r.level}">${r.name} (${r.level})</option>`; });
    const modalHtml = `
      <div class="modal" id="modal-ascenso">
        <div class="modal-content">
          <h3>Seleccionar Rango</h3>
          <select id="select-rank" style="width:100%; padding:0.6vw; margin-bottom:0.8vw;">${options}</select>
          <div style="display:flex; gap:0.6vw; justify-content:flex-end;">
            <button class="btn small" id="btn-apply-rank">Aplicar</button>
            <button class="btn small" onclick="document.getElementById('modal-ascenso').remove()">Cancelar</button>
          </div>
        </div>
      </div>
    `;
    document.body.insertAdjacentHTML('beforeend', modalHtml);
    document.getElementById('btn-apply-rank').onclick = () => {
      const lvl = document.getElementById('select-rank').value;
      // targetServerId: lo podemos tomar desde el modal padre si lo guardaste; para simplificar: pedir confirmación y emitir evento (aquí simplifico: el perfil debe tener guardado serverId en data-serverid)
      const modalPadre = document.getElementById('modal-agente');
        if (!modalPadre) return;
      const sid = modalPadre.dataset.serverid;
      post('agentes:setGrade', { serverId: sid, grade: parseInt(lvl) }, function(res) {
        if (res && res.success) showTemporaryMessage('Rango actualizado', 'success');
        else showTemporaryMessage('No autorizado o error', 'error');
        document.getElementById('modal-ascenso').remove();
        document.getElementById('modal-agente')?.remove();
        cargarAgentes();
      });
    };
  });
}

function eliminarTagAgente(tag, serverId) {

  post('agentes:removeTag', { serverId, tag }, function(res) {
    if (res && res.ok) {
      showTemporaryMessage('Etiqueta eliminada', 'success');
      document.getElementById('modal-agente')?.remove();
      cargarAgentes();
    } else {
      showTemporaryMessage('No se pudo eliminar la etiqueta', 'error');
    }
  });
}

// Abrir selector de tags (usa tags:getAll para cargar los tags disponibles)
function abrirTagSelector(targetServerId) {
  post('tags:getAll', {}, function(data) {
    const tags = (data && data.agentes) || [];
    let list = '';
    tags.forEach(t => list += `<li style="display:flex; justify-content:space-between; align-items:center;"><span>${t}</span><button onclick="post('agentes:addTag', { serverId: ${targetServerId}, tag: '${t}' }, () => { document.getElementById('modal-agente')?.remove(); cargarAgentes(); })">➕</button></li>`);
    const modal = `
      <div class="modal" id="modal-tags-agente">
        <div class="modal-content">
          <h3>Tags Agente</h3>
          <ul style="max-height:12vw; overflow:auto; margin:0; padding:0;">${list}</ul>
          <div style="display:flex; justify-content:flex-end; gap:0.6vw; margin-top:0.6vw;">
            <button class="btn small" onclick="document.getElementById('modal-tags-agente').remove()">Cerrar</button>
          </div>
        </div>
      </div>
    `;
    document.body.insertAdjacentHTML('beforeend', modal);
  });
}

// Agregar agente: pedir al client-lua la persona más cercana
document.getElementById('btn-add-agente')?.addEventListener('click', () => {
  post('agentes:getClosest', {}, function(res) {
    if (!res || !res.serverId) { showTemporaryMessage('No hay jugadores cercanos (3m)', 'error'); return; }
    // Llamada al server para marcarlo/agregar registro si se necesita
    post('agentes:addAgentByServerId', { serverId: res.serverId }, function(resp) {
      if (resp && resp.success) {
        showTemporaryMessage('Agente agregado / registrado', 'success');
        cargarAgentes();
      } else showTemporaryMessage('No se pudo agregar agente', 'error');
    });
  });
});
// ------------------ FIN AGENTES ------------------


// -------------------- BLOQUE: INFORMES POLICIALES --------------------
document.querySelectorAll('.btn.tile2').forEach(btn => {
  if (btn.textContent.trim().toUpperCase() === 'INFORMES POLICIALES') {
    btn.addEventListener('click', abrirPanelInformes);
  }
});

function abrirPanelInformes() {
  hideAllPanels?.();
  let panel = document.getElementById('panel-informes');
  if (!panel) {
    panel = document.createElement('div');
    panel.id = 'panel-informes';
    panel.className = 'panel';
    panel.style.cssText = 'width:65vw;height:42vw;top:6vw;position:absolute;left:50%;transform:translateX(-50%);';
    panel.innerHTML = `
      <div class="panel-header">
        <h2 style="font-weight:800;font-size:1.15vw;color:#fff;margin:0;">Informes Policiales</h2>
        <div style="display:flex;gap:0.6vw;align-items:center;">
          <input id="inf-search" placeholder="Buscar por título o creador..." style="padding:0.4vw;border-radius:0.4vw;" />
          <button id="btn-search-informes" class="btn small">Buscar</button>
          <button id="btn-crear-informe" class="btn small">Crear Informe</button>
          <button class="btn small close-btn" id="cerrar-informes">X</button>
        </div>
      </div>
      <div class="panel-body" style="display:flex;flex-direction:column;gap:0.6vw;">
        <div id="lista-informes" class="perfil-tab-content" style="display:grid;grid-template-columns:repeat(2,1fr);gap:0.6vw;max-height:30vw;overflow:auto;"></div>
      </div>
    `;
    document.body.appendChild(panel);

    document.getElementById('btn-search-informes').addEventListener('click', () => {
      const q = document.getElementById('inf-search').value.trim();
      cargarInformes(q);
    });
    document.getElementById('btn-crear-informe').addEventListener('click', abrirCrearInforme);
    document.getElementById('cerrar-informes').addEventListener('click', () => panel.classList.add('hidden'));
  }

  panel.classList.remove('hidden');
  cargarInformes();
}

// -------------------- FUNCIONES DE INFORMES --------------------
let lastFetch = 0;
function cargarInformes(query = '') {
  const now = Date.now();
  if (now - lastFetch < 3000) return; // evita spam cada 3 seg
  lastFetch = now;

  const cont = document.getElementById('lista-informes');
  if (!cont) return;
  cont.innerHTML = '<p style="grid-column:1 / -1;text-align:center;">Cargando informes...</p>';

  post('informes:fetchList', { query }, function(rows) {
    renderInformes(rows || []);
  });
}

function renderInformes(rows) {
  const cont = document.getElementById('lista-informes');
  if (!cont) return;
  cont.innerHTML = '';
  if (!rows.length) {
    cont.innerHTML = '<p style="grid-column:1 / -1;text-align:center;color:#666;">No hay informes</p>';
    return;
  }
  rows.forEach(r => {
    const div = document.createElement('div');
    div.className = 'nota-item informe-item';
    const title = r.title || ('Informe #' + r.id);
    const fecha = r.created_at ? new Date(r.created_at).toLocaleString('es-ES') : '-';
    div.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:0.4vw;">
        <div>
          <div class="nota-titulo">${escapeHtml(title)}</div>
          <div class="nota-texto" style="max-height:4.2vw;overflow:hidden;">${escapeHtml(r.description || '')}</div>
        </div>
        <div style="text-align:right;min-width:9vw;">
          <div style="font-size:0.7vw;color:#6c757d;">${fecha}</div>
          <button class="btn small" onclick="verInforme(${r.id})">Ver</button>
        </div>
      </div>`;
    cont.appendChild(div);
  });
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str).replace(/[&<>"'`]/g, s => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;','`':'&#96;'}[s]));
}

// -------------------- CREAR INFORME --------------------
function abrirCrearInforme() {
  post('tags:getAll', {}, function(tagdata) {
    const tags = (tagdata && tagdata.informes) ? tagdata.informes : [];
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.id = 'modal-crear-informe';
    modal.innerHTML = `
      <div class="modal-content" style="width:50vw;max-height:35vw;overflow:auto;">
        <h3>Crear Informe Policial</h3>
        <div style="display:flex;flex-direction:column;gap:0.8vw;">
          <label><strong>Título:</strong><input id="inf_titulo" type="text" style="width:100%;"></label>
          <label><strong>Descripción general:</strong><textarea id="inf_desc" style="width:100%;height:5vw;"></textarea></label>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:0.6vw;">
            <label><strong>Agentes:</strong><textarea id="inf_agentes" style="width:100%;height:4vw;"></textarea></label>
            <label><strong>Víctimas:</strong><textarea id="inf_victimas" style="width:100%;height:4vw;"></textarea></label>
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:0.6vw;">
            <label><strong>Implicados:</strong><textarea id="inf_implicados" style="width:100%;height:4vw;"></textarea></label>
            <label><strong>Vehículos:</strong><textarea id="inf_vehicle" style="width:100%;height:4vw;"></textarea></label>
          </div>
          <div>
            <strong>Tags:</strong>
            <div id="inf_tags_selector" style="display:flex;gap:0.4vw;flex-wrap:wrap;">
              ${tags.map(t=>`<button class="tag-btn small" data-tag="${t}" onclick="toggleTagSelection(this)">${t}</button>`).join('')}
            </div>
          </div>

          <div style="margin-top:0.5vw;">
            <strong>Adjuntar Evidencias:</strong>
            <div id="inf_evid_selector" style="display:flex;gap:0.8vw;flex-wrap:wrap;align-items:center;min-height:3vw;">
              <p style="font-size:0.9vw;color:#ccc;">Cargando evidencias del inventario...</p>
            </div>
          </div>

          <div style="display:flex;justify-content:flex-end;gap:0.6vw;margin-top:1vw;">
            <button class="btn small" onclick="this.closest('.modal').remove()">Cancelar</button>
            <button class="btn small" onclick="submitCrearInforme()">Guardar</button>
          </div>
        </div>
      </div>`;
    document.body.appendChild(modal);
    window._inf_selected_tags = [];

    post('informes:getPlayerEvidencias', {}, function(data) {
      const cont = document.getElementById('inf_evid_selector');
      if (!cont) return;
      cont.innerHTML = '';

      const fotos = data.fotos || [];
      const informes = data.informes || [];

      if (!fotos.length && !informes.length) {
        cont.innerHTML = '<p style="color:#888;">No tienes evidencias en el inventario.</p>';
        return;
      }

      const renderItem = (item, tipo) => `
        <label style="display:flex;align-items:center;gap:0.4vw;background:rgba(0,35,50,0.7);padding:0.3vw 0.5vw;border-radius:0.4vw;border:0.1vw solid #004d73;cursor:pointer;">
          <input type="checkbox" name="inf_evid_multi" value="${tipo}:${item.slot}">
          <img src="images/${item.image || (tipo === 'foto' ? 'fotos.png' : 'infopol.png')}" style="width:2vw;height:2vw;border-radius:0.3vw;">
          <span>${item.label || (tipo === 'foto' ? 'Foto Policial' : 'Informe Evidencias')}</span>
        </label>
      `;

      fotos.forEach(f => cont.innerHTML += renderItem(f, 'foto'));
      informes.forEach(i => cont.innerHTML += renderItem(i, 'informe'));
    });
  });
}

window.submitCrearInforme = function() {
  const selected = [...document.querySelectorAll('input[name="inf_evid_multi"]:checked')]
    .map(el => {
      const [tipo, slot] = el.value.split(':');
      return { tipo, slot };
    });

  const payload = {
    title: document.getElementById('inf_titulo').value.trim(),
    description: document.getElementById('inf_desc').value.trim(),
    agents: document.getElementById('inf_agentes').value.trim(),
    victims: document.getElementById('inf_victimas').value.trim(),
    implicated: document.getElementById('inf_implicados').value.trim(),
    vehicle: document.getElementById('inf_vehicle').value.trim(),
    tags: window._inf_selected_tags || [],
    evidencias: selected
  };

  post('informes:create', payload, function(resp) {
    if (resp && resp.success) {
      showTemporaryMessage?.('Informe creado ✔', 'success');
      document.getElementById('modal-crear-informe')?.remove();
      cargarInformes();
    } else {
      showTemporaryMessage?.('Error al crear informe', 'error');
    }
  });
};

window.toggleTagSelection = function(btn) {
  const tag = btn.dataset.tag;
  if (!window._inf_selected_tags) window._inf_selected_tags = [];
  if (window._inf_selected_tags.includes(tag)) {
    window._inf_selected_tags = window._inf_selected_tags.filter(t => t !== tag);
    btn.style.opacity = 1;
  } else {
    window._inf_selected_tags.push(tag);
    btn.style.opacity = 0.6;
  }
};

window.verInforme = function(id) {
  post('informes:getById', { id }, function(r) {
    if (!r) return;
    const agentes = Array.isArray(r.agents_involved) ? r.agents_involved.map(a => a.name || '').join(', ') : (r.agents_involved || '—');
    const victimas = Array.isArray(r.victims) ? r.victims.map(v => v.name || '').join(', ') : (r.victims || '—');
    const implicados = Array.isArray(r.implicated) ? r.implicated.map(i => i.name || '').join(', ') : (r.implicated || '—');
    const tags = Array.isArray(r.tags) ? r.tags.join(', ') : (r.tags || '—');

    const evidencias = (r.extra && r.extra.evidencias && r.extra.evidencias.length)
      ? r.extra.evidencias.map(ev =>
          ev.tipo === 'foto'
            ? `<img src="${ev.url || 'images/fotos.png'}" style="width:5vw;height:5vw;border-radius:0.3vw;margin:0.3vw;">`
            : `<div style="display:inline-block;padding:0.3vw 0.5vw;border:1px solid #004d73;border-radius:0.3vw;margin:0.2vw;">📄 Informe (${ev.slot})</div>`
        ).join('')
      : '—';

    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.innerHTML = `
      <div class="modal-content">
        <h3>${escapeHtml(r.title || ('Informe #' + r.id))}</h3>
        <p><strong>Creado por:</strong> ${escapeHtml(r.creator_name || '')}
           <strong style="float:right">${new Date(r.created_at).toLocaleString('es-ES')}</strong></p>
        <p><strong>Descripción:</strong><br>${escapeHtml(r.description || '')}</p>
        <p><strong>Agentes:</strong> ${escapeHtml(agentes)}</p>
        <p><strong>Víctimas:</strong> ${escapeHtml(victimas)}</p>
        <p><strong>Implicados:</strong> ${escapeHtml(implicados)}</p>
        <p><strong>Vehículos:</strong> ${escapeHtml(r.vehicle || '')}</p>
        <p><strong>Tags:</strong> ${escapeHtml(tags)}</p>
        <p><strong>Evidencias Asociadas:</strong><br>${evidencias}</p>
        <div style="display:flex;justify-content:flex-end;margin-top:1vw;">
          <button class="btn small" onclick="this.closest('.modal').remove()">Cerrar</button>
        </div>
      </div>`;
    document.body.appendChild(modal);
  });
};

window.addEventListener('message', e => {
  const d = e.data || {};
  if (d.action === 'informes:refresh') cargarInformes();
});

// 🔥 SOLUCIÓN SIMPLE: Cerrar todos los paneles con ESC
document.addEventListener('keydown', function(event) {
  if (event.key === 'Escape') {
    // Cerrar panel de informes
    const panelInformes = document.getElementById('panel-informes');
    if (panelInformes && !panelInformes.classList.contains('hidden')) {
      panelInformes.classList.add('hidden');
      return;
    }
    
    // Cerrar otros paneles que tengas...
    // const panelAgentes = document.getElementById('panel-agentes');
    // if (panelAgentes && !panelAgentes.classList.contains('hidden')) {
    //   panelAgentes.classList.add('hidden');
    //   return;
    // }
  }
});

// ==================================================
// SISTEMA DE VISOR DE FOTOS - CORREGIDO
// ==================================================

let visorFotoAbierto = false;
let currentFotoData = null;

// Recibir mensaje para abrir el visor de fotos
window.addEventListener('message', (e) => {
    const data = e.data || {};
    
    if (data.action === 'abrirVisorFoto') {
        abrirVisorFoto(data.url, data.fecha, data.agente);
    }
    
    if (data.action === 'cerrarVisorFoto') {
        cerrarVisorFoto();
    }
});

// Función para abrir el visor de fotos
function abrirVisorFoto(url, fecha, agente) {
    if (visorFotoAbierto) {
        return;
    }
    
    visorFotoAbierto = true;
    
    // Guardar datos actuales
    currentFotoData = { url, fecha, agente };
    
    // Crear el HTML del visor
    const visorHTML = `
        <div id="visor-foto-overlay" style="
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background: rgba(0, 0, 0, 0.98);
            z-index: 9999;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            font-family: 'Segoe UI', sans-serif;
            animation: fadeIn 0.3s ease-in;
        ">
            <!-- Header con información -->
            <div style="
                position: absolute;
                top: 2vw;
                left: 50%;
                transform: translateX(-50%);
                background: rgba(0, 20, 40, 0.9);
                padding: 0.4vw 0.9vw;
                border-radius: 0.5vw;
                color: white;
                text-align: center;
                border: 0.1vw solid #1e3a5c;
                min-width: 30vw;
            ">
                <div style="font-size: 1.2vw; font-weight: 800; margin-bottom: 0.5vw; color: #4d9eff;">
                    FOTO DE EVIDENCIA
                </div>
                <div style="font-size: 0.9vw; margin-bottom: 0.3vw;">
                    <strong>Agente:</strong> ${agente || 'No disponible'}
                </div>
                <div style="font-size: 0.9vw;">
                    <strong>Fecha:</strong> ${fecha || 'No disponible'}
                </div>
            </div>
            
            <!-- Contenedor de la imagen -->
            <div style="
                max-width: 85vw;
                max-height: 70vh;
                display: flex;
                align-items: center;
                justify-content: center;
                margin: 4vw 0 2vw 0;
            ">
                <img src="${url}" 
                     alt="Foto evidencia" 
                     id="foto-evidencia"
                     style="
                         max-width: 100%;
                         max-height: 100%;
                         border-radius: 0.5vw;
                         box-shadow: 0 0 3vw rgba(77, 158, 255, 0.3);
                         border: 0.2vw solid #1e3a5c;
                     "
                     onload="console.log('NUI: Imagen cargada correctamente')"
                     onerror="
                         console.error('NUI: Error cargando imagen');
                         this.src='https://via.placeholder.com/800x600/1e3a5c/ffffff?text=Error+al+cargar+imagen';
                         this.alt='Error al cargar imagen';
                     "
                >
            </div>
            
            <!-- Botón de cerrar -->
            <button onclick="cerrarDesdeBoton()" style="
                padding: 0.8vw 2.5vw;
                background: linear-gradient(135deg, #4d0005, #8b0000);
                color: white;
                border: none;
                border-radius: 0.3vw;
                font-size: 0.9vw;
                cursor: pointer;
                font-weight: bold;
                transition: all 0.2s;
                box-shadow: 0 0.2vw 1vw rgba(139, 0, 0, 0.3);
            " onmouseover="this.style.transform='scale(1.05)'" 
               onmouseout="this.style.transform='scale(1)'">
                CERRAR VISOR [ESC]
            </button>
            
            <!-- Loading indicator -->
            <div id="foto-loading" style="
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                color: white;
                font-size: 1.2vw;
                background: rgba(0, 0, 0, 0.8);
                padding: 1vw 2vw;
                border-radius: 0.5vw;
                display: none;
            ">
                ⏳ Cargando imagen...
            </div>
        </div>
        
        <style>
            @keyframes fadeIn {
                from { opacity: 0; }
                to { opacity: 1; }
            }
            
            #foto-evidencia {
                transition: transform 0.3s ease;
            }
            
            #foto-evidencia:hover {
                transform: scale(1.02);
            }
        </style>
    `;
    
    // Mostrar loading primero
    document.body.insertAdjacentHTML('beforeend', visorHTML);
    
    // Ocultar loading cuando la imagen cargue
    const img = document.getElementById('foto-evidencia');
    const loading = document.getElementById('foto-loading');
    
    if (img && loading) {
        loading.style.display = 'block';
        img.onload = function() {
            loading.style.display = 'none';
        };
        img.onerror = function() {
            loading.style.display = 'none';
        };
    }
}

// Función para cerrar desde el botón
function cerrarDesdeBoton() {
    cerrarVisorFoto();
}

// Función para cerrar el visor
function cerrarVisorFoto() {
    
    const visor = document.getElementById('visor-foto-overlay');
    if (visor) {
        visor.remove();
    }
    
    visorFotoAbierto = false;
    currentFotoData = null;
    
    // Enviar al cliente que se cerró el visor
    fetch(`https://${GetParentResourceName()}/CerrarVisor`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
    }).then(() => {
    }).catch(err => {
        console.error('NUI: Error enviando cierre:', err);
    });
}

// Cerrar con ESC (ya está en el cliente también)
document.addEventListener('keydown', (e) => {
    if (visorFotoAbierto && (e.key === 'Escape' || e.keyCode === 27)) {
        cerrarVisorFoto();
    }
});

///////////////////////////////////
////////SONIDOS//////////////////
////////////////////////////////

// 🔥 FUNCIONES DE SONIDO
function playOpenSound() {
    const sound = document.getElementById('sound-open');
    if (sound) {
        sound.currentTime = 0;
        sound.play().catch(e => console.log('Error reproduciendo sonido open:', e));
    }
}

function playClickSound() {
    const sound = document.getElementById('sound-click');
    if (sound) {
        sound.currentTime = 0;
        sound.play().catch(e => console.log('Error reproduciendo sonido click:', e));
    }
}


window.addEventListener('message', (e) => {
  const data = e.data || {};

  if (data.action === 'open') {
    document.getElementById('wrap').classList.remove('hidden');
    document.getElementById('slogan').textContent = data.slogan || '';
    
    // 🔥 REPRODUCIR SONIDO AL ABRIR
    playOpenSound();
  }

  // ... resto de tus event listeners
});


// 🔥 AGREGAR SONIDO A HOVERS
function addHoverSounds() {
    // Seleccionar todos los botones y elementos clickeables
    const buttons = document.querySelectorAll('.btn, .tile, .dashcam-btn, [onclick]');
    
    buttons.forEach(button => {
        // Sonido al pasar el mouse
        button.addEventListener('mouseenter', function() {
            playClickSound();
        });
        
        // Opcional: sonido al hacer click
        button.addEventListener('click', function() {
            // playClickSound(); // Descomenta si quieres sonido al click también
        });
    });
}

// Ejecutar cuando se abra el MDT
window.addEventListener('message', (e) => {
  const data = e.data || {};

  if (data.action === 'open') {
    document.getElementById('wrap').classList.remove('hidden');
    document.getElementById('slogan').textContent = data.slogan || '';
    playOpenSound();
    
    // 🔥 AGREGAR SONIDOS A BOTONES
    setTimeout(addHoverSounds, 100); // Pequeño delay para que carguen los elementos
  }

  // ... resto de tus event listeners
});

// === 🔹 SISTEMA DE DISPATCH ===

// === 🔹 MINI DISPATCH CON COLA, NAVEGACIÓN, DEDUPE Y CONTADOR ===
let alertQueue = [];
let currentAlertIndex = -1;

// === Mostrar una alerta específica en el mini dispatch ===
function renderMiniDispatch(index) {
    if (!alertQueue || alertQueue.length === 0) return;
    if (index < 0) index = 0;
    if (index >= alertQueue.length) index = alertQueue.length - 1;

    const data = alertQueue[index];
    if (!data) return;

    const miniDispatch = document.getElementById('mini-dispatch');
    if (!miniDispatch) return;

    // 🔹 Animación suave de cambio
    miniDispatch.style.opacity = "0";
    setTimeout(() => {
        document.getElementById('mini-msg').textContent = data.information || data.message || "Alerta 911";
        document.getElementById('mini-loc').textContent = `📍 ${data.street || 'Ubicación desconocida'}`;
        document.getElementById('mini-code').textContent = `#${data.code || '911'}`;
        document.getElementById('mini-time').textContent = `🕐 ${formatTimeAgo(data.time || Date.now())}`;

        // 🔹 Contador correcto
        const counter = document.getElementById('mini-counter');
        if (counter) counter.textContent = `${index + 1} / ${alertQueue.length}`;

        miniDispatch.classList.remove('hidden');
        miniDispatch.style.transition = "opacity 0.25s ease";
        miniDispatch.style.opacity = "1";
    }, 80);
}

// === Agregar/actualizar una nueva alerta (sin duplicar) ===
function showDispatchAlert(alertData) {
    if (!alertData) return;
    alertData.time = alertData.time || Date.now();

    // 🔹 Dedupe por id (si ya existe, se actualiza)
    if (alertData.id !== undefined && alertData.id !== null) {
        const idx = alertQueue.findIndex(a => a.id === alertData.id);
        if (idx !== -1) {
            alertQueue[idx] = Object.assign({}, alertQueue[idx], alertData);
            currentAlertIndex = idx;
            renderMiniDispatch(currentAlertIndex);
            return;
        }
    }

    // 🔹 Nueva alerta
    alertQueue.push(alertData);
    currentAlertIndex = alertQueue.length - 1;
    renderMiniDispatch(currentAlertIndex);
}

// === Ocultar mini alerta visualmente ===
function hideDispatchAlert() {
    const miniDispatch = document.getElementById('mini-dispatch');
    if (!miniDispatch) return;
    miniDispatch.style.opacity = "0";
    setTimeout(() => miniDispatch.classList.add('hidden'), 180);
}

// === Navegación entre alertas ===
function showNextAlert() {
    if (alertQueue.length <= 1) return;
    currentAlertIndex = (currentAlertIndex + 1) % alertQueue.length;
    renderMiniDispatch(currentAlertIndex);
}

function showPreviousAlert() {
    if (alertQueue.length <= 1) return;
    currentAlertIndex = (currentAlertIndex - 1 + alertQueue.length) % alertQueue.length;
    renderMiniDispatch(currentAlertIndex);
}

// === Formato de tiempo relativo CORREGIDO ===
function formatTimeAgo(timestamp) {
    const now = Date.now();
    
    // 🔥 CORRECCIÓN: Si el timestamp está en segundos, convertir a milisegundos
    let alertTime = timestamp;
    if (timestamp < 1000000000000) { // Si es menor a 13 dígitos, está en segundos
        alertTime = timestamp * 1000; // Convertir segundos a milisegundos
    }
    
    const diff = now - alertTime;
    
    // Menos de 1 minuto = segundos
    if (diff < 60000) {
        const seconds = Math.floor(diff / 1000);
        return `${seconds} S`;
    }
    // Menos de 1 hora = minutos
    else if (diff < 3600000) {
        const minutes = Math.floor(diff / 60000);
        return `${minutes} M`;
    }
    // Más de 1 hora = horas
    else {
        const hours = Math.floor(diff / 3600000);
        return `${hours} H`;
    }
}

// Agregar después de la función showPreviousAlert()
function syncAlertNavigation() {
    fetch(`https://${GetParentResourceName()}/dispatch:syncNavigation`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
            currentIndex: currentAlertIndex,
            totalAlerts: alertQueue.length 
        })
    }).catch(() => {});
}


// === 🔹 Eventos desde el cliente LUA ===
window.addEventListener('message', (e) => {
    const data = e.data || {};
    switch (data.action) {
        case 'dispatch:showAlert':
            showDispatchAlert(data.data);
            break;
        case 'dispatch:hideAlert':
            hideDispatchAlert();
            break;
        case 'dispatch:showAlertList':
            showAlertList(data.data);
            break;
        case 'dispatch:hidePanel':
            hidePanelDispatch();
            break;
        case 'dispatch:updateQueue':
            alertQueue = Array.isArray(data.data) ? data.data.slice() : [];
            currentAlertIndex = typeof data.current === 'number' ? data.current : (alertQueue.length - 1);
            if (currentAlertIndex < 0 && alertQueue.length > 0) currentAlertIndex = 0;
            if (currentAlertIndex >= alertQueue.length) currentAlertIndex = alertQueue.length - 1;
            renderMiniDispatch(currentAlertIndex);
            break;
        case 'dispatch:addPoliceChat':
            addPoliceChatMessage(data.message);
            break;
    }
});

// === 🔹 Recibir comandos desde el cliente (navegación con teclas del juego) ===
window.addEventListener('message', (e) => {
    const data = e.data || {};
    if (data.action === 'dispatch:nextAlert') {
        showNextAlert();
    } else if (data.action === 'dispatch:prevAlert') {
        showPreviousAlert();
    }
});

function openPoliceChat() {
    const chat = document.getElementById('policeChat');
    if (chat) chat.style.display = 'flex';
}

function closePoliceChat() {
    const chat = document.getElementById('policeChat');
    if (chat) chat.style.display = 'none';
}

function sendPoliceChat() {
    const input = document.getElementById('policeChatInput');
    const text = input.value.trim();
    if (text.length > 0) {
        fetch(`https://${GetParentResourceName()}/sendPoliceChat`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: text })
        });
        input.value = '';
    }
}

function addPoliceChatMessage(msg) {
    const list = document.getElementById('policeChatMessages');
    if (!list) return;
    const div = document.createElement('div');
    div.classList.add('policeChatMsg');
    div.innerHTML = msg;
    div.style.animation = 'fadeIn 0.3s ease'; // 👈 efecto suave
    list.appendChild(div);
    list.scrollTop = list.scrollHeight;
}


// === Panel de alertas completo ===
function showAlertList(alerts) {
    const container = document.getElementById('dispatch-alerts');
    const panel = document.getElementById('panel-dispatch');

    hideAllPanels();
    panel.classList.remove('hidden');

    if (!alerts || alerts.length === 0) {
        container.innerHTML = '<p style="text-align:center;color:#666;padding:2vw;">No hay alertas activas</p>';
        return;
    }

    container.innerHTML = alerts.map(alert => `
        <div class="alert-item priority-${alert.priority || 2}" onclick="selectAlert(${alert.id})">
            <div class="alert-header">
                <div class="alert-title">${alert.message || 'ALERTA 911'}</div>
                <div class="alert-code">${alert.code || '911'}</div>
            </div>
            ${alert.information ? `<div class="alert-info">💬 ${alert.information}</div>` : ''}
            <div class="alert-location">📍 ${alert.street || 'Ubicación desconocida'}</div>
            <div class="alert-time">${formatTimeAgo(alert.time)}</div>
        </div>
    `).join('');
}

// === Mostrar/ocultar panel ===
function showPanelDispatch() {
    hideAllPanels();
    document.getElementById('panel-dispatch').classList.remove('hidden');
    post('dispatch:getAlerts');
    fetch(`https://${GetParentResourceName()}/setFocus`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ focus: true })
    });
}

function selectAlert(alertId) {
    post('dispatch:setWaypoint', { alertId });
}

function clearAllBlips() {
    post('dispatch:clearBlips');
}

function hidePanelDispatch() {
    document.getElementById('panel-dispatch').classList.add('hidden');
    const backdrop = document.getElementById('panel-backdrop');
    if (backdrop) backdrop.classList.add('hidden');
    fetch(`https://${GetParentResourceName()}/setFocus`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ focus: false })
    });
}

// === Ocultar todo ===
function hideAllPanels() {
    document.querySelectorAll('.panel').forEach(panel => panel.classList.add('hidden'));
    const backdrop = document.getElementById('panel-backdrop');
    if (backdrop) backdrop.classList.add('hidden');
    hideDispatchAlert();
    fetch(`https://${GetParentResourceName()}/setFocus`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ focus: false })
    });
}

// Actualizar hideAllPanels
function hideAllPanels() {
  document.getElementById('panel-ciudadanos').classList.add('hidden');
  document.getElementById('panel-ciudadano-perfil').classList.add('hidden');
  document.getElementById('panel-tiempo').classList.add('hidden');
  document.getElementById('panel-busqueda-captura').classList.add('hidden');
  document.getElementById('panel-federal').classList.add('hidden');
  document.getElementById('panel-camaras').classList.add('hidden');
  document.getElementById('panel-dashcams').classList.add('hidden');
  document.getElementById('panel-codigo-penal').classList.add('hidden');
  document.getElementById('panel-tags').classList.add('hidden'); 
  document.getElementById('panel-registro-armas').classList.add('hidden');
  document.getElementById('panel-vehiculos').classList.add('hidden');
}

