local QBCore = exports['qb-core']:GetCoreObject()


-- Abrir panel de búsqueda desde el botón
RegisterNUICallback('btn:buscar-ciudadano', function(_, cb)
    SendNUIMessage({ action = "showCiudadanosSearch" })
    cb('ok')
end)

-- Evento cuando se hace búsqueda desde el NUI
RegisterNUICallback('ciudadanos:search', function(data, cb)
    if not data or not data.query or #data.query < 3 then
        QBCore.Functions.Notify("Debes ingresar al menos 3 caracteres", "error")
        cb({})
        return
    end

    -- pedir resultados al servidor
    QBCore.Functions.TriggerCallback('sh-mdt:server:buscarCiudadanos', function(resultados)
        SendNUIMessage({ action = "ciudadanos:showResults", results = resultados })
    end, data.query)

    cb('ok')
end)

-- Cuando se selecciona un ciudadano de la lista
RegisterNUICallback('ciudadanos:openProfile', function(data, cb)
    if not data or not data.id then return cb('fail') end

    QBCore.Functions.TriggerCallback('sh-mdt:server:getCiudadanoPerfil', function(perfil)
        SendNUIMessage({ action = "ciudadanos:showProfile", data = perfil })
    end, data.id)

    cb('ok')
end)

RegisterNUICallback('ciudadanos:editarNota', function(data, cb)
    --print("📝 Editando nota desde cliente - ID:", data.id, "Título:", data.titulo, "Texto:", data.texto)
    TriggerServerEvent('sh-mdt:server:editarNota', data.id, data.titulo, data.texto)
    QBCore.Functions.Notify("✅ Nota editada correctamente", "success")
    cb('ok')
end)


-- Marcar peligroso / captura
RegisterNUICallback('ciudadanos:updateFlags', function(data, cb)
    TriggerServerEvent('sh-mdt:server:updateFlags', data.id, data.peligroso, data.captura)
    cb('ok')
end)

-- Añadir cargo
RegisterNUICallback('ciudadanos:addCargo', function(data, cb)
    TriggerServerEvent('sh-mdt:server:addCargo', data.id, data.articulo, data.descripcion)
    cb('ok')
end)

-- Emitir factura (usa tu sistema sh-facturas)
RegisterNUICallback('ciudadanos:emitirFactura', function(data, cb)
    TriggerEvent("sh-facturas:emitirFacturaID", data.ciudadanoId)
    cb('ok')
end)



-- Solicitud de datos para pestañas (vehículos, licencias, etc.)
RegisterNUICallback('ciudadanos:getTab', function(data, cb)
    -- data.id llega desde el NUI (perfil abierto)
    QBCore.Functions.TriggerCallback('sh-mdt:server:getTabData', function(results)
        SendNUIMessage({ action = 'ciudadanos:tabData', tab = data.tab, data = results })
    end, data) -- 👈 ahora pasamos también el id al servidor
    cb('ok')
end)


RegisterNetEvent('sh-mdt:client:sendTabData', function(tab, data)
    SendNUIMessage({ action = "ciudadanos:tabData", tab = tab, data = data })
end)

-- En ciudadanos.lua (CLIENT) - CORREGIDO
RegisterNUICallback('ciudadanos:openNotaInput', function(data, cb)
    local input = exports['qb-input']:ShowInput({
        header = "📝 AGREGAR NUEVA NOTA",
        submitText = "Guardar Nota",
        inputs = {
            {
                text = "Título de la nota",
                name = "titulo",  -- 🔥 CAMBIAR de 'nota' a 'titulo'
                type = "text",
                isRequired = true,
                placeholder = "Ej: Comportamiento sospechoso..."
            },
            {
                text = "Descripción de la nota", 
                name = "nota",  -- 🔥 AGREGAR segundo campo
                type = "text",
                isRequired = true,
                placeholder = "Detalles de la nota..."
            }
        }
    })

    if input and input.titulo and input.nota then
        -- Limpiar espacios
        local titulo = string.gsub(input.titulo, "^%s*(.-)%s*$", "%1")
        local notaTexto = string.gsub(input.nota, "^%s*(.-)%s*$", "%1")
        
        if titulo ~= "" and notaTexto ~= "" then
            -- 🔥 ENVIAR AMBOS DATOS AL SERVIDOR
            TriggerServerEvent('sh-mdt:server:guardarNotas', data.id, notaTexto, titulo)
            QBCore.Functions.Notify("✅ Nota agregada correctamente", "success")
            
            -- Esperar y recargar las notas
            Citizen.Wait(300)
            TriggerServerEvent('sh-mdt:server:getTabData', {id = data.id, tab = "notas"})
        else
            QBCore.Functions.Notify("❌ Debes completar todos los campos", "error")
        end
    else
        QBCore.Functions.Notify("❌ Operación cancelada", "error")
    end

    cb('ok')
end)

-- En la parte donde tienes el callback para agregar multas, REEMPLAZAR con:

RegisterNUICallback('ciudadanos:openMultaInput', function(data, cb)
    local input = exports['qb-input']:ShowInput({
        header = "🚨 AGREGAR NUEVA MULTA",
        submitText = "Registrar Multa", 
        inputs = {
            {
                text = "Artículo / Código",
                name = "articulo",
                type = "text",
                isRequired = true,
                placeholder = "Ej: ART 123..."
            },
            {
                text = "Descripción de la infracción", 
                name = "descripcion",
                type = "text",
                isRequired = true,
                placeholder = "Descripción detallada..."
            },
            {
                text = "Monto de la Multa ($)",
                name = "monto", 
                type = "number",
                isRequired = true,
                placeholder = "Ej: 500"
            }
        }
    })

    if input and input.articulo and input.descripcion and input.monto then
        local articulo = string.gsub(input.articulo, "^%s*(.-)%s*$", "%1")
        local descripcion = string.gsub(input.descripcion, "^%s*(.-)%s*$", "%1")
        local monto = tonumber(input.monto)
        
        if articulo ~= "" and descripcion ~= "" and monto and monto > 0 then
            local ciudadanoId = data.id
            
            -- Primero obtener el perfil completo para tener el server_id
            QBCore.Functions.TriggerCallback('sh-mdt:server:getCiudadanoPerfil', function(perfil)
                if perfil and perfil.server_id and perfil.server_id ~= "No en línea" then
                    local targetServerId = tonumber(perfil.server_id)
                    
                    if targetServerId then
                        -- Crear la multa en el MDT CON MONTO
                        TriggerServerEvent('sh-mdt:server:addCargo', ciudadanoId, articulo, descripcion, monto)
                        
                        -- 🔥 CORREGIDO: Enviar la DESCRIPCIÓN completa como razón de la factura
                        TriggerServerEvent("sh-facturas:server:emitirFacturaID", targetServerId, 
                            "Multa: " .. descripcion, monto)  -- 👈 CAMBIO AQUÍ
                        
                        QBCore.Functions.Notify("✅ Multa registrada y factura emitida", "success")
                    else
                        TriggerServerEvent('sh-mdt:server:addCargo', ciudadanoId, articulo, descripcion, monto)
                        QBCore.Functions.Notify("✅ Multa registrada (ciudadano no conectado para factura)", "success")
                    end
                else
                    -- Si no está conectado, solo registrar la multa CON MONTO
                    TriggerServerEvent('sh-mdt:server:addCargo', ciudadanoId, articulo, descripcion, monto)
                    QBCore.Functions.Notify("✅ Multa registrada (ciudadano no conectado)", "success")
                end
                
                -- Recargar las multas después de un breve delay
                Citizen.Wait(300)
                TriggerServerEvent('sh-mdt:server:getTabData', {id = ciudadanoId, tab = "multas"})
            end, ciudadanoId)
            
        else
            QBCore.Functions.Notify("❌ Debes completar todos los campos correctamente", "error")
        end
    else
        QBCore.Functions.Notify("❌ Operación cancelada", "error")
    end

    cb('ok')
end)

-- En ciudadanos.lua (CLIENTE)
RegisterNUICallback('ciudadanos:eliminarNota', function(data, cb)
    --print("📝 Eliminando nota ID:", data.id) -- DEBUG
    TriggerServerEvent('sh-mdt:server:eliminarNota', data.id)
    QBCore.Functions.Notify("🗑️ Nota eliminada correctamente", "success")
    cb('ok')
end)

RegisterNUICallback('ciudadanos:eliminarMulta', function(data, cb)
    --print("📝 Eliminando multa ID:", data.id) -- DEBUG
    TriggerServerEvent('sh-mdt:server:eliminarMulta', data.id)
    QBCore.Functions.Notify("🗑️ Multa eliminada correctamente", "success")
    cb('ok')
end)

-- Guardar nota desde el formulario integrado (CLIENTE)
RegisterNUICallback('ciudadanos:guardarNotaIntegrado', function(data, cb)
    if not data.id or not data.titulo or not data.nota then
        return cb('fail')
    end

    TriggerServerEvent('sh-mdt:server:guardarNotas', data.id, data.nota, data.titulo)
    QBCore.Functions.Notify("✅ Nota agregada correctamente", "success")
    
    -- Recargar las notas después de un breve delay
    Citizen.Wait(300)
    TriggerServerEvent('sh-mdt:server:getTabData', {id = data.id, tab = "notas"})
    
    cb('ok')
end)

-- 🔥 NUEVO: Callbacks para licencias
RegisterNUICallback('ciudadanos:suspenderLicencia', function(data, cb)
    TriggerServerEvent('sh-mdt:server:suspenderLicencia', data.id, data.tipo)
    QBCore.Functions.Notify("📄 Licencia suspendida", "success")
    cb('ok')
end)

RegisterNUICallback('ciudadanos:validarLicencia', function(data, cb)
    TriggerServerEvent('sh-mdt:server:validarLicencia', data.id, data.tipo)
    QBCore.Functions.Notify("📄 Licencia validada", "success")
    cb('ok')
end)

RegisterNUICallback('ciudadanos:revocarLicencia', function(data, cb)
    TriggerServerEvent('sh-mdt:server:revocarLicencia', data.id, data.tipo)
    QBCore.Functions.Notify("📄 Licencia revocada", "success")
    cb('ok')
end)

-- 🔥 NUEVO: Callback para agregar licencia manualmente (agregar al final)
RegisterNUICallback('ciudadanos:agregarLicencia', function(data, cb)
    local input = exports['qb-input']:ShowInput({
        header = "📄 AGREGAR NUEVA LICENCIA",
        submitText = "Agregar Licencia", 
        inputs = {
            {
                text = "Tipo de Licencia",
                name = "tipo",
                type = "select",
                options = {
                    { value = "LICENCIA DE CONDUCIR", text = "Licencia de Conducir" },
                    { value = "LICENCIA DE PORTE DE ARMAS", text = "Licencia de Porte de Armas" },
                    { value = "LICENCIA COMERCIAL", text = "Licencia Comercial" },
                    { value = "LICENCIA DE PILOTO", text = "Licencia de Piloto" },
                    { value = "LICENCIA DE PESCA", text = "Licencia de Pesca" },
                    { value = "TARJETA BANCARIA", text = "Tarjeta Bancaria" },
                    { value = "PASE DE ABOGADO", text = "Pase de Abogado" },
                    { value = "DOCUMENTO DE IDENTIDAD", text = "Documento de Identidad" },
                    { value = "CARNET MÉDICO", text = "Carnet Médico" }
                }
            },
            {
                text = "Estado Inicial",
                name = "estado",
                type = "select",
                options = {
                    { value = "VÁLIDA", text = "Válida" },
                    { value = "SUSPENDIDA", text = "Suspendida" },
                    { value = "REVOCADA", text = "Revocada" }
                }
            }
        }
    })

    if input and input.tipo then
        TriggerServerEvent('sh-mdt:server:agregarLicencia', data.id, input.tipo, input.estado)
        QBCore.Functions.Notify("📄 Licencia agregada: " .. input.tipo, "success")
        
        Citizen.Wait(300)
        TriggerServerEvent('sh-mdt:server:getTabData', {id = data.id, tab = "licencias"})
    else
        QBCore.Functions.Notify("❌ Operación cancelada", "error")
    end

    cb('ok')
end)

RegisterNUICallback('mdt:copiarSerial', function(data, cb)
    if data.serial then
        -- Enviar mensaje en el chat que el jugador puede copiar
        TriggerEvent('chat:addMessage', {
            args = {"^2[MDT]", "Serial copiado: ^3" .. data.serial .. "^0  (Ctrl+C para copiar del chat)"}
        })

        -- Mostrar el input del GTA para copiar rápido
        SendNUIMessage({
            action = "focusChat",
            text = data.serial
        })
    end
    cb({})
end)
