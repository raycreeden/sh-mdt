local QBCore = exports['qb-core']:GetCoreObject()
local tabletOpen = false
local tabletProp = nil --  Guardamos la referencia al prop para borrarlo después

-------------------------------------
-- 🔹 FUNCIONES DE ANIMACIÓN TABLET
-------------------------------------
function StartTabletAnim()
    local anim = Config.Animation
    local ped = PlayerPedId()

    RequestAnimDict(anim.dict)
    while not HasAnimDictLoaded(anim.dict) do
        Wait(10)
    end

    local propHash = GetHashKey(anim.prop)
    RequestModel(propHash)
    while not HasModelLoaded(propHash) do
        Wait(10)
    end

    local prop = CreateObject(propHash, 0, 0, 0, true, true, false)
    AttachEntityToEntity(
        prop, ped, GetPedBoneIndex(ped, anim.propBone),
        anim.propOffset.x, anim.propOffset.y, anim.propOffset.z,
        anim.propRot.x, anim.propRot.y, anim.propRot.z,
        true, true, false, true, 1, true
    )

    TaskPlayAnim(ped, anim.dict, anim.name, 3.0, 3.0, -1, 49, 0, false, false, false)
    return prop
end

function StopTabletAnim(prop)
    local ped = PlayerPedId()
    ClearPedTasks(ped)
    if DoesEntityExist(prop) then
        DeleteEntity(prop)
    end
end

-------------------------------------
-- 🔹 ABRIR / CERRAR MDT
-------------------------------------
RegisterCommand(Config.CommandName, function()
    local Player = QBCore.Functions.GetPlayerData()
    
    -- Verificar si el jugador tiene el trabajo permitido
    if Player.job.name ~= Config.AllowedJob then
        QBCore.Functions.Notify('No tienes acceso a la MDT', 'error')
        return
    end
    
    -- 🔥 ELIMINADA la verificación de vehículo
    tabletOpen = not tabletOpen

    if tabletOpen then
        -- Verificar si tiene el item requerido
        QBCore.Functions.TriggerCallback('sh-mdt:server:hasItem', function(hasItem)
            if hasItem then
                -- Abrir tablet
                SetNuiFocus(true, true)
                SendNUIMessage({
                    action = "open",
                    slogan = Config.Slogan
                })

                SendNUIMessage({ action = "playOpenSound" })

                -- 🔹 Iniciar animación
                tabletProp = StartTabletAnim()

                -- Pedir contador de policías en servicio
                TriggerServerEvent('sh-mdt:server:requestOnDutyCount')
            else
                QBCore.Functions.Notify('No tienes la tablet', 'error')
                tabletOpen = false
            end
        end, Config.RequiredItem)
    else
        -- Cerrar tablet
        tabletOpen = false
        SetNuiFocus(false, false)
        SendNUIMessage({ action = "close" })
        StopTabletAnim(tabletProp)
        tabletProp = nil
    end
end, false)

-------------------------------------
-- 🔹 KEYMAPPING
-------------------------------------
RegisterKeyMapping(Config.CommandName, 'Abrir Tablet MDT', 'keyboard', Config.KeyDefault)

-------------------------------------
-- 🔹 ASEGURAR QUE INICIE CERRADA
-------------------------------------
CreateThread(function()
    SetNuiFocus(false, false)
    SendNUIMessage({ action = "close" })
end)

-------------------------------------
-- 🔹 CERRAR CON ESC
-------------------------------------
if Config.EnableCloseWithEsc then
    CreateThread(function()
        while true do
            -- 🔥 CAMBIAR Wait(0) por Wait(100)
            Wait(100)
            if tabletOpen and IsControlJustReleased(0, 177) then -- ESC
                tabletOpen = false
                SetNuiFocus(false, false)
                SendNUIMessage({ action = "close" })
                StopTabletAnim(tabletProp)
                tabletProp = nil
            end
        end
    end)
end

-------------------------------------
-- 🔹 NUI CALLBACKS
-------------------------------------
RegisterNUICallback('close', function(_, cb)
    tabletOpen = false
    SetNuiFocus(false, false)
    StopTabletAnim(tabletProp)
    tabletProp = nil
    cb('ok')
end)

RegisterNUICallback('btn:servicio', function(_, cb)
    TriggerServerEvent('sh-mdt:server:toggleDuty')
    cb('ok')
end)

-------------------------------------
-- 🔹 CONTADOR DE POLICÍAS
-------------------------------------
RegisterNetEvent('sh-mdt:client:setOnDutyCount', function(count)
    SendNUIMessage({ action = 'setOnDutyCount', count = count })
end)

-- Salir si el sistema está desactivado
if not Config.PoliceArmorySystem.enabled then
    return
end

local locations = Config.PoliceArmorySystem.locations
local activeMarkers = {}
local showText = false
local textX, textY, textScale = 0.09, 0.635, 0.45

-------------------------------------------------------
-- 🔹 DIBUJAR MÚLTIPLES MARKERS + INTERACCIÓN
-------------------------------------------------------
CreateThread(function()
    while true do
        local sleep = 1500
        local ped = PlayerPedId()
        local pedCoords = GetEntityCoords(ped)
        
        -- Reiniciar markers activos
        activeMarkers = {}
        
        for i, location in ipairs(locations) do
            -- 🔹 COORDENADAS AJUSTADAS - ELIGE UNA OPCIÓN:
            local adjustedCoord = vector3(location.coords.x, location.coords.y - 0.5, location.coords.z)
            -- local adjustedCoord = vector3(location.coords.x + 1.0, location.coords.y, location.coords.z)  -- Derecha
            -- local adjustedCoord = vector3(location.coords.x, location.coords.y + 1.0, location.coords.z)  -- Atrás
            -- local adjustedCoord = vector3(location.coords.x - 1.0, location.coords.y, location.coords.z)  -- Izquierda

            local dist = #(pedCoords - adjustedCoord)

            if dist < 5.0 then
                sleep = 0
                local markerRotation = (GetGameTimer() / 50) % 360.0

                local _, groundZ = GetGroundZFor_3dCoord(adjustedCoord.x, adjustedCoord.y, adjustedCoord.z, 0)
                DrawMarker(
                    2, 
                    adjustedCoord.x, adjustedCoord.y, groundZ + 0.5,
                    0.0, 0.0, 0.0,
                    0.0, 0.0, markerRotation,
                    0.3, 0.3, 0.3,
                    0, 0, 0, 85,
                    false, false, 2, false, nil, nil, false
                )

                if dist < location.radius then
                    activeMarkers[i] = location
                end
            end
        end
        
        -- Mostrar texto si hay markers activos
        if next(activeMarkers) ~= nil then
            showText = true
        else
            showText = false
        end
        
        Wait(sleep)
    end
end)

-------------------------------------------------------
-- 🔹 INTERACCIÓN CON TECLA E PARA TODAS LAS UBICACIONES
-------------------------------------------------------
CreateThread(function()
    while true do
        if next(activeMarkers) ~= nil then
            if IsControlJustPressed(0, 38) then -- tecla E
                AbrirMenuPolicial()
            end
        end
        Wait(0)
    end
end)

-------------------------------------------------------
-- 🔹 MOSTRAR TEXTO EN PANTALLA
-------------------------------------------------------
CreateThread(function()
    while true do
        if showText then
            DrawRect(0.1, 0.65, 0.22, 0.035, 0, 0, 0, 200)
            SetTextFont(4)
            SetTextScale(textScale, textScale)
            SetTextColour(255, 255, 255, 255)
            SetTextCentre(true)
            SetTextEntry("STRING")
            AddTextComponentString("E - Inventario / Armamento Policial")
            DrawText(textX, textY)
        else
            Wait(500)
        end
        Wait(0)
    end
end)

-------------------------------------------------------
-- 🔹 MENÚ POLICIAL (SIN CAMBIOS)
-------------------------------------------------------
function AbrirMenuPolicial()
    local PlayerData = QBCore.Functions.GetPlayerData()
    if PlayerData.job.name ~= "police" then
        QBCore.Functions.Notify("No perteneces al cuerpo policial.", "error")
        return
    end

    exports['qb-menu']:openMenu({
        {
            header = "Inventario / Armamento Policial",
            isMenuHeader = true
        },
        {
            header = "Inventario Policial",
            txt = "Accede al inventario compartido de la comisaría",
            params = { isServer = true, event = "sh-mdt:server:abrirInventario" }
        },
        {
            header = "Armamento Policial",
            txt = "Accede al almacén de armas y equipamiento",
            params = { isServer = true, event = "sh-mdt:server:abrirArmoryStorage" }
        },
        {
            header = "Evidencias",
            txt = "Abrir carpeta de evidencias",
            params = { event = "sh-mdt:client:menuEvidencias" }
        },
        {
            header = "Equipamiento Policial",
            txt = "Equipamiento estándar del cuerpo policial",
            params = { isServer = true, event = "sh-mdt:server:abrirEquipamientoPolicial" }
        },
        {
            header = "Cerrar",
            params = { event = "qb-menu:closeMenu" }
        }
    })
end

-------------------------------------------------------
-- 🔹 INPUT DE EVIDENCIAS (SIN CAMBIOS)
-------------------------------------------------------
RegisterNetEvent("sh-mdt:client:menuEvidencias", function()
    local input = exports['qb-input']:ShowInput({
        header = "Nombre o número de evidencia",
        submitText = "Abrir",
        inputs = {
            {
                type = 'text',
                isRequired = true,
                name = 'evidenceId',
                text = 'Ingrese un nombre o número'
            }
        }
    })

    if input and input.evidenceId then
        TriggerServerEvent("sh-mdt:server:abrirEvidencia", input.evidenceId)
    else
        QBCore.Functions.Notify("No ingresaste un valor válido", "error")
    end
end)

-- ==========================================================
-- 🔹 SISTEMA DE PROCESADOS - CLIENTE
-- ==========================================================

-- Salir si el sistema está desactivado
if not Config.ProcessedSystem or not Config.ProcessedSystem.enabled then
    return
end

local processedLocations = Config.ProcessedSystem.locations

-------------------------------------------------------
-- 🔹 QB-TARGET PARA PROCESADOS
-------------------------------------------------------
CreateThread(function()
    for i, location in ipairs(processedLocations) do
        exports['qb-target']:AddBoxZone("processed_" .. i, location.coords, 1.5, 1.5, {
            name = "processed_" .. i,
            heading = 0,
            debugPoly = false,
            minZ = location.coords.z - 1,
            maxZ = location.coords.z + 1,
        }, {
            options = {
                {
                    type = "client",
                    event = "sh-mdt:client:abrirMenuProcesados",
                    icon = "fas fa-clipboard-list",
                    label = location.label or "Lista de Procesados"
                }
            },
            distance = 2.5
        })
    end
end)

-------------------------------------------------------
-- 🔹 MENÚ DE PROCESADOS
-------------------------------------------------------
RegisterNetEvent("sh-mdt:client:abrirMenuProcesados", function()
    local input = exports['qb-input']:ShowInput({
        header = "Sistema de Procesados",
        submitText = "Abrir Expediente",
        inputs = {
            {
                type = 'text',
                isRequired = true,
                name = 'processedId',
                text = 'Ingrese nombre o ID del procesado'
            }
        }
    })

    if input and input.processedId then
        TriggerServerEvent("sh-mdt:server:abrirProcesado", input.processedId)
    else
        QBCore.Functions.Notify("No ingresaste un valor válido", "error")
    end
end)

-- ==========================================================
-- 🔹 SISTEMA DE HUELLAS DIGITALES - CLIENTE
-- ==========================================================

-- Salir si el sistema está desactivado
if not Config.FingerprintSystem or not Config.FingerprintSystem.enabled then
    return
end

local fingerprintLocations = Config.FingerprintSystem.locations
local createdProps = {}

-------------------------------------------------------
-- 🔹 CREAR PROPS Y QB-TARGET PARA HUELLAS
-------------------------------------------------------
CreateThread(function()
    for i, location in ipairs(fingerprintLocations) do
        local propModel = GetHashKey(location.prop)
        RequestModel(propModel)
        
        -- 🔥 AGREGAR ESTO: Timeout de 3 segundos
        local timeout = 3000
        while not HasModelLoaded(propModel) and timeout > 0 do
            Wait(10)
            timeout = timeout - 10
        end
        
        -- 🔥 AGREGAR ESTO: Solo crear si se cargó a tiempo
        if timeout > 0 then
            local propCoords = vector3(
                location.coords.x + location.propOffset.x,
                location.coords.y + location.propOffset.y, 
                location.coords.z + location.propOffset.z
            )
            
            local prop = CreateObject(propModel, propCoords, false, false, false)
            SetEntityHeading(prop, location.heading)
            SetEntityAsMissionEntity(prop, true, true)
            FreezeEntityPosition(prop, true)
            
            createdProps[i] = prop
            
            exports['qb-target']:AddTargetEntity(prop, {
                options = {
                    {
                        type = "client",
                        event = "sh-mdt:client:usarLectorHuellas",
                        icon = "fas fa-fingerprint",
                        label = location.label or "Apoyar Dedo",
                        locationIndex = i
                    }
                },
                distance = 2.5
            })
        end
    end
end)

-------------------------------------------------------
-- 🔹 USAR LECTOR DE HUELLAS
-------------------------------------------------------
RegisterNetEvent("sh-mdt:client:usarLectorHuellas", function(data)
    local player = PlayerPedId()
    local playerData = QBCore.Functions.GetPlayerData()
    
    -- Animación de señalar
    RequestAnimDict("gestures@f@standing@casual")
    while not HasAnimDictLoaded("gestures@f@standing@casual") do
        Wait(1)
    end
    
    TaskPlayAnim(player, "gestures@f@standing@casual", "gesture_point", 8.0, -8.0, 2000, 49, 0, false, false, false)
    
    -- Mostrar mensaje en chat con formato especial
    TriggerEvent('chat:addMessage', {
        template = '<div style="font-size: 1.30vh; display: flex; align-items: center; justify-content: center; font-weight: bold; margin-bottom: 2px; width: fit-content; padding: 4px 12px; margin-right: 0.40vw; background-color: rgba(255,174,0,0.5); border-radius: 5px; border: rgba(255, 255, 255, 1) 2px solid; color: #222;">{0}: <span style="color: #222; font-weight: bold; margin-left: 4px;">'.. playerData.charinfo.firstname .. " " .. playerData.charinfo.lastname ..'</span></div>',
        args = { "El lector de Huellas Mostraría" }
    })
    
    -- Esperar un poco y detener animación
    Wait(2000)
    ClearPedTasks(player)
    
    -- Notificación de confirmación
    QBCore.Functions.Notify("Huella digital registrada", "success")
    
    -- Registrar en servidor
    TriggerServerEvent("sh-mdt:server:registrarUsoHuellas", data.locationIndex)
end)

-------------------------------------------------------
-- 🔹 LIMPIAR PROPS AL CERRAR RECURSO (NUEVO)
-------------------------------------------------------
AddEventHandler('onResourceStop', function(resourceName)
    if (GetCurrentResourceName() ~= resourceName) then
        return
    end
    
    for i, prop in pairs(createdProps) do
        if DoesEntityExist(prop) then
            DeleteEntity(prop)
        end
    end
end)

