local QBCore = exports['qb-core']:GetCoreObject()
local isSpectating = false
local spectatingPlayer = nil
local originalCoords = nil

-- 🔹 NUI Callback para obtener oficiales (desde servidor)
RegisterNUICallback('dashcams:getOficiales', function(_, cb)
    local playerData = QBCore.Functions.GetPlayerData()
    
    -- Verificar permisos
    if not playerData or not playerData.job or playerData.job.name ~= 'police' or playerData.job.grade.level < Config.Dashcams.MinGrade then
        QBCore.Functions.Notify(Config.Dashcams.Messages.NoPermission, "error")
        cb({})
        return
    end
    
    -- Pedir lista de oficiales al servidor
    QBCore.Functions.TriggerCallback('sh-mdt:server:getOficialesDashcams', function(oficiales)
        cb(oficiales)
    end)
end)


-- 🔹 Función para spectear a un jugador (modo dashcam)
local function spectatePlayer(targetServerId)
    local playerPed = PlayerPedId()
    local targetPed = GetPlayerPed(GetPlayerFromServerId(targetServerId))

    if not DoesEntityExist(targetPed) then
        QBCore.Functions.Notify(Config.Dashcams.Messages.TargetOffline, "error")
        return
    end

    -- 🔹 Ocultar tablet
    SetNuiFocus(false, false)
    SendNUIMessage({ action = "hideAll" })

    originalCoords = GetEntityCoords(playerPed)

    -- 🔹 Congelar jugador
    SetEntityVisible(playerPed, true, false)
    SetEntityCollision(playerPed, true, true)
    FreezeEntityPosition(playerPed, true)

    -- 🔹 Crear cámara
    local cam = CreateCam("DEFAULT_SCRIPTED_CAMERA", true)
    SetCamActive(cam, true)
    RenderScriptCams(true, false, 0, true, false)

-- 🔹 Activar efecto visual "secret_camera" (más realista, sin blur exagerado)
SetTimecycleModifier("scanline_cam")
SetTimecycleModifierStrength(0.6) -- 🔧 ajustá entre 0.3 y 0.6 a gusto
ShakeCam(cam, "HAND_SHAKE", 0.08) -- leve vibración tipo dashcam

-- 🔹 Overlay tipo scanline / CCTV
Citizen.CreateThread(function()
    while isSpectating do
        Citizen.Wait(0)

        -- Líneas horizontales sutiles en toda la pantalla
        for i = 0, 1.0, 0.04 do
            DrawRect(0.5, i, 1.0, 0.001, 0, 0, 0, 55)
        end
    end
end)



       -- 🔹 Estado
    isSpectating = true
    spectatingPlayer = targetServerId

    -- 🔹 Variable local para guardar el nombre del jugador espectado
    local viewedName = "Desconocido"

    -- 🔹 Obtener el nombre desde el servidor y guardarlo
    QBCore.Functions.TriggerCallback('sh-mdt:server:getPlayerName', function(targetName)
        viewedName = targetName or "Desconocido"
        QBCore.Functions.Notify(("Viendo dashcam de: %s"):format(viewedName), "success")
    end, targetServerId)

    -- 🔹 Seguimiento del jugador
    Citizen.CreateThread(function()
        while isSpectating do
            Citizen.Wait(0)
            if not DoesEntityExist(targetPed) then
                stopSpectating(cam)
                break
            end

            -- Posicionar cámara en primera persona (tipo bodycam)
            local targetRot = GetEntityRotation(targetPed)
            local offset = GetOffsetFromEntityInWorldCoords(targetPed, 0.0, 0.28, 0.35)
            SetCamCoord(cam, offset.x, offset.y, offset.z)
            SetCamRot(cam, targetRot.x, targetRot.y, targetRot.z, 2)

            -- Salir con BACKSPACE
            if IsControlJustPressed(0, 177) then
                stopSpectating(cam)
                break
            end
        end
    end)

    -- 🔹 Overlay visual (nombre + líneas tipo scanline)
    Citizen.CreateThread(function()
        while isSpectating do
            Citizen.Wait(0)

            -- Texto con el nombre del jugador
            local displayText = string.format("%s - DASHCAM ACTIVE", viewedName)

            SetTextFont(0)
            SetTextScale(0.38, 0.38)
            SetTextColour(0, 255, 0, 180)
            SetTextOutline()
            SetTextEntry("STRING")
            AddTextComponentString(displayText)
            DrawText(0.015, 0.68) -- 🔧 Subilo/bajalo según tu HUD

            -- Líneas horizontales tipo scanline
            for i = 0, 1.0, 0.04 do
                DrawRect(0.5, i, 1.0, 0.001, 0, 0, 0, 35)
            end
        end
    end)
end


-- 🔹 Función para dejar de spectear (modo dashcam)
function stopSpectating(cam)
    if not isSpectating then return end

    local playerPed = PlayerPedId()

    -- 🔹 Fade out para transición suave
    DoScreenFadeOut(500)
    while not IsScreenFadedOut() do Citizen.Wait(10) end

    -- 🔹 Restaurar cámara
    if cam and DoesCamExist(cam) then
        RenderScriptCams(false, false, 0, true, false)
        DestroyCam(cam, true)
    end

    -- 🔹 Limpiar efectos visuales
    ClearTimecycleModifier()
    StopAllScreenEffects()
    ShakeCam(cam, "HAND_SHAKE", 0.0)
    SetCamEffect(0)
    RenderScriptCams(false, false, 0, true, false)

    -- 🔹 Restaurar visibilidad y movimiento del jugador
    SetEntityVisible(playerPed, true, false)
    SetEntityCollision(playerPed, true, true)
    FreezeEntityPosition(playerPed, false)

    -- 🔹 Volver al punto original si lo teníamos
    if originalCoords then
        SetEntityCoords(playerPed, originalCoords.x, originalCoords.y, originalCoords.z, false, false, false, false)
    end

    -- 🔹 Reset de estado
    isSpectating = false
    spectatingPlayer = nil
    originalCoords = nil

    -- 🔹 Limpieza total de interfaz / cursor
    SetNuiFocus(false, false)
    SetNuiFocusKeepInput(false)
    SetCursorLocation(0.5, 0.5) -- centra el cursor
    SetPlayerControl(PlayerId(), true, 0)

    -- 🔹 Cerrar cualquier UI que quede abierta
    SendNUIMessage({ action = "dashcams:stoppedSpectating" })
    SendNUIMessage({ action = "close" })

    -- 🔹 Log y notificación
    TriggerServerEvent('sh-mdt:server:logDashcamView', GetPlayerServerId(PlayerId()), "stop")
    QBCore.Functions.Notify(Config.Dashcams.Messages.StoppedSpectating or "Saliste del modo dashcam", "error")

    -- 🔹 Pequeño delay y fade-in
    Citizen.Wait(300)
    DoScreenFadeIn(500)
end

-- 🔹 NUI: abrir panel dashcams
RegisterNUICallback('dashcams:open', function(_, cb)
    local playerData = QBCore.Functions.GetPlayerData()
    
    if not playerData or not playerData.job or playerData.job.name ~= 'police' or playerData.job.grade.level < Config.Dashcams.MinGrade then
        QBCore.Functions.Notify(Config.Dashcams.Messages.NoPermission, "error")
        cb({})
        return
    end
    
    cb('ok')
end)


-- 🔹 NUI: iniciar spectate
RegisterNUICallback('dashcams:spectate', function(data, cb)
    local playerData = QBCore.Functions.GetPlayerData()
    local targetServerId = data.serverId
    
    if not playerData or not playerData.job or playerData.job.name ~= 'police' or playerData.job.grade.level < Config.Dashcams.MinGrade then
        QBCore.Functions.Notify(Config.Dashcams.Messages.NoPermission, "error")
        cb('error')
        return
    end
    
    if targetServerId then
        spectatePlayer(tonumber(targetServerId))
    end
    
    cb('ok')
end)


-- 🔹 NUI: cerrar MDT
RegisterNUICallback('close', function(_, cb)
    if isSpectating then
        stopSpectating()
    end
    cb('ok')
end)


-- 🔹 Comando manual de salida (por emergencia)
RegisterCommand('stopspectate', function()
    if isSpectating then
        stopSpectating()
    end
end, false)

