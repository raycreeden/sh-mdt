local QBCore = exports['qb-core']:GetCoreObject()
local isUsingDetector = false
local detectorProp = nil

-- Función para cargar animación
function LoadAnimDict(dict)
    while not HasAnimDictLoaded(dict) do
        RequestAnimDict(dict)
        Wait(5)
    end
end

-- Función para cargar modelo de prop
function LoadModel(model)
    while not HasModelLoaded(model) do
        RequestModel(model)
        Wait(5)
    end
end

-- Función para crear el prop en la mano
function AttachDetectorProp()
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    local modelHash = GetHashKey('reh_prop_reh_digiscanner_01a')
    
    LoadModel(modelHash)
    
    detectorProp = CreateObject(modelHash, coords.x, coords.y, coords.z, true, true, true)
    AttachEntityToEntity(detectorProp, ped, GetPedBoneIndex(ped, 57005), 0.14, 0.0, -0.01, 90.0, -90.0, 0.0, true, true, false, true, 1, true)
end

-- Función para eliminar el prop
function DeleteDetectorProp()
    if detectorProp then
        DeleteObject(detectorProp)
        detectorProp = nil
    end
end

-- Función principal para usar el detector
function UseDetector()
    if isUsingDetector then 
        QBCore.Functions.Notify('Ya estás usando el detector', 'error', 3000)
        return 
    end
    
    -- Verificar si es policía
    local PlayerData = QBCore.Functions.GetPlayerData()
    if not PlayerData.job or PlayerData.job.name ~= 'police' then
        QBCore.Functions.Notify('Solo la policía puede usar esto', 'error', 3000)
        return
    end
    
    local playerPed = PlayerPedId()
    local playerCoords = GetEntityCoords(playerPed)
    
    -- Verificar si hay jugadores cercanos
    local closestPlayer, closestDistance = QBCore.Functions.GetClosestPlayer()
    
    if closestPlayer == -1 or closestDistance > 3.0 then
        QBCore.Functions.Notify('No hay jugadores cercanos', 'error', 3000)
        return false
    end
    
    isUsingDetector = true
    
    -- Cargar animación y prop
    LoadAnimDict('anim@amb@business@meth@meth_smash_weight_check@')
    AttachDetectorProp()
    
    -- ProgressBar de 10 segundos
    QBCore.Functions.Progressbar('using_detector', 'ESCANEANDO ESTADOS...', 10000, false, true, {
        disableMovement = true,
        disableCarMovement = true,
        disableMouse = false,
        disableCombat = true,
    }, {
        animDict = 'anim@amb@business@meth@meth_smash_weight_check@',
        anim = 'break_weigh_char01',
        flags = 49,
    }, {}, {}, function()
        -- Success - Verificar estados del jugador cercano
        TriggerServerEvent('detector:server:checkPlayerStatus', GetPlayerServerId(closestPlayer))
        
        -- Limpiar
        DeleteDetectorProp()
        ClearPedTasks(playerPed)
        isUsingDetector = false
    end, function()
        -- Cancel
        DeleteDetectorProp()
        ClearPedTasks(playerPed)
        QBCore.Functions.Notify('Escaneo cancelado', 'error', 3000)
        isUsingDetector = false
    end)
    
    return true
end

-- Evento para recibir resultados del servidor (ACTUALIZAR ESTE)
RegisterNetEvent('detector:client:showResults')
AddEventHandler('detector:client:showResults', function(statusList)
    
    if not statusList or #statusList == 0 then
        QBCore.Functions.Notify('No se detectaron estados alterados', 'success', 15000)
        return
    end
    
    QBCore.Functions.Notify('Se detectaron ' .. #statusList .. ' estados alterados', 'primary', 13000)
    
    -- Mostrar cada estado alterado encontrado
    for i, status in ipairs(statusList) do
        Citizen.Wait(800) -- Espera 0.8 segundos entre cada notificación
        QBCore.Functions.Notify('' .. status, 'primary', 14000)
    end
end)

-- 🔥 EVENTO CLAVE: Este es el que se ejecuta cuando usas el item del inventario
RegisterNetEvent('qb-items:client:useDetector')
AddEventHandler('qb-items:client:useDetector', function()
    UseDetector()
end)

-- Alternativa si usas otro sistema de inventario
RegisterNetEvent('inventory:item:useDetector')
AddEventHandler('inventory:item:useDetector', function()
    UseDetector()
end)

-- Para QB-Inventory estándar
RegisterNetEvent('inventory:client:ItemBox')
AddEventHandler('inventory:client:ItemBox', function(itemData, type)
    if itemData.name == 'pol_detector' and type == 'use' then
        UseDetector()
    end
end)

-- Debug command para probar
RegisterCommand('testdetector', function()
    UseDetector()
end)