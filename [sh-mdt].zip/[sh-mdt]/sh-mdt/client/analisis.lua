local QBCore = exports['qb-core']:GetCoreObject()
local analizando = false

-- Función para crear los props y targets
local function CrearPropsAnalisis()
    -- Prop para huellas
    local huellasProp = CreateObject(GetHashKey(Config.AnalisisEvidencias.Props.Huellas.prop), 
        Config.AnalisisEvidencias.Props.Huellas.coords.x, 
        Config.AnalisisEvidencias.Props.Huellas.coords.y, 
        Config.AnalisisEvidencias.Props.Huellas.coords.z, 
        false, false, false)
    SetEntityHeading(huellasProp, Config.AnalisisEvidencias.Props.Huellas.heading)
    FreezeEntityPosition(huellasProp, true)

    -- Prop para sangre
    local sangreProp = CreateObject(GetHashKey(Config.AnalisisEvidencias.Props.Sangre.prop), 
        Config.AnalisisEvidencias.Props.Sangre.coords.x, 
        Config.AnalisisEvidencias.Props.Sangre.coords.y, 
        Config.AnalisisEvidencias.Props.Sangre.coords.z, 
        false, false, false)
    SetEntityHeading(sangreProp, Config.AnalisisEvidencias.Props.Sangre.heading)
    FreezeEntityPosition(sangreProp, true)

    -- Prop para casquillos
    local casquillosProp = CreateObject(GetHashKey(Config.AnalisisEvidencias.Props.Casquillos.prop), 
        Config.AnalisisEvidencias.Props.Casquillos.coords.x, 
        Config.AnalisisEvidencias.Props.Casquillos.coords.y, 
        Config.AnalisisEvidencias.Props.Casquillos.coords.z, 
        false, false, false)
    SetEntityHeading(casquillosProp, Config.AnalisisEvidencias.Props.Casquillos.heading)
    FreezeEntityPosition(casquillosProp, true)

    -- Crear targets
    exports['qb-target']:AddTargetEntity(huellasProp, {
        options = {
            {
                type = "client",
                event = "sh-evidencias:cliente:abrirMenuHuellas",
                icon = "fas fa-fingerprint",
                label = Config.AnalisisEvidencias.Props.Huellas.label,
                job = "police"
            }
        },
        distance = 2.5
    })

    exports['qb-target']:AddTargetEntity(sangreProp, {
        options = {
            {
                type = "client",
                event = "sh-evidencias:cliente:abrirMenuSangre", 
                icon = "fas fa-tint",
                label = Config.AnalisisEvidencias.Props.Sangre.label,
                job = "police"
            }
        },
        distance = 2.5
    })

    exports['qb-target']:AddTargetEntity(casquillosProp, {
        options = {
            {
                type = "client",
                event = "sh-evidencias:cliente:abrirMenuCasquillos",
                icon = "fas fa-crosshairs",
                label = Config.AnalisisEvidencias.Props.Casquillos.label,
                job = "police"
            }
        },
        distance = 2.5
    })
end

-- Función para abrir menú de huellas
RegisterNetEvent('sh-evidencias:cliente:abrirMenuHuellas')
AddEventHandler('sh-evidencias:cliente:abrirMenuHuellas', function()
    if analizando then return end
    
    local PlayerData = QBCore.Functions.GetPlayerData()
    if not PlayerData or not PlayerData.job or PlayerData.job.name ~= 'police' then
        QBCore.Functions.Notify('No eres policía', 'error')
        return
    end

    -- Obtener huellas del servidor
    QBCore.Functions.TriggerCallback('sh-evidencias:servidor:obtenerHuellas', function(huellas)
        if not huellas or #huellas == 0 then
            QBCore.Functions.Notify(Config.AnalisisEvidencias.Mensajes.SinEvidencias, 'error')
            return
        end

        local opciones = {}
        for i, huella in ipairs(huellas) do
            table.insert(opciones, {
                header = "Huella Digital #" .. i,
                txt = "Huella: " .. (huella.fingerprint or "Desconocida"),
                params = {
                    event = "sh-evidencias:cliente:analizarHuella",
                    args = huella
                }
            })
        end

        opciones[#opciones + 1] = {
            header = "⬅ Cerrar Menú",
            txt = "",
            params = {
                event = "qb-menu:client:closeMenu"
            }
        }

        exports['qb-menu']:openMenu(opciones)
    end)
end)

-- Función para analizar huella específica
RegisterNetEvent('sh-evidencias:cliente:analizarHuella')
AddEventHandler('sh-evidencias:cliente:analizarHuella', function(huella)
    if analizando then return end
    analizando = true

    QBCore.Functions.Progressbar('analizar_huella', Config.AnalisisEvidencias.Mensajes.Analizando, 5000, false, true, {
        disableMovement = true,
        disableCarMovement = true,
        disableMouse = false,
        disableCombat = true,
    }, {
        animDict = "anim@amb@business@coc@coc_unpack_cut@",
        anim = "fullcut_cycle_v1_cokecutter",
        flags = 16,
    }, {}, {}, function()
        -- Enviar al servidor para crear el informe
        TriggerServerEvent('sh-evidencias:servidor:crearInformeHuella', huella)
        analizando = false
    end, function()
        QBCore.Functions.Notify('Cancelado', 'error')
        analizando = false
    end)
end)

-- Función para abrir menú de sangre
RegisterNetEvent('sh-evidencias:cliente:abrirMenuSangre')
AddEventHandler('sh-evidencias:cliente:abrirMenuSangre', function()
    if analizando then return end
    
    local PlayerData = QBCore.Functions.GetPlayerData()
    if not PlayerData or not PlayerData.job or PlayerData.job.name ~= 'police' then
        QBCore.Functions.Notify('No eres policía', 'error')
        return
    end

    -- Obtener muestras de sangre del servidor
    QBCore.Functions.TriggerCallback('sh-evidencias:servidor:obtenerSangre', function(sangre)
        if not sangre or #sangre == 0 then
            QBCore.Functions.Notify(Config.AnalisisEvidencias.Mensajes.SinEvidencias, 'error')
            return
        end

        local opciones = {}
        for i, muestra in ipairs(sangre) do
            table.insert(opciones, {
                header = "Muestra de Sangre #" .. i,
                txt = "Tipo: " .. (muestra.bloodtype or "Desconocido"),
                params = {
                    event = "sh-evidencias:cliente:analizarSangre",
                    args = muestra
                }
            })
        end

        opciones[#opciones + 1] = {
            header = "⬅ Cerrar Menú",
            txt = "",
            params = {
                event = "qb-menu:client:closeMenu"
            }
        }

        exports['qb-menu']:openMenu(opciones)
    end)
end)

-- Función para analizar sangre específica
RegisterNetEvent('sh-evidencias:cliente:analizarSangre')
AddEventHandler('sh-evidencias:cliente:analizarSangre', function(sangre)
    if analizando then return end
    analizando = true

    QBCore.Functions.Progressbar('analizar_sangre', Config.AnalisisEvidencias.Mensajes.Analizando, 5000, false, true, {
        disableMovement = true,
        disableCarMovement = true,
        disableMouse = false,
        disableCombat = true,
    }, {
        animDict = "anim@amb@business@coc@coc_unpack_cut@",
        anim = "fullcut_cycle_v1_cokecutter",
        flags = 16,
    }, {}, {}, function()
        -- Enviar al servidor para crear el informe
        TriggerServerEvent('sh-evidencias:servidor:crearInformeSangre', sangre)
        analizando = false
    end, function()
        QBCore.Functions.Notify('Cancelado', 'error')
        analizando = false
    end)
end)

-- Función para abrir menú de casquillos
RegisterNetEvent('sh-evidencias:cliente:abrirMenuCasquillos')
AddEventHandler('sh-evidencias:cliente:abrirMenuCasquillos', function()
    if analizando then return end
    
    local PlayerData = QBCore.Functions.GetPlayerData()
    if not PlayerData or not PlayerData.job or PlayerData.job.name ~= 'police' then
        QBCore.Functions.Notify('No eres policía', 'error')
        return
    end

    -- Obtener casquillos del servidor
    QBCore.Functions.TriggerCallback('sh-evidencias:servidor:obtenerCasquillos', function(casquillos)
        if not casquillos or #casquillos == 0 then
            QBCore.Functions.Notify(Config.AnalisisEvidencias.Mensajes.SinEvidencias, 'error')
            return
        end

        local opciones = {}
        for i, casquillo in ipairs(casquillos) do
            table.insert(opciones, {
                header = "Casquillo #" .. i,
                txt = "Arma: " .. (casquillo.weapon or "Desconocida"),
                params = {
                    event = "sh-evidencias:cliente:analizarCasquillo",
                    args = casquillo
                }
            })
        end

        opciones[#opciones + 1] = {
            header = "⬅ Cerrar Menú",
            txt = "",
            params = {
                event = "qb-menu:client:closeMenu"
            }
        }

        exports['qb-menu']:openMenu(opciones)
    end)
end)

-- Función para analizar casquillo específico
RegisterNetEvent('sh-evidencias:cliente:analizarCasquillo')
AddEventHandler('sh-evidencias:cliente:analizarCasquillo', function(casquillo)
    if analizando then return end
    analizando = true

    QBCore.Functions.Progressbar('analizar_casquillo', Config.AnalisisEvidencias.Mensajes.Analizando, 5000, false, true, {
        disableMovement = true,
        disableCarMovement = true,
        disableMouse = false,
        disableCombat = true,
    }, {
        animDict = "anim@amb@business@coc@coc_unpack_cut@",
        anim = "fullcut_cycle_v1_cokecutter",
        flags = 16,
    }, {}, {}, function()
        -- Enviar al servidor para crear el informe
        TriggerServerEvent('sh-evidencias:servidor:crearInformeCasquillo', casquillo)
        analizando = false
    end, function()
        QBCore.Functions.Notify('Cancelado', 'error')
        analizando = false
    end)
end)

-- Crear props cuando el recurso inicia
AddEventHandler('onResourceStart', function(resourceName)
    if GetCurrentResourceName() == resourceName then
        CrearPropsAnalisis()
    end
end)

-- También crear cuando el jugador entra
RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
    Wait(5000)
    CrearPropsAnalisis()
end)