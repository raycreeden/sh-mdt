local QBCore = exports['qb-core']:GetCoreObject()
local viendoFoto = false

-- Función para abrir el visor de fotos
local function AbrirVisorFoto(urlImagen, fecha, agente)
    if viendoFoto then 
        return 
    end
    
    viendoFoto = true
    
    -- Enviar datos al NUI (HTML)
    SendNUIMessage({
        action = 'abrirVisorFoto',
        url = urlImagen,
        fecha = fecha or 'Fecha no disponible',
        agente = agente or 'Agente desconocido'
    })
    
    -- Mostrar el NUI y darle foco
    SetNuiFocus(true, true)
end

-- Función para cerrar el visor
local function CerrarVisorFoto()
    if not viendoFoto then return end
    
    viendoFoto = false
    
    SendNUIMessage({
        action = 'cerrarVisorFoto'
    })
    
    SetNuiFocus(false, false)
end

-- Evento para recibir la foto del servidor
RegisterNetEvent('sh-camara:cliente:verFoto')
AddEventHandler('sh-camara:cliente:verFoto', function(urlImagen, fecha, agente)
    AbrirVisorFoto(urlImagen, fecha, agente)
end)

-- Callback desde el NUI para cerrar
RegisterNUICallback('CerrarVisor', function(data, cb)
    CerrarVisorFoto()
    cb('ok')
end)

-- Control para cerrar con BACKSPACE y ESC
Citizen.CreateThread(function()
    while true do
        Wait(0)
        if viendoFoto then
            -- BACKSPACE
            if IsControlJustReleased(0, 177) then
                CerrarVisorFoto()
            end
            -- ESC
            if IsControlJustReleased(0, 200) then
                CerrarVisorFoto()
            end
        end
    end
end)

-- Limpiar cuando el recurso se para
AddEventHandler('onResourceStop', function(resourceName)
    if GetCurrentResourceName() == resourceName and viendoFoto then
        CerrarVisorFoto()
    end
end)