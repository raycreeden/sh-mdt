local QBCore = exports['qb-core']:GetCoreObject()
local open = false

--------------------------------------
-- 📘 PANEL CÓDIGO PENAL
--------------------------------------

RegisterNetEvent('codigo_penal:openUI', function()
    SetNuiFocus(true, true)
    SendNUIMessage({ action = 'openCodigoPenal' })
    open = true
end)

RegisterNUICallback('close', function(_, cb)
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'close' })
    open = false
    cb('ok')
end)

--------------------------------------
-- 📚 CRUD ARTÍCULOS
--------------------------------------

RegisterNUICallback('codigo:getArticles', function(_, cb)
    QBCore.Functions.TriggerCallback('codigo_penal:getArticles', function(result)
        cb(result or {})
    end)
end)

RegisterNUICallback('codigo:createArticle', function(data, cb)
    if not data or not data.codigo or not data.descripcion or not data.monto then return cb('fail') end
    TriggerServerEvent('codigo_penal:createArticle', data)
    cb('ok')
end)

RegisterNUICallback('codigo:deleteArticle', function(data, cb)
    if not data or not data.id then return cb('fail') end
    TriggerServerEvent('codigo_penal:deleteArticle', tonumber(data.id))
    cb('ok')
end)

RegisterNetEvent('codigo_penal:syncArticles', function(list)
    SendNUIMessage({ action = 'codigo:sync', articles = list or {} })
end)

--------------------------------------
-- 🧾 MULTAS DEL CÓDIGO PENAL
--------------------------------------

-- Obtener artículos
RegisterNUICallback('codigo_penal:getAll', function(_, cb)
    QBCore.Functions.TriggerCallback('codigo_penal:getAll', function(result)
        cb(result or {})
    end)
end)

-- Aplicar multa (idéntico a ciudadanos:addCargo)
RegisterNUICallback('codigo_penal:aplicarMulta', function(data, cb)
    if not data then return cb('fail') end
    local ciudadanoId = tonumber(data.ciudadanoId)
    local codigo = tostring(data.codigo or "")
    local descripcion = tostring(data.descripcion or "")
    local monto = tonumber(data.monto or 0)
    if not ciudadanoId or codigo == "" or descripcion == "" or monto <= 0 then return cb('fail') end
    TriggerServerEvent('codigo_penal:server:aplicarMulta', ciudadanoId, codigo, descripcion, monto)
    cb('ok')
end)

-- Refrescar multas
RegisterNetEvent('ciudadanos:syncMultas', function(ciudadanoId)
    SendNUIMessage({ action = 'ciudadanos:refreshMultas', ciudadanoId = ciudadanoId })
end)

-- Relay hacia sh-facturas (no toca el recurso)
RegisterNetEvent('codigo_penal:emitirFacturaRelay', function(targetId, razon, monto)
    if not targetId or not razon or not monto then return end
    TriggerServerEvent('sh-facturas:server:emitirFacturaID', tonumber(targetId), tostring(razon), tonumber(monto))
end)
