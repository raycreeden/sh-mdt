local QBCore = exports['qb-core']:GetCoreObject()

-- 🔥 VARIABLES OPTIMIZADAS
local estadoAnterior = nil
local esPolicia = false
local ultimaVerificacion = 0
local INTERVALO_NORMAL = 30000 -- 30 segundos
local INTERVALO_RAPIDO = 5000  -- 5 segundos (solo para transiciones)
local modoRapido = false
local tiempoModoRapido = 0

-- 🔥 FUNCIÓN PRINCIPAL OPTIMIZADA
local function verificarEstadoServicio()
    local playerData = QBCore.Functions.GetPlayerData()
    
    if not playerData or not playerData.job then 
        if esPolicia then
            esPolicia = false
            estadoAnterior = nil
        end
        return 
    end

    local esPoliciaActual = (playerData.job.name == 'police')
    local estadoActual = playerData.job.onduty

    -- 🔥 DETECTAR CAMBIO DE ESTADO
    if esPoliciaActual then
        if not esPolicia then
            -- Cambió a ser policía
            esPolicia = true
            estadoAnterior = estadoActual
            TriggerServerEvent('sh-mdt:server:registrarServicio', estadoActual and 'entrar' or 'salir')
            modoRapido = true
            tiempoModoRapido = GetGameTimer()
        else
            -- Solo si cambia el estado de servicio
            if estadoAnterior ~= nil and estadoAnterior ~= estadoActual then
                estadoAnterior = estadoActual
                TriggerServerEvent('sh-mdt:server:registrarServicio', estadoActual and 'entrar' or 'salir')
                modoRapido = true
                tiempoModoRapido = GetGameTimer()
            end
        end
    else
        if esPolicia then
            -- Dejó de ser policía
            esPolicia = false
            estadoAnterior = nil
            TriggerServerEvent('sh-mdt:server:registrarServicio', 'salir')
        end
    end
end

-- 🔥 LOOP PRINCIPAL CON GESTIÓN INTELIGENTE DE INTERVALOS
CreateThread(function()
    -- Esperar inicialización del jugador
    Wait(10000)
    
    while true do
        local tiempoActual = GetGameTimer()
        
        -- 🔥 CALCULAR INTERVALO INTELIGENTE
        local intervalo
        if modoRapido then
            intervalo = INTERVALO_RAPIDO
            -- Salir del modo rápido después de 30 segundos
            if (tiempoActual - tiempoModoRapido) > 30000 then
                modoRapido = false
            end
        else
            intervalo = INTERVALO_NORMAL
        end
        
        -- Solo verificar si ha pasado el intervalo suficiente
        if (tiempoActual - ultimaVerificacion) >= intervalo then
            verificarEstadoServicio()
            ultimaVerificacion = tiempoActual
        end
        
        -- 🔥 WAIT FLEXIBLE - Reduce CPU
        if modoRapido then
            Wait(1000)  -- 1 segundo en modo rápido
        else
            Wait(5000)  -- 5 segundos en modo normal
        end
    end
end)

-- 🔥 EVENTOS DE REINICIO
AddEventHandler('QBCore:Client:OnPlayerLoaded', function()
    Wait(8000)
    estadoAnterior = nil
    esPolicia = false
    ultimaVerificacion = 0
    verificarEstadoServicio()
end)

AddEventHandler('QBCore:Client:OnPlayerUnload', function()
    estadoAnterior = nil
    esPolicia = false
end)

-- 🔥 CALLBACK PARA NUI (sin cambios)
RegisterNUICallback('tiempo:getOficiales', function(_, cb)
    QBCore.Functions.TriggerCallback('sh-mdt:tiempo:getOficiales', function(registros)
        cb(registros or {})
    end)
end)
