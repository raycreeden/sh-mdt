local QBCore = exports['qb-core']:GetCoreObject()
local open = false
local currentTags = { agentes = {}, informes = {} }

-- Abrir panel
RegisterNetEvent('tags:openUI', function()
    SetNuiFocus(true, true)
    SendNUIMessage({ action = 'openTags', data = currentTags })
    open = true
end)

RegisterNUICallback('close', function(_, cb)
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'close' })
    open = false
    cb('ok')
end)

-- Obtener tags desde el servidor
RegisterNUICallback('tags:getAll', function(_, cb)
    QBCore.Functions.TriggerCallback('tags:getAll', function(tags)
        currentTags = tags or { agentes = {}, informes = {} }
        cb(currentTags)
    end)
end)

-- Agregar tag
RegisterNUICallback('tags:add', function(data, cb)
    TriggerServerEvent('tags:add', data.tipo, data.nombre)
    cb('ok')
end)

-- Eliminar tag
RegisterNUICallback('tags:delete', function(data, cb)
    TriggerServerEvent('tags:delete', data.tipo, data.nombre)
    cb('ok')
end)

-- Actualización en tiempo real
RegisterNetEvent('tags:updateAll', function(tags)
    currentTags = tags
    if open then
        SendNUIMessage({ action = 'updateTags', data = tags })
    end
end)
