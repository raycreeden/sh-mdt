local QBCore = exports['qb-core']:GetCoreObject()
local usandoCamara = false
local propCamara = nil
local camara = nil
local zoomActual = Config.Camara.ZoomDefault

-- Función para cargar animación
local function CargarAnimacion(dict)
    RequestAnimDict(dict)
    local intentos = 0
    while not HasAnimDictLoaded(dict) and intentos < 100 do
        intentos = intentos + 1
        Wait(10)
    end
    return HasAnimDictLoaded(dict)
end

-- Función para cargar modelo
local function CargarModelo(model)
    local modelHash = GetHashKey(model)
    RequestModel(modelHash)
    local intentos = 0
    while not HasModelLoaded(modelHash) and intentos < 100 do
        intentos = intentos + 1
        Wait(10)
    end
    return HasModelLoaded(modelHash)
end

-- Función para bloquear controles peligrosos
local function BloquearControlesPeligrosos()
    -- Bloquear disparos
    DisableControlAction(0, 24, true) -- INPUT_ATTACK (Click izquierdo)
    -- Bloquear melee/puñetazos
    DisableControlAction(0, 140, true) -- INPUT_MELEE_ATTACK_LIGHT (R)
    DisableControlAction(0, 142, true) -- INPUT_MELEE_ATTACK_ALTERNATE (LEFT MOUSE)
    DisableControlAction(0, 199, true) -- INPUT_FRONTEND_PAUSE (P)
end

-- Función para crear la cámara scripteada
local function CrearCamara()
    local playerPed = PlayerPedId()
    local coords = GetEntityCoords(playerPed)
    local forwardVector = GetEntityForwardVector(playerPed)
    
    -- Calcular posición de la cámara (más adelante para no ver la prop)
    local camCoords = vector3(
        coords.x + (forwardVector.x * Config.Camara.CameraOffset.y),
        coords.y + (forwardVector.y * Config.Camara.CameraOffset.y), 
        coords.z + Config.Camara.CameraOffset.z
    )
    
    -- Crear cámara scripteada
    camara = CreateCam("DEFAULT_SCRIPTED_CAMERA", true)
    SetCamCoord(camara, camCoords.x, camCoords.y, camCoords.z)
    
    -- Apuntar la cámara hacia donde mira el jugador
    local heading = GetEntityHeading(playerPed)
    SetCamRot(camara, 0.0, 0.0, heading, 2)
    
    -- Aplicar zoom inicial
    SetCamFov(camara, zoomActual)
    
    -- Renderizar cámara
    RenderScriptCams(true, true, 1000, true, true)
    
    -- Deshabilitar controles del jugador pero permitir movimiento de cámara
    DisableControlAction(0, 1, true) -- Mouse look
    DisableControlAction(0, 2, true) -- Mouse look
    
    return camara
end

-- Función para colocar el prop de la cámara (pero fuera de vista)
local function ColocarPropCamara()
    local playerPed = PlayerPedId()
    
    -- Cargar modelo de la cámara
    if not CargarModelo(Config.Camara.PropName) then
        QBCore.Functions.Notify("Error al cargar modelo de cámara", "error")
        return false
    end
    
    -- Crear el objeto de la cámara
    local coords = GetEntityCoords(playerPed)
    propCamara = CreateObject(GetHashKey(Config.Camara.PropName), coords.x, coords.y, coords.z, true, true, true)
    
    -- Attach la cámara a la mano del jugador (posición discreta)
    AttachEntityToEntity(propCamara, playerPed, GetPedBoneIndex(playerPed, Config.Camara.PropBone), 
        Config.Camara.PropOffset.x, Config.Camara.PropOffset.y, Config.Camara.PropOffset.z, 
        Config.Camara.PropRotation.x, Config.Camara.PropRotation.y, Config.Camara.PropRotation.z, 
        true, true, false, true, 1, true)
    
    return true
end

-- Función para manejar el zoom (CORREGIDO)
local function ManejarZoom()
    local scrollUp = IsDisabledControlJustPressed(0, 14)    -- Scroll hacia arriba
    local scrollDown = IsDisabledControlJustPressed(0, 15)  -- Scroll hacia abajo
    
    if scrollUp then -- Scroll up - ACERCAR (zoom in)
        zoomActual = math.max(Config.Camara.ZoomMin, zoomActual - Config.Camara.ZoomStep)
        SetCamFov(camara, zoomActual)
    elseif scrollDown then -- Scroll down - ALEJAR (zoom out)
        zoomActual = math.min(Config.Camara.ZoomMax, zoomActual + Config.Camara.ZoomStep)
        SetCamFov(camara, zoomActual)
    end
end

-- Función para manejar el movimiento de la cámara con mouse
local function ManejarMovimientoCamara()
    local playerPed = PlayerPedId()
    local mouseX = GetDisabledControlNormal(0, 1) -- Mouse X
    local mouseY = GetDisabledControlNormal(0, 2) -- Mouse Y
    
    if mouseX ~= 0.0 or mouseY ~= 0.0 then
        local camRot = GetCamRot(camara, 2)
        local newX = camRot.x - (mouseY * 10.0) -- Invertir Y para movimiento natural
        local newZ = camRot.z - (mouseX * 10.0)
        
        -- Limitar rotación vertical para evitar volteos
        newX = math.max(-89.0, math.min(89.0, newX))
        
        SetCamRot(camara, newX, 0.0, newZ, 2)
    end
end

-- Función para actualizar la posición de la cámara (sigue al jugador)
local function ActualizarPosicionCamara()
    local playerPed = PlayerPedId()
    local coords = GetEntityCoords(playerPed)
    local camRot = GetCamRot(camara, 2)
    
    -- Calcular dirección basada en la rotación de la cámara
    local angle = math.rad(camRot.z)
    local forwardX = math.sin(angle) * Config.Camara.CameraOffset.y
    local forwardY = math.cos(angle) * Config.Camara.CameraOffset.y
    
    -- Calcular nueva posición de la cámara
    local camCoords = vector3(
        coords.x - forwardX,  -- Invertir para que esté frente al jugador
        coords.y + forwardY,
        coords.z + Config.Camara.CameraOffset.z
    )
    
    -- Actualizar posición manteniendo la rotación
    SetCamCoord(camara, camCoords.x, camCoords.y, camCoords.z)
end

-- Función para eliminar el prop
local function EliminarPropCamara()
    if propCamara then
        DeleteEntity(propCamara)
        propCamara = nil
    end
end

-- Función para limpiar la cámara
local function LimpiarCamara()
    if camara then
        RenderScriptCams(false, true, 1000, true, true)
        DestroyCam(camara, false)
        camara = nil
    end
end

-- Función para restaurar controles
local function RestaurarControles()
    -- Re-habilitar todos los controles
    EnableControlAction(0, 1, true) -- Mouse look
    EnableControlAction(0, 2, true) -- Mouse look
    EnableControlAction(0, 24, true) -- INPUT_ATTACK
    EnableControlAction(0, 25, true) -- INPUT_AIM
    EnableControlAction(0, 37, true) -- INPUT_SELECT_WEAPON
    EnableControlAction(0, 45, true) -- INPUT_RELOAD
    EnableControlAction(0, 44, true) -- INPUT_COVER
    EnableControlAction(0, 22, true) -- INPUT_JUMP
    EnableControlAction(0, 23, true) -- INPUT_ENTER
    EnableControlAction(0, 140, true) -- INPUT_MELEE_ATTACK_LIGHT
    EnableControlAction(0, 141, true) -- INPUT_MELEE_ATTACK_HEAVY
    EnableControlAction(0, 142, true) -- INPUT_MELEE_ATTACK_ALTERNATE
    EnableControlAction(0, 143, true) -- INPUT_MELEE_BLOCK
    EnableControlAction(0, 157, true) -- INPUT_SELECT_WEAPON_UNARMED
    EnableControlAction(0, 158, true) -- INPUT_SELECT_WEAPON_MELEE
    EnableControlAction(0, 160, true) -- INPUT_SELECT_WEAPON_SHOTGUN
    EnableControlAction(0, 163, true) -- INPUT_SELECT_WEAPON_HEAVY
    EnableControlAction(0, 164, true) -- INPUT_SELECT_WEAPON_SPECIAL
    EnableControlAction(0, 165, true) -- INPUT_SELECT_WEAPON_UNARMED
    EnableControlAction(0, 75, true) -- INPUT_VEH_EXIT
    EnableControlAction(0, 199, true) -- INPUT_FRONTEND_PAUSE
end

-- Función para ocultar el HUD
local function OcultarHUD()
    DisplayRadar(false)
    DisplayHud(false)
end

-- Función para mostrar el HUD
local function MostrarHUD()
    DisplayRadar(true)
    DisplayHud(true)
end

-- Función para tomar screenshot y enviar al servidor
local function TomarFoto()
    if not exports[Config.Camara.ResourceScreenshot] then
        QBCore.Functions.Notify("Error: Resource de screenshot no disponible", "error")
        return
    end

    -- Ocultar HUD antes de tomar la foto
    OcultarHUD()

    -- Pequeño delay para asegurar que el HUD se ocultó
    Citizen.Wait(100)

    -- Mostrar mensaje de que se está tomando la foto
    QBCore.Functions.Notify("Tomando foto...", "primary")

    -- Tomar screenshot
    exports[Config.Camara.ResourceScreenshot]:requestScreenshotUpload(Config.Camara.WebhookURL, "files[]", function(data)
        -- Restaurar HUD inmediatamente después de tomar la foto
        MostrarHUD()

        local response = json.decode(data)
        local imageURL = response and response.attachments and response.attachments[1] and response.attachments[1].url
        
        if imageURL then
            -- Enviar al servidor para crear el item
            TriggerServerEvent('sh-camara:servidor:crearFotoItem', imageURL)
        else
            QBCore.Functions.Notify("Error al procesar la foto", "error")
        end
    end)
end

-- Función para salir del modo cámara
local function SalirModoCamara()
    local playerPed = PlayerPedId()
    
    if not usandoCamara then return end
    
    usandoCamara = false
    
    -- Asegurar que el HUD se restaure al salir
    MostrarHUD()
    
    -- Limpiar animación
    ClearPedTasks(playerPed)
    
    -- Limpiar cámara
    LimpiarCamara()
    
    -- Eliminar prop
    EliminarPropCamara()
    
    -- Restaurar controles
    RestaurarControles()
    
    -- Restaurar vista normal
    SetFollowPedCamViewMode(1)
    
    -- Limpiar help text
    ClearHelp(true)
    
    -- Resetear zoom
    zoomActual = Config.Camara.ZoomDefault
    
    QBCore.Functions.Notify(Config.Camara.Mensajes.Cancelado, "info")
end

-- Función principal para usar la cámara
local function UsarCamara()
    local playerPed = PlayerPedId()
    
    -- Verificar si ya está usando la cámara
    if usandoCamara then
        return
    end
    
    -- Verificar si está en vehículo
    if IsPedInAnyVehicle(playerPed, false) then
        QBCore.Functions.Notify("No puedes usar la cámara dentro de un vehículo", "error")
        return
    end
    
    -- Cargar animación
    if not CargarAnimacion(Config.Camara.AnimDict) then
        QBCore.Functions.Notify(Config.Camara.Mensajes.ErrorAnim, "error")
        return
    end
    
    usandoCamara = true
    
    -- Reproducir animación
    TaskPlayAnim(playerPed, Config.Camara.AnimDict, Config.Camara.AnimName, 8.0, -8.0, -1, 49, 0, false, false, false)
    
    -- Colocar prop de la cámara (no visible porque la cámara está al frente)
    ColocarPropCamara()
    
    -- Crear cámara scripteada
    if not CrearCamara() then
        SalirModoCamara()
        return
    end
    
    -- Mostrar mensaje inicial
    QBCore.Functions.Notify(Config.Camara.Mensajes.UsandoCamara, "primary", 5000)

    -- Hilo principal de la cámara (optimizado)
    Citizen.CreateThread(function()
        local lastAnimCheck = 0
        local lastHelpUpdate = 0
        local lastCamUpdate = 0
        local helpTextDelay = 300      -- 1 segundo
        local animCheckDelay = 200      -- 0.4 segundos
        local camUpdateDelay = 10       -- 0.05 segundos (~20 fps)
        
        while usandoCamara do
            Wait(0) -- Mantiene controles y movimiento fluidos

            -- Bloquear controles peligrosos (cada frame)
            BloquearControlesPeligrosos()

            -- Controles principales
            if IsControlJustReleased(0, Config.Camara.ControlTomarFoto) then
                TomarFoto()
            elseif IsControlJustReleased(0, Config.Camara.ControlCancelar) then
                break
            end

            -- Manejar zoom y movimiento (deben ser fluidos)
            ManejarZoom()
            ManejarMovimientoCamara()

            local now = GetGameTimer()

            -- Mostrar help text cada 1 segundo
            if now - lastHelpUpdate > helpTextDelay then
                lastHelpUpdate = now
                SetTextComponentFormat("STRING")
                AddTextComponentString("~INPUT_PICKUP~ Tomar Foto | ~SCROLL~ Zoom | ~INPUT_CELLPHONE_CANCEL~ Cancelar")
                DisplayHelpTextFromStringLabel(0, 0, 1, -1)
            end

            -- Actualizar posición de cámara cada 50 ms (20 fps)
            if now - lastCamUpdate > camUpdateDelay then
                lastCamUpdate = now
                ActualizarPosicionCamara()
            end

            -- Rechequear animación cada 400 ms
            if now - lastAnimCheck > animCheckDelay then
                lastAnimCheck = now
                if not IsEntityPlayingAnim(playerPed, Config.Camara.AnimDict, Config.Camara.AnimName, 3) then
                    TaskPlayAnim(playerPed, Config.Camara.AnimDict, Config.Camara.AnimName, 8.0, -8.0, -1, 49, 0, false, false, false)
                end
            end

            -- Salir si entra en un vehículo
            if IsPedInAnyVehicle(playerPed, false) then
                break
            end
        end

        -- Salir del modo cámara
        SalirModoCamara()
    end)
end

-- Evento para usar la cámara desde el item
RegisterNetEvent('sh-camara:cliente:usarCamara')
AddEventHandler('sh-camara:cliente:usarCamara', function()
    UsarCamara()
end)

-- Manejar cuando el recurso se detiene
AddEventHandler('onResourceStop', function(resourceName)
    if GetCurrentResourceName() == resourceName and usandoCamara then
        SalirModoCamara()
    end
end)

-- Detectar si el jugador entra en un vehículo
Citizen.CreateThread(function()
    while true do
        Wait(1000)
        if usandoCamara then
            local playerPed = PlayerPedId()
            if IsPedInAnyVehicle(playerPed, false) then
                SalirModoCamara()
            end
        end
    end
end)