local QBCore = exports['qb-core']:GetCoreObject()

-- Abrir panel de búsqueda y captura
RegisterNUICallback('busquedacaptura:open', function(_, cb)
    TriggerServerEvent('sh-mdt:server:getBusquedaCaptura')
    cb('ok')
end)

-- Recibir datos de búsqueda y captura
RegisterNetEvent('sh-mdt:client:receiveBusquedaCaptura', function(ciudadanos)
    SendNUIMessage({
        action = 'busquedacaptura:showResults',
        ciudadanos = ciudadanos
    })
end)

-- Cerrar panel
RegisterNUICallback('busquedacaptura:close', function(_, cb)
    SendNUIMessage({
        action = 'busquedacaptura:hidePanel'
    })
    cb('ok')
end)