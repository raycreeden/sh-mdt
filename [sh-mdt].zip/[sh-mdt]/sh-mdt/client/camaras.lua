local QBCore = exports['qb-core']:GetCoreObject()
local camaraActiva = false
local camaraId = nil

-- Función para activar una cámara
local function activarCamara(id)
    if camaraActiva then
        -- Si ya hay una cámara activa, desactivarla primero
        ExecuteCommand("cam")
    end
    
    -- Activar la nueva cámara
    ExecuteCommand("cam " .. id)
    camaraActiva = true
    camaraId = id
    
    -- Notificación
    QBCore.Functions.Notify("Cámara " .. id .. " activada - BACKSPACE para salir", "success")
    
    -- Configurar tecla para salir
    Citizen.CreateThread(function()
        while camaraActiva do
            Citizen.Wait(0)
            if IsControlJustPressed(0, 177) then -- BACKSPACE
                salirCamara()
                break
            end
        end
    end)
end

-- Función para salir de la cámara
function salirCamara()
    if camaraActiva then
        ExecuteCommand("cam")
        camaraActiva = false
        camaraId = nil
        QBCore.Functions.Notify("Cámara desactivada", "error")
    end
end

-- NUI Callback para abrir panel de cámaras
RegisterNUICallback('camaras:open', function(_, cb)
    cb('ok')
end)

-- NUI Callback para activar cámara específica
RegisterNUICallback('camaras:activar', function(data, cb)
    local id = data.id
    if id then
        activarCamara(tonumber(id))
    end
    cb('ok')
end)

-- NUI Callback para obtener lista de cámaras
RegisterNUICallback('camaras:getList', function(_, cb)
    cb(Config.Camaras)
end)

-- Evento para cuando se cierra el MDT
RegisterNUICallback('close', function(_, cb)
    if camaraActiva then
        salirCamara()
    end
    cb('ok')
end)