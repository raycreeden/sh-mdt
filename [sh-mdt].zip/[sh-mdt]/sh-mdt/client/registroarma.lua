local QBCore = exports['qb-core']:GetCoreObject()

RegisterNUICallback('registroarmas:search', function(data, cb)
    if not data or not data.query or data.query == '' then 
        return cb({ results = {} }) 
    end
    
    QBCore.Functions.TriggerCallback('sh-mdt:server:buscarArmaSerial', function(results)
        cb({ results = results or {} })
    end, data.query) -- ✅ Pasar el query como parámetro
end)

RegisterNUICallback('registroarmas:getRecord', function(data, cb)
    if not data or not data.serial then return cb({}) end
    QBCore.Functions.TriggerCallback('sh-mdt:server:getArmaOwner', function(res)
        cb(res or {})
    end, data.serial)
end)

RegisterNUICallback('registroarmas:setRobada', function(data, cb)
    if not data or not data.serial then return cb({ ok = false }) end
    TriggerServerEvent('sh-mdt:server:setArmaRobada', data.serial, data.robada)
    cb({ ok = true })
end)

RegisterNetEvent('sh-mdt:client:notifyRegistroArma', function(msg, tipo)
    QBCore.Functions.Notify(msg, tipo)
end)