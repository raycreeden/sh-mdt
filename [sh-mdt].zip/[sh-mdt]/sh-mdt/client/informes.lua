local QBCore = exports['qb-core']:GetCoreObject()

-- Abrir panel de informes desde NUI (botón)
RegisterNUICallback('informes:open', function(_, cb)
    SendNUIMessage({ action = "informes:open" })
    cb('ok')
end)

-- Pedir lista
RegisterNUICallback('informes:fetchList', function(data, cb)
    local q = data.query or ''
    QBCore.Functions.TriggerCallback('sh-mdt:server:getInformes', function(rows)
        cb(rows or {})
    end, q)
end)

-- Guardar informe (payload viene desde JS con arrays de objetos)
RegisterNUICallback('informes:create', function(data, cb)
    QBCore.Functions.TriggerCallback('sh-mdt:server:createInforme', function(resp)
        cb(resp)
        -- si éxito, refrescar lista
        if resp and resp.success then
            SendNUIMessage({ action = "informes:refresh" })
        end
    end, data)
end)

-- Obtener detalle por id
RegisterNUICallback('informes:getById', function(data, cb)
    QBCore.Functions.TriggerCallback('sh-mdt:server:getInformeById', function(row)
        cb(row)
    end, data.id)
end)

RegisterNUICallback('informes:getPlayerEvidencias', function(_, cb)
    local Player = QBCore.Functions.GetPlayerData()
    if not Player or not Player.items then return cb({ fotos = {}, informes = {} }) end

    local fotos = {}
    local informes = {}

    for _, item in pairs(Player.items) do
        if item.name == 'fotos_pol' then
            fotos[#fotos + 1] = { slot = item.slot, label = item.label, info = item.info or {}, image = item.image or 'fotos.png' }
        elseif item.name == 'infopol_evid' then
            informes[#informes + 1] = { slot = item.slot, label = item.label, info = item.info or {}, image = item.image or 'infopol.png' }
        end
    end

    cb({ fotos = fotos, informes = informes })
end)

