-- client/servicio.lua
RegisterNUICallback('btn:servicio:click', function(_, cb)
    TriggerServerEvent('sh-mdt:server:toggleDuty')
    cb('ok')
end)
