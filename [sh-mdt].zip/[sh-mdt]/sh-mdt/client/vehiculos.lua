local QBCore = exports['qb-core']:GetCoreObject()

-- Buscar vehículos
RegisterNUICallback('vehiculos:search', function(data, cb)
    if not data or not data.query or data.query == '' then
        return cb({ results = {} })
    end

    QBCore.Functions.TriggerCallback('sh-mdt:server:buscarVehiculoPlate', function(results)
        -- devolvemos al NUI (html/app.js)
        SendNUIMessage({
            action = 'vehiculos:showResults',
            results = results or {}
        })
        cb({ ok = true }) -- ✅ importante: siempre cerrar el callback
    end, data.query)
end)

-- Obtener detalle de vehículo
RegisterNUICallback('vehiculos:getRecord', function(data, cb)
    if not data or not data.plate then
        return cb({})
    end

    QBCore.Functions.TriggerCallback('sh-mdt:server:getVehiculoOwner', function(res)
        SendNUIMessage({
            action = 'vehiculos:showRecord',
            record = res or {}
        })
        cb({ ok = true })
    end, data.plate)
end)

RegisterNUICallback('vehiculos:setBuscado', function(data, cb)
    if not data or not data.plate then
        return cb({ ok = false })
    end
    TriggerServerEvent('sh-mdt:server:setVehiculoBuscado', data.plate, data.buscado)
    cb({ ok = true })
end)

RegisterNetEvent('sh-mdt:client:notifyVehiculo', function(msg, tipo)
    QBCore.Functions.Notify(msg, tipo)
end)
