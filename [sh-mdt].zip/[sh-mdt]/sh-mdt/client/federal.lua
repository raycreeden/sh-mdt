local QBCore = exports['qb-core']:GetCoreObject()
local isInFederal = false
local timeLeft = 0
local timerThread = nil
local federalCenter = vector3(1744.37, 2525.8, 45.55)

-- Abrir panel federal
RegisterNUICallback('federal:open', function(_, cb)
    cb('ok')
end)

-- Enviar a federal
RegisterNUICallback('federal:sendToFederal', function(data, cb)
    TriggerServerEvent('sh-mdt:server:sendToFederal', data.serverId, data.minutes)
    cb('ok')
end)

-- Recibir confirmación
RegisterNetEvent('sh-mdt:client:federalConfirmation', function(message)
    SendNUIMessage({
        action = 'federal:showMessage',
        message = message
    })
end)

-- Ser enviado a federal
RegisterNetEvent('sh-mdt:client:goToFederal', function(seconds)
    local playerPed = PlayerPedId()
    
    -- TP al federal
    SetEntityCoords(playerPed, federalCenter.x, federalCenter.y, federalCenter.z, false, false, false, false)
    SetEntityHeading(playerPed, 87.19)
    
    -- Variables de control
    isInFederal = true
    timeLeft = seconds
    
    -- Iniciar controles
    startFederalControls()
    
    -- Mostrar tiempo inicial
    updateFederalHUD()
end)

-- Controles de federal
-- Controles de federal (optimizado y con corrección Lua)
function startFederalControls()
    if timerThread then return end
    timerThread = true

    CreateThread(function()
        while isInFederal and timeLeft > 0 do
            Wait(1000)

            -- Si ya no estamos en federal salimos
            if not isInFederal then break end

            -- Verificar distancia solo cada 5 segundos para ahorrar CPU
            if timeLeft % 5 == 0 then
                local playerPed = PlayerPedId()
                if playerPed and playerPed ~= 0 then
                    local playerCoords = GetEntityCoords(playerPed)
                    local distance = #(playerCoords - federalCenter)
                    if distance > 150.0 then
                        SetEntityCoords(playerPed, federalCenter.x, federalCenter.y, federalCenter.z, false, false, false, false)
                        SetEntityHeading(playerPed, 87.19)
                        QBCore.Functions.Notify("No puedes escapar de la prisión federal!", "error")
                    end
                end
            end

            -- Actualizar tiempo (forma compatible con Lua)
            timeLeft = timeLeft - 1

            -- Guardar progreso cada 30 segundos
            if timeLeft % 30 == 0 then
                TriggerServerEvent('sh-mdt:server:updateFederalTime', timeLeft)
            end

            if timeLeft <= 0 then
                TriggerServerEvent('sh-mdt:server:completeFederal')
                endFederal()
                break
            else
                updateFederalHUD()
            end
        end

        -- Cerrar correctamente el "lock" del timer
        timerThread = false
    end)
end

-- Actualizar HUD del tiempo
function updateFederalHUD()
    SendNUIMessage({
        action = 'federal:updateTimer',
        minutes = timeLeft  -- Aunque diga "minutes", son segundos
    })
end

-- Finalizar federal
function endFederal()
    if not isInFederal then return end
    isInFederal = false
    timeLeft = 0

    -- Detener el hilo correctamente
    timerThread = false

    local playerPed = PlayerPedId()
    SetEntityCoords(playerPed, 1849.05, 2586.0, 45.67, false, false, false, false)
    SetEntityHeading(playerPed, 267.35)

    SendNUIMessage({ action = 'federal:hideTimer' })
    QBCore.Functions.Notify("Has cumplido tu condena federal!", "success")
end

-- Evento para liberación manual
RegisterNetEvent('sh-mdt:client:endFederal', function()
    if isInFederal then
        endFederal()
    end
end)

-- 🔥 CORREGIDO: Verificar estado federal al cargar el jugador
RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
    
    Citizen.Wait(8000) -- Esperar más a que todo cargue
    
    QBCore.Functions.TriggerCallback('sh-mdt:server:getFederalStatus', function(federalData)
        if federalData and federalData.time and federalData.time > 0 then
            -- 🔥 IMPORTANTE: Usar el evento, no TriggerEvent
            TriggerEvent('sh-mdt:client:goToFederal', federalData.time)
        else
        end
    end)
end)

-- 🔥 NUEVO: También verificar cuando el recurso se inicia
AddEventHandler('onClientResourceStart', function(resourceName)
    if (GetCurrentResourceName() ~= resourceName) then return end
    
    Citizen.Wait(10000) -- Esperar a que el servidor cargue
    
    QBCore.Functions.TriggerCallback('sh-mdt:server:getFederalStatus', function(federalData)
        if federalData and federalData.time and federalData.time > 0 then
            TriggerEvent('sh-mdt:client:goToFederal', federalData.time)
        end
    end)
end)

-- 🔥 CORREGIDO: No usar GetParentResourceName()
AddEventHandler('onResourceStop', function(resource)
    if resource == "sh-mdt" then
        -- Solo detener el thread sin finalizar la condena
        if timerThread then
            timerThread = nil
        end
    end
end)

-- Pedir lista federal
RegisterNUICallback('federal:getList', function(_, cb)
    QBCore.Functions.TriggerCallback('getFederalList', function(result)
        cb(result or {}) -- 🔒 siempre devuelve algo
    end)
end)


-- 🔹 Liberar jugador federal (NUI Callback)
RegisterNUICallback('federal:liberar', function(data, cb)
    local citizenid = data and data.citizenid
    if not citizenid then
        cb(false) -- ⚠️ devolvemos falso para evitar freeze NUI
        return
    end

    -- 🔹 Ejecutar callback del servidor
    QBCore.Functions.TriggerCallback('liberarFederal', function(success)
        if success then
        else
        end

        cb(success or false) -- ⚠️ devolvemos siempre respuesta, incluso false
    end, { citizenid = citizenid })
end)
