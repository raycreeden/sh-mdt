local QBCore = exports['qb-core']:GetCoreObject()
local PlayerData = {}
local calls = {}
local alertQueue = {}
local currentAlertIndex = 0
local currentAlert = nil
local alertActive = false


-- ======================================================
-- 🔹 MOSTRAR / OCULTAR MINI ALERTA (CORREGIDA PARA MEZCLA)
-- ======================================================
function ShowDispatchAlert(alertData)
    if not alertData.id then
        alertData.id = "LOCAL_" .. GetGameTimer() .. "_" .. math.random(1000, 9999)
    end
    
    if not alertData.time then
        alertData.time = math.floor(GetGameTimer() / 1000)
    end

    -- 🔥 Agregar todas las alertas a la cola
    table.insert(alertQueue, alertData)

    -- 🔊 🔥 Siempre reproducir sonido al recibir alerta (aunque haya una en pantalla)
    PlaySoundFrontend(-1, alertData.sound or "Lose_1st", alertData.sound2 or "GTAO_FM_Events_Soundset", true)

    -- 🔥 Mostrar visualmente solo si no hay otra activa
    if not alertActive or currentAlertIndex < 1 then
        currentAlertIndex = #alertQueue
        DisplayMiniAlert(alertData)
    end
    
    RefreshAlertQueue()
end

function DisplayMiniAlert(alertData)
    alertActive = true
    currentAlert = alertData

    -- 🔥 SONIDO PARA TODAS LAS ALERTAS
    PlaySoundFrontend(-1, "Lose_1st", "GTAO_FM_Events_Soundset", true)

    SendNUIMessage({
        action = 'dispatch:showAlert',
        data = alertData
    })

    CreateAlertBlip(alertData)

    SetTimeout((Config.Dispatch.AlertTime or 15) * 1000, function()
        if alertActive and currentAlert == alertData then
            HideDispatchAlert()
        end
    end)
end

function HideDispatchAlert()
    alertActive = false
    currentAlert = nil
    SendNUIMessage({ action = 'dispatch:hideAlert' })
end

-- ======================================================
-- 🔹 CAMBIAR ENTRE ALERTAS
-- ======================================================
function ShowNextAlert()
    if #alertQueue == 0 then return end
    currentAlertIndex = currentAlertIndex + 1
    if currentAlertIndex > #alertQueue then currentAlertIndex = 1 end
    DisplayMiniAlert(alertQueue[currentAlertIndex])
end

function ShowPreviousAlert()
    if #alertQueue == 0 then return end
    currentAlertIndex = currentAlertIndex - 1
    if currentAlertIndex < 1 then currentAlertIndex = #alertQueue end
    DisplayMiniAlert(alertQueue[currentAlertIndex])
end

-- ======================================================
-- 🔹 CREAR BLIP DE ALERTA
-- ======================================================
function CreateAlertBlip(alertData)
    local blipConfig = Config.Dispatch.Blips[alertData.codeName] or Config.Dispatch.Blips['911call']

    local blip = AddBlipForCoord(alertData.coords.x, alertData.coords.y, alertData.coords.z)
    SetBlipSprite(blip, blipConfig.sprite)
    SetBlipColour(blip, blipConfig.color)
    SetBlipScale(blip, blipConfig.scale)
    SetBlipAsShortRange(blip, false)

    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString(alertData.message or "Alerta 911")
    EndTextCommandSetBlipName(blip)

    if blipConfig.flash then
        SetBlipFlashes(blip, true)
    end

    SetTimeout(blipConfig.length * 60000, function()
        RemoveBlip(blip)
    end)
end

-- ======================================================
-- 🔹 COMANDO /911
-- ======================================================
RegisterCommand('911', function(_, args)
    local message = table.concat(args, " ")
    if message == "" then
        QBCore.Functions.Notify('Debes escribir un mensaje', 'error')
        return
    end

    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    local streetName = GetStreetNameFromHashKey(GetStreetNameAtCoord(coords.x, coords.y, coords.z))

    local alertData = {
        message = "LLAMADA 911",
        codeName = '911call',
        code = '911',
        priority = 1,
        coords = coords,
        street = streetName,
        information = message,
        name = PlayerData.charinfo and (PlayerData.charinfo.firstname .. " " .. PlayerData.charinfo.lastname) or "Desconocido",
        number = PlayerData.charinfo and PlayerData.charinfo.phone or "N/A"
    }

    TriggerServerEvent('sh-mdt:server:sendAlert', alertData)
end)

-- ======================================================
-- 🔹 CERRAR PANEL DISPATCH
-- ======================================================
function hidePanelDispatch()
    SendNUIMessage({ action = 'dispatch:hidePanel' })
    SetNuiFocus(false, false)
end

-- ======================================================
-- 🔹 EVENTOS DEL SERVIDOR
-- ======================================================
RegisterNetEvent('sh-mdt:client:showAlert', function(alertData)
    if not PlayerData or not PlayerData.job then return end
    local jobName = PlayerData.job.name

    -- Solo policías o sheriffs
    if jobName ~= 'police' and jobName ~= 'sheriff' then return end

    -- Si requiere estar de servicio
    if Config.Dispatch.OnDutyOnly and not PlayerData.job.onduty then return end

    -- 🔥 AGREGAR TIMESTAMP SI FALTA (para alertas de disparos)
    if not alertData.time then
        alertData.time = os.time()
    end

    -- Mostrar y actualizar NUI
    ShowDispatchAlert(alertData)
    
    -- 🔥 DEDUPLICACIÓN MEJORADA EN TIEMPO REAL
    local tempQueue = {}
    local seen = {}
    
    for _, alert in ipairs(alertQueue) do
        local key = alert.code .. "_" .. (alert.street or "unknown") .. "_" .. (alert.time or "notime")
        if not seen[key] then
            seen[key] = true
            table.insert(tempQueue, alert)
        end
    end
    
    alertQueue = tempQueue
    
    -- Re-sincronizar índice actual
    if currentAlertIndex > #alertQueue then
        currentAlertIndex = #alertQueue
    end
    if currentAlertIndex < 1 and #alertQueue > 0 then
        currentAlertIndex = 1
    end
    
    RefreshAlertQueue()
end)

RegisterNetEvent('sh-mdt:client:showAlertList', function(alertsList)
    calls = alertsList or {}
    SendNUIMessage({
        action = 'dispatch:showAlertList',
        data = alertsList
    })
end)

RegisterNetEvent('sh-mdt:client:setFocus', function(focus)
    SetNuiFocus(focus, focus)
end)

-- ======================================================
-- 🔹 ACTUALIZAR DATOS DEL JUGADOR
-- ======================================================
RegisterNetEvent('QBCore:Client:OnJobUpdate', function(job)
    PlayerData.job = job
end)

RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
    PlayerData = QBCore.Functions.GetPlayerData()
end)

CreateThread(function()
    Wait(1500)
    PlayerData = QBCore.Functions.GetPlayerData()
end)

-- ======================================================
-- 🔹 CALLBACKS DESDE EL NUI
-- ======================================================
RegisterNUICallback('dispatch:getAlerts', function(_, cb)
    TriggerServerEvent('sh-mdt:server:getActiveAlerts')
    cb('ok')
end)

RegisterNUICallback('dispatch:setWaypoint', function(data, cb)
    local alertId = data.alertId
    if not alertId then return cb('error') end

    local alert = nil
    for _, a in pairs(calls) do
        if a.id == alertId then
            alert = a
            break
        end
    end

    if alert and alert.coords then
        SetNewWaypoint(alert.coords.x, alert.coords.y)
        cb('ok')
    else
        QBCore.Functions.Notify('No se encontró la alerta', 'error')
        cb('error')
    end
end)

RegisterNUICallback('dispatch:clearBlips', function(_, cb)
    local blip = GetFirstBlipInfoId(8)
    while DoesBlipExist(blip) do
        RemoveBlip(blip)
        blip = GetNextBlipInfoId(8)
    end
    cb('ok')
end)

-- 🔹 Sincroniza toda la cola con el NUI
function RefreshAlertQueue()
    SendNUIMessage({
        action = 'dispatch:updateQueue',
        data = alertQueue,
        current = currentAlertIndex
    })
end

-- ======================================================
-- 🔹 CONTROL DE ALERTAS (E / arrow left / arrow right / Cerrar / Limpiar) - FUNCIONA SIEMPRE
-- ======================================================
CreateThread(function()
    while true do
        Wait(0)
        if #alertQueue > 0 then
            -- 🔸 Siguiente alerta (Arrow Right - 175)
            if IsControlJustPressed(0, 175) then  
                currentAlertIndex = currentAlertIndex + 1
                if currentAlertIndex > #alertQueue then currentAlertIndex = 1 end
                currentAlert = alertQueue[currentAlertIndex]
                
                -- Actualizar NUI
                SendNUIMessage({
                    action = 'dispatch:showAlert',
                    data = currentAlert
                })
                
                -- Re-crear blip
                CreateAlertBlip(currentAlert)
            
            -- 🔸 Alerta anterior (Arrow Left - 174)  
            elseif IsControlJustPressed(0, 174) then  
                currentAlertIndex = currentAlertIndex - 1
                if currentAlertIndex < 1 then currentAlertIndex = #alertQueue end
                currentAlert = alertQueue[currentAlertIndex]
                
                -- Actualizar NUI
                SendNUIMessage({
                    action = 'dispatch:showAlert',
                    data = currentAlert
                })
                
                -- Re-crear blip
                CreateAlertBlip(currentAlert)
            
            -- 🔸 Marcar waypoint (E - 38)
            elseif IsControlJustPressed(0, 38) then  
                if currentAlert and currentAlert.coords then
                    SetNewWaypoint(currentAlert.coords.x, currentAlert.coords.y)
                else
                    QBCore.Functions.Notify('No hay coordenadas para esta alerta', 'error', 3000)
                end
            
            -- 🔸 LIMPIAR alerta actual (Input Control - 173)
            elseif IsControlJustPressed(0, 173) then  
                if currentAlert then
                    -- Remover alerta actual de la cola
                    table.remove(alertQueue, currentAlertIndex)
                    
                    -- Ajustar índice si es necesario
                    if currentAlertIndex > #alertQueue then
                        currentAlertIndex = #alertQueue
                    end
                    if currentAlertIndex < 1 and #alertQueue > 0 then
                        currentAlertIndex = 1
                    end
                    
                    if #alertQueue > 0 then
                        -- Mostrar siguiente alerta
                        currentAlert = alertQueue[currentAlertIndex]
                        SendNUIMessage({
                            action = 'dispatch:updateQueue',
                            data = alertQueue,
                            current = currentAlertIndex
                        })
                        CreateAlertBlip(currentAlert)
                    else
                        -- No hay más alertas
                        currentAlert = nil
                        alertActive = false
                        SendNUIMessage({ action = 'dispatch:hideAlert' })
                    end
                end
            
            -- 🔸 CERRAR mini dispatch (Input Control - 172)
            elseif IsControlJustPressed(0, 172) then  
                -- Ocultar visualmente pero mantener las alertas en cola
                SendNUIMessage({ action = 'dispatch:hideAlert' })
                alertActive = false
            end
        end
    end
end)

-- Agregar en la sección de callbacks NUI
RegisterNUICallback('dispatch:syncNavigation', function(data, cb)
    currentAlertIndex = data.currentIndex or 0
    if currentAlertIndex < 1 and #alertQueue > 0 then
        currentAlertIndex = 1
    end
    cb('ok')
end)

-- ======================================================
-- 🔫 SISTEMA DE DETECCIÓN DE DISPAROS (TODO EL SERVIDOR)
-- ======================================================

local lastShootingAlert = 0
local shootingCooldown = Config.ShootingAlerts.cooldown or 30000

-- Función para verificar si un arma genera alerta (CORREGIDA)
function ShouldAlertForWeapon(weaponHash)
    -- 🔥 CONVERTIR los nombres de texto a HASH numéricos para comparar
    local weaponWhitelistHashes = {}
    local weaponBlacklistHashes = {}
    
    -- Convertir whitelist a hashes
    for _, weaponName in ipairs(Config.ShootingAlerts.WeaponWhitelist) do
        local hash = GetHashKey(weaponName)
        weaponWhitelistHashes[hash] = true
    end
    
    -- Convertir blacklist a hashes  
    for _, weaponName in ipairs(Config.ShootingAlerts.WeaponBlacklist) do
        local hash = GetHashKey(weaponName)
        weaponBlacklistHashes[hash] = true
    end
    
    -- Verificar si está en la whitelist (NO genera alerta)
    if weaponWhitelistHashes[weaponHash] then
        return false
    end
    
    -- Verificar si está en la blacklist (SÍ genera alerta)
    if weaponBlacklistHashes[weaponHash] then
        return true
    end
    return false
end

-- Detectar disparos del jugador local (VERSIÓN CON DEBUG)
CreateThread(function()
    while true do
        Wait(0)
        local playerPed = PlayerPedId()
        
        if IsPedShooting(playerPed) then
            local weaponHash = GetSelectedPedWeapon(playerPed)
            
            -- Verificar si el arma debe generar alerta
            if ShouldAlertForWeapon(weaponHash) then
                local currentTime = GetGameTimer()
                
                -- Verificar cooldown
                if currentTime - lastShootingAlert > shootingCooldown then
                    lastShootingAlert = currentTime
                    
                    -- Obtener coordenadas y calle
                    local coords = GetEntityCoords(playerPed)
                    local streetName = GetStreetNameFromHashKey(GetStreetNameAtCoord(coords.x, coords.y, coords.z))
                    
                    -- Reportar al servidor
                    TriggerServerEvent('sh-mdt:server:playerShotWeapon', coords, streetName, weaponHash)
                else
                end
            end
        end
    end
end)

-- ======================================================
-- 🚗 DETECCIÓN INTELIGENTE DE CARJACKING (solo si el jugador apunta al conductor)
-- ======================================================

local lastCarjackAlert = 0
local trackedNPCs = {}

-- ✅ Verifica si el jugador tiene un arma válida para carjacking
function HasCarjackingWeapon()
    local playerPed = PlayerPedId()
    local currentWeapon = GetSelectedPedWeapon(playerPed)
    for _, weaponName in ipairs(Config.CarjackingWeapons) do
        if currentWeapon == GetHashKey(weaponName) then
            return true
        end
    end
    return false
end

CreateThread(function()
    while true do
        Wait(1000)
        local playerPed = PlayerPedId()
        local playerCoords = GetEntityCoords(playerPed)

        -- Solo si el jugador está apuntando a alguien con un arma válida
        if HasCarjackingWeapon() then
            local isAiming, targetPed = GetEntityPlayerIsFreeAimingAt(PlayerId())
            if isAiming and DoesEntityExist(targetPed) and not IsPedAPlayer(targetPed) then
                if IsPedInAnyVehicle(targetPed, false) then
                    local vehicle = GetVehiclePedIsIn(targetPed, false)
                    if GetPedInVehicleSeat(vehicle, -1) == targetPed then
                        local distance = #(playerCoords - GetEntityCoords(targetPed))
                        if distance < 7.0 and not trackedNPCs[targetPed] then
                            trackedNPCs[targetPed] = true
                            TrackCarjack(targetPed, playerCoords, vehicle)
                        end
                    end
                end
            end
        end

        -- Limpiar NPCs muertos o borrados
        for ped, _ in pairs(trackedNPCs) do
            if not DoesEntityExist(ped) then
                trackedNPCs[ped] = nil
            end
        end
    end
end)

-- 🔎 Rastrea si el NPC efectivamente abandona el vehículo tras ser apuntado
function TrackCarjack(npcPed, playerCoords, vehicle)
    CreateThread(function()
        local wasInVehicle = true
        local plate = QBCore.Functions.GetPlate(vehicle)
        local vehicleModel = GetEntityModel(vehicle)
        local vehicleLabel = GetLabelText(GetDisplayNameFromVehicleModel(vehicleModel))
        if vehicleLabel == "NULL" or vehicleLabel == "" then
            vehicleLabel = GetDisplayNameFromVehicleModel(vehicleModel)
        end

        while trackedNPCs[npcPed] and DoesEntityExist(npcPed) do
            Wait(500)
            local currentCoords = GetEntityCoords(npcPed)
            local distanceToPlayer = #(playerCoords - currentCoords)

            -- Si el NPC se baja (por miedo o robo)
            if not IsPedInAnyVehicle(npcPed, false) and wasInVehicle then
                wasInVehicle = false
                local currentTime = GetGameTimer()
                if currentTime - lastCarjackAlert > Config.CarjackingAlert.Cooldown then
                    lastCarjackAlert = currentTime

                    local s1, s2 = GetStreetNameAtCoord(currentCoords.x, currentCoords.y, currentCoords.z)
                    local streetName = GetStreetNameFromHashKey(s1)

                    -- 🔥 Enviar alerta real
                    TriggerServerEvent('sh-mdt:server:carjackAlert', currentCoords, streetName, plate, vehicleLabel)
                end
                trackedNPCs[npcPed] = nil
                break
            end

            -- Si se alejó mucho o el jugador bajó el arma
            if distanceToPlayer > 15.0 or not HasCarjackingWeapon() then
                trackedNPCs[npcPed] = nil
                break
            end
        end
    end)
end

-- ======================================================
-- 💊 DETECTOR LOCAL DE VENTAS DE DROGAS A NPC (CLIENTE)
-- ======================================================

local lastDrugAlert = 0

local function SendDrugSaleAlert()
    -- Cooldown local
    if GetGameTimer() - lastDrugAlert < 4000 then return end
    lastDrugAlert = GetGameTimer()

    -- Probabilidad de que se llame a la policía
    local chance = Config.DrugsDetect.PoliceCallChance or 30
    if math.random(100) > chance then
        return -- 👮‍♂️ No se reporta a la policía esta vez
    end

    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    local s1, s2 = GetStreetNameAtCoord(coords.x, coords.y, coords.z)
    local street = GetStreetNameFromHashKey(s1)

    TriggerServerEvent('sh-mdt:server:reportDrugSale', {
        coords = coords,
        street = street,
    })
end

-- 🔹 Método 1: Detectar animación de venta (la que usa qb-drugs)
CreateThread(function()
    while true do
        Wait(500)
        local ped = PlayerPedId()
        if IsEntityPlayingAnim(ped, "gestures@f@standing@casual", "gesture_point", 3) then
            local playerCoords = GetEntityCoords(ped)
            local foundNPC = false

            for pedNearby in EnumeratePeds() do
                if DoesEntityExist(pedNearby) and not IsPedAPlayer(pedNearby) and not IsEntityDead(pedNearby) then
                    local dist = #(GetEntityCoords(pedNearby) - playerCoords)
                    if dist < 3.0 then
                        foundNPC = true
                        break
                    end
                end
            end

            if foundNPC then
                SendDrugSaleAlert()
            end
        end
    end
end)

-- 🔹 Enumerador de peds (función auxiliar)
function EnumerateEntities(initFunc, moveFunc, disposeFunc)
    return coroutine.wrap(function()
        local iter, id = initFunc()
        if not id or id == 0 then
            disposeFunc(iter)
            return
        end
        local enum = { handle = iter, destructor = disposeFunc }
        setmetatable(enum, {
            __gc = function(obj)
                if obj.destructor and obj.handle then
                    obj.destructor(obj.handle)
                end
            end,
        })
        local next = true
        repeat
            coroutine.yield(id)
            next, id = moveFunc(iter)
        until not next
        enum.destructor, enum.handle = nil, nil
        disposeFunc(iter)
    end)
end

function EnumeratePeds()
    return EnumerateEntities(FindFirstPed, FindNextPed, EndFindPed)
end

-- ======================================================
-- 🚗 DETECCIÓN DE ROBO DE VEHÍCULO ESTACIONADO (LOCKPICK)
-- ======================================================
local lastVehTheft = 0

-- ===============================
-- FUNCION CENTRAL DE ALERTA
-- ===============================
local function SendVehicleTheftAlert()
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    local vehicle = GetClosestVehicle(coords.x, coords.y, coords.z, Config.VehicleTheft.DetectRadius, 0, 71)
    if not vehicle or vehicle == 0 then return end

    local now = GetGameTimer()
    if now - lastVehTheft < Config.VehicleTheft.AlertCooldown then return end
    lastVehTheft = now

    -- Probabilidad de alerta
    if math.random(1, 100) > Config.VehicleTheft.AlertChance then
        return
    end

    local plate = QBCore.Functions.GetPlate(vehicle)
    local model = GetEntityModel(vehicle)
    local label = GetDisplayNameFromVehicleModel(model)
    local s1, s2 = GetStreetNameAtCoord(coords.x, coords.y, coords.z)
    local street = GetStreetNameFromHashKey(s1)

    TriggerServerEvent('sh-mdt:server:vehicleTheftAlert', coords, street, plate, label)
end

-- ==========================================
-- 1️⃣ CAPTURAR LOCKPICK ROTO (SERVER→CLIENT)
-- ==========================================
RegisterNetEvent('dispatch:client:LockpickBroken', function()
    SendVehicleTheftAlert()
end)

-- ==========================================
-- 2️⃣ INTERCEPTAR FALLO DE MINIJUEGO
-- ==========================================
-- Sobrescribimos la función AttemptPoliceAlert si existe
CreateThread(function()
    while AttemptPoliceAlert == nil do
        Wait(500)
    end
    local oldAlert = AttemptPoliceAlert
    AttemptPoliceAlert = function(type)
        if type == 'steal' then
            SendVehicleTheftAlert()
        end
        oldAlert(type)
    end
end)

RegisterNetEvent('sh-mdt:client:receivePoliceChat', function(msg)
    SendNUIMessage({
        action = 'dispatch:addPoliceChat',
        message = msg
    })
end)

RegisterNUICallback('sendPoliceChat', function(data, cb)
    local msg = data.message or ''
    if msg ~= '' then
        ExecuteCommand('ipol ' .. msg)
    end
    cb('ok')
end)

