local QBCore = exports['qb-core']:GetCoreObject()

-- Variables
local CurrentStatusList = {}
local Casings = {}
local BloodDrops = {}
local Fingerprints = {}
local shotAmount = 0
local nearestEvidence = nil
local nearestEvidenceType = nil
local impactPoints = {}
local DamagedNPCs = {}
local lastNPCCheck = 0
local revealedEvidences = {} -- Evidencias que han sido reveladas con linterna

local StatusList = {
    ['fight'] = 'Manos rojas',
    ['widepupils'] = 'Pupilas dilatadas',
    ['redeyes'] = 'Ojos rojos',
    ['weedsmell'] = 'Olor a marihuana',
    ['gunpowder'] = 'Pólvora en manos',
    ['chemicals'] = 'Olor a químicos',
    ['heavybreath'] = 'Respiración pesada',
    ['sweat'] = 'Sudoración excesiva',
    ['handbleed'] = 'Manos sangrando',
    ['confused'] = 'Confusión',
    ['alcohol'] = 'Olor a alcohol',
    ['heavyalcohol'] = 'Olor fuerte a alcohol',
    ['agitated'] = 'Agitación'
}

local WhitelistedWeapons = {
    `weapon_unarmed`,
    `weapon_snowball`,
    `weapon_stungun`,
    `weapon_petrolcan`,
    `weapon_hazardcan`,
    `weapon_fireextinguisher`
}

-- Función simple para verificar si la linterna está activa
local function IsFlashlightActive()
    return GetSelectedPedWeapon(PlayerPedId()) == `weapon_flashlight`
end

-- Función para revelar evidencia permanentemente
local function RevealEvidence(evidenceId)
    revealedEvidences[evidenceId] = true
end

-- Función para detectar daño a NPCs
local function CheckNPCDamage()
    local currentTime = GetGameTimer()
    
    -- Verificar cada 500ms para no sobrecargar
    if currentTime - lastNPCCheck < 1000 then
        return
    end
    lastNPCCheck = currentTime
    
    local playerCoords = GetEntityCoords(PlayerPedId())
    local nearbyPeds = GetGamePool('CPed')
    
    for _, ped in ipairs(nearbyPeds) do
        -- Verificar si es un NPC (no jugador, no muerto, no en vehículo)
        if DoesEntityExist(ped) and not IsPedAPlayer(ped) and not IsPedDeadOrDying(ped, true) and not IsPedInAnyVehicle(ped, false) then
            local pedCoords = GetEntityCoords(ped)
            local distance = #(playerCoords - pedCoords)
            
-- Solo NPCs cercanos (50 metros)
if distance < 20.0 then
    local pedHealth = GetEntityHealth(ped)

    -- 🧠 FIX: evitar spam por entidades sin red
    local pedId
    if DoesEntityExist(ped) and NetworkGetEntityIsNetworked(ped) then
        pedId = PedToNet(ped)
    else
        pedId = ped -- usamos el handle local (no causa warning)
    end

                -- Verificar si el NPC ya está en nuestra lista
                if not DamagedNPCs[pedId] then
                    DamagedNPCs[pedId] = {
                        health = pedHealth,
                        coords = pedCoords,
                        lastChecked = currentTime
                    }
                else
                    -- Verificar si recibió daño
                    local npcData = DamagedNPCs[pedId]
                    if pedHealth < npcData.health then
                        local damageTaken = npcData.health - pedHealth
                        
                        -- Solo crear sangre si el daño es significativo
                        if damageTaken >= 10 then
                            
                            -- Obtener el arma que causó el daño
                            local weapon = GetSelectedPedWeapon(PlayerPedId())
                            
                            -- Enviar al servidor
                            TriggerServerEvent('evidence:server:OnNPCDamage', pedId, pedCoords, weapon)
                            
                            -- Actualizar salud en la lista
                            DamagedNPCs[pedId].health = pedHealth
                            DamagedNPCs[pedId].coords = pedCoords
                        end
                    end
                    
                    -- Actualizar coordenadas
                    DamagedNPCs[pedId].coords = pedCoords
                    DamagedNPCs[pedId].lastChecked = currentTime
                end
            end
        end
    end
    
    -- Limpiar NPCs viejos de la lista (más de 30 segundos sin ver)
    for npcId, npcData in pairs(DamagedNPCs) do
        if currentTime - npcData.lastChecked > 30000 then
            DamagedNPCs[npcId] = nil
        end
    end
end


-- Hilo para detectar daño a NPCs
CreateThread(function()
    while true do
        Wait(1000) -- Revisar cada segundo
        
        local PlayerData = QBCore.Functions.GetPlayerData()
        if PlayerData and PlayerData.job and PlayerData.job.name == 'police' then
            CheckNPCDamage()
        end
    end
end)

-- Limpiar puntos de impacto viejos (más de 10 minutos)
CreateThread(function()
    while true do
        Wait(30000) -- Cada 30 segundos
        local currentTime = GetGameTimer()
        
        for i = #impactPoints, 1, -1 do
            if impactPoints[i] and (currentTime - impactPoints[i].createdAt) > 600000 then -- 10 minutos
                table.remove(impactPoints, i)
            end
        end
    end
end)

-- Functions
local function DrawText3D(x, y, z, text)
    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextEntry("STRING")
    SetTextCentre(true)
    AddTextComponentString(text)
    SetDrawOrigin(x, y, z, 0)
    DrawText(0.0, 0.0)
    local factor = (string.len(text)) / 370
    DrawRect(0.0, 0.0 + 0.0125, 0.017 + factor, 0.03, 0, 0, 0, 75)
    ClearDrawOrigin()
end

local function DrawMarkerAtEvidence(coords, color)
    DrawMarker(2, coords.x, coords.y, coords.z + 0.05, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.2, 0.3, 0.1, color.r, color.g, color.b, 150, false, true, 2, false, false, false, false)
end

-- MEJORAR los marcadores de sangre para hacerlos más visibles:
local function DrawBloodMarker(coords)
    -- Marker grande en el suelo (naranja)
    DrawMarker(2, coords.x, coords.y, coords.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.2, 0.2, 0.1, 255, 50, 0, 180, false, true, 2, false, false, false, false)
    
end

local function WhitelistedWeapon(weapon)
    for i = 1, #WhitelistedWeapons do
        if WhitelistedWeapons[i] == weapon then
            return true
        end
    end
    return false
end

local function DropBulletCasing(weapon, ped)
    local randX = math.random() + math.random(-1, 1)
    local randY = math.random() + math.random(-1, 1)
    local coords = GetOffsetFromEntityInWorldCoords(ped, randX, randY, 0)
    TriggerServerEvent('evidence:server:CreateCasing', weapon, coords)
    Wait(300)
end

local function DnaHash(s)
    local h = string.gsub(s, '.', function(c)
        return string.format('%02x', string.byte(c))
    end)
    return h
end

-- FUNCIÓN CORREGIDA: Crear sangre automáticamente
local function CreateBloodAutomatically()
    local playerCoords = GetEntityCoords(PlayerPedId())
    local Player = QBCore.Functions.GetPlayerData()
    
    if not Player or not Player.metadata or not Player.metadata.bloodtype then
        return
    end
    
    -- Crear múltiples muestras de sangre en patrón circular
    for i = 1, 3 do
        local angle = (i / 3) * math.pi * 2
        local offsetX = math.cos(angle) * 1.0
        local offsetY = math.sin(angle) * 1.0
        local bloodCoords = vector3(
            playerCoords.x + offsetX,
            playerCoords.y + offsetY,
            playerCoords.z - 0.9
        )
        
        -- Enviar al servidor
        TriggerServerEvent('evidence:server:CreateBloodDrop', Player.citizenid, Player.metadata.bloodtype, bloodCoords)
        Wait(50)
    end
end

-- Crear huellas en vehículos (versión corregida y segura)
local function CreateFingerprintOnVehicleEnter(vehicle)
    if not DoesEntityExist(vehicle) then return end

    -- Evitar spam: solo vehículos sincronizados en red
    if not NetworkGetEntityIsNetworked(vehicle) then
        return
    end

    local ped = PlayerPedId()
    local doorBones = { "door_dside_f", "door_pside_f", "door_dside_r", "door_pside_r", "handle_dside_f" }
    local doorBone = doorBones[math.random(1, #doorBones)]
    local boneIndex = GetEntityBoneIndexByName(vehicle, doorBone)

    if boneIndex == -1 then
        return
    end

    local boneCoords = GetWorldPositionOfEntityBone(vehicle, boneIndex)
    if boneCoords then
        -- ✅ Obtener el Network ID del vehículo de forma segura
        local netId = NetworkGetNetworkIdFromEntity(vehicle)
        if not netId or netId == 0 then
            return
        end

        -- ✅ Enviar huella asociada al vehículo
        TriggerServerEvent('evidence:server:CreateFingerDrop', {
            coords = boneCoords,
            netId = netId
        })

    end
end

-- Función para recolectar la evidencia más cercana
local function CollectNearestEvidence()
    if not nearestEvidence then return end
    
    local PlayerData = QBCore.Functions.GetPlayerData()
    if not PlayerData or not PlayerData.job or PlayerData.job.name ~= 'police' or not PlayerData.job.onduty then
        QBCore.Functions.Notify('No estás en servicio como policía', 'error')
        return
    end
    
    local ped = PlayerPedId()
    
 -- 🔁 Animación de recoger del suelo (optimizada y compatible)
local animDict = "pickup_object"
RequestAnimDict(animDict)

local timeout = 0
while not HasAnimDictLoaded(animDict) and timeout < 5000 do
    Wait(10)
    timeout = timeout + 10
end

if HasAnimDictLoaded(animDict) then
    TaskPlayAnim(ped, animDict, "pickup_low", 8.0, -8.0, 1000, 49, 0, false, false, false)
    Wait(600)
else
    print("^3[sh-mdt] Advertencia: no se pudo cargar la animación de recoger objeto.^0")
end

    local coords = nil
    local info = {}
    
    if nearestEvidenceType == 'casing' then
        local casing = Casings[nearestEvidence]
        if not casing then return end
        coords = casing.coords
        
        local s1, s2 = GetStreetNameAtCoord(coords.x, coords.y, coords.z)
        local street1 = GetStreetNameFromHashKey(s1)
        local street2 = GetStreetNameFromHashKey(s2)
        local streetLabel = street1
        if street2 then
            streetLabel = streetLabel .. ' | ' .. street2
        end
        
        info = {
            label = 'Casquillo de bala',
            type = 'casing',
            street = streetLabel:gsub("%'", ''),
            ammotype = casing.type,
            serie = casing.serie or 'Serial no visible'
        }
        TriggerServerEvent('evidence:server:AddCasingToInventory', nearestEvidence, info)
        
    elseif nearestEvidenceType == 'blood' then
        local blood = BloodDrops[nearestEvidence]
        if not blood then return end
        coords = blood.coords
        
        local s1, s2 = GetStreetNameAtCoord(coords.x, coords.y, coords.z)
        local street1 = GetStreetNameFromHashKey(s1)
        local street2 = GetStreetNameFromHashKey(s2)
        local streetLabel = street1
        if street2 then
            streetLabel = streetLabel .. ' | ' .. street2
        end
        
        info = {
            label = 'Muestra de sangre',
            type = 'blood',
            street = streetLabel:gsub("%'", ''),
            dnalabel = DnaHash(blood.citizenid),
            bloodtype = blood.bloodtype
        }
        TriggerServerEvent('evidence:server:AddBlooddropToInventory', nearestEvidence, info)
        
    elseif nearestEvidenceType == 'fingerprint' then
        local finger = Fingerprints[nearestEvidence]
        if not finger then return end
        coords = finger.coords
        
        local s1, s2 = GetStreetNameAtCoord(coords.x, coords.y, coords.z)
        local street1 = GetStreetNameFromHashKey(s1)
        local street2 = GetStreetNameFromHashKey(s2)
        local streetLabel = street1
        if street2 then
            streetLabel = streetLabel .. ' | ' .. street2
        end
        
        info = {
            label = 'Huella digital',
            type = 'fingerprint',
            street = streetLabel:gsub("%'", ''),
            fingerprint = finger.fingerprint
        }
        TriggerServerEvent('evidence:server:AddFingerprintToInventory', nearestEvidence, info)
    end
    
    -- Limpiar animación
    ClearPedTasks(ped)
    
    nearestEvidence = nil
    nearestEvidenceType = nil
end

-- Función para limpiar la evidencia más cercana (VERSIÓN ALTERNATIVA)
local function CleanNearestEvidence()
    if not nearestEvidence then return end
    
    local PlayerData = QBCore.Functions.GetPlayerData()
    if not PlayerData or not PlayerData.job or PlayerData.job.name ~= 'police' or not PlayerData.job.onduty then
        QBCore.Functions.Notify('No estás en servicio como policía', 'error')
        return
    end
    
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    
    -- Cargar el diccionario de animación
    RequestAnimDict("anim@gangops@facility@servers@bodysearch@")
    while not HasAnimDictLoaded("anim@gangops@facility@servers@bodysearch@") do
        Wait(10)
    end
    
    -- Forzar posición y animación
    SetCurrentPedWeapon(ped, `WEAPON_UNARMED`, true)
    ClearPedTasksImmediately(ped)
    
    -- Iniciar animación con flags más específicos
    TaskPlayAnim(ped, "anim@gangops@facility@servers@bodysearch@", "player_search", 
        1.0, -- velocidad de blend in
        1.0, -- velocidad de blend out  
        3000, -- duración
        16, -- flags: 1 (repetir) + 16 (stop last frame) + 32 (upper body only)
        0, -- tasa de repetición
        false, -- no lock X
        false, -- no lock Y
        false -- no lock Z
    )
    
    QBCore.Functions.Progressbar('clean_evidence', 'Limpiando evidencia...', 3000, false, true, {
        disableMovement = true,
        disableCarMovement = true,
        disableMouse = false,
        disableCombat = true,
    }, {}, {}, {}, function()
        -- Success
        if nearestEvidenceType == 'casing' then
            TriggerServerEvent('evidence:server:RemoveCasing', nearestEvidence)
        elseif nearestEvidenceType == 'blood' then
            TriggerServerEvent('evidence:server:RemoveBlooddrop', nearestEvidence)
        elseif nearestEvidenceType == 'fingerprint' then
            TriggerServerEvent('evidence:server:RemoveFingerprint', nearestEvidence)
        end
        
        -- Limpiar también de las evidencias reveladas
        revealedEvidences[nearestEvidence] = nil
        
        -- Limpiar animación
        ClearPedTasks(ped)
        
        QBCore.Functions.Notify('Evidencia limpiada', 'success')
        
        nearestEvidence = nil
        nearestEvidenceType = nil
    end, function()
        -- Cancel
        ClearPedTasks(ped)
        QBCore.Functions.Notify('Cancelado', 'error')
    end)
end

-- Events
RegisterNetEvent('evidence:client:SetStatus', function(statusId, time)
    if time > 0 and StatusList[statusId] then
        if (CurrentStatusList == nil or CurrentStatusList[statusId] == nil) or
            (CurrentStatusList[statusId] and CurrentStatusList[statusId].time < 20) then
            CurrentStatusList[statusId] = {
                text = StatusList[statusId],
                time = time
            }
            QBCore.Functions.Notify(CurrentStatusList[statusId].text, 'error')
        end
    elseif StatusList[statusId] then
        CurrentStatusList[statusId] = nil
    end
    TriggerServerEvent('evidence:server:UpdateStatus', CurrentStatusList)
end)

-- EVENTO CLAVE CORREGIDO: Recibir sangre del servidor
RegisterNetEvent('evidence:client:AddBlooddrop', function(bloodId, citizenid, bloodtype, coords)
    
    if not coords or type(coords) ~= 'vector3' then
        return
    end
    
    -- Usar las coordenadas exactas que vienen del servidor
    BloodDrops[bloodId] = {
        citizenid = citizenid,
        bloodtype = bloodtype,
        coords = vector3(coords.x, coords.y, coords.z)
    }

end)

RegisterNetEvent('evidence:client:RemoveBlooddrop', function(bloodId)
    BloodDrops[bloodId] = nil
    revealedEvidences[bloodId] = nil
end)

-- Cliente: recibir huella (acepta opcionalmente netId)
RegisterNetEvent('evidence:client:AddFingerPrint', function(fingerId, fingerprint, coords, netId)
    if not coords then return end

    -- Guardamos la entrada base
    Fingerprints[fingerId] = {
        fingerprint = fingerprint,
        -- coords inicial (si no hay vehículo, se usa como fijo)
        coords = vector3(coords.x, coords.y, coords.z - 0.9),
        vehicleNetId = netId and tonumber(netId) or nil,
        offset = nil -- se calcula si viene vehicleNetId
    }

    -- Si vino asociado a un vehículo, calculamos offset local para seguirlo
    if Fingerprints[fingerId].vehicleNetId then
        local ent = NetworkGetEntityFromNetworkId(Fingerprints[fingerId].vehicleNetId)
        if DoesEntityExist(ent) then
            local vehCoords = GetEntityCoords(ent)
            Fingerprints[fingerId].offset = Fingerprints[fingerId].coords - vehCoords
        else
            -- si no existe aún, lo dejamos como coord fija, pero intentaremos más tarde
        end
    end
end)

RegisterNetEvent('evidence:client:RemoveFingerprint', function(fingerId)
    Fingerprints[fingerId] = nil
    revealedEvidences[fingerId] = nil
end)

RegisterNetEvent('evidence:client:AddCasing', function(casingId, weapon, coords, serie)
    Casings[casingId] = {
        type = weapon,
        serie = serie and serie or 'Serial no visible',
        coords = vector3(coords.x, coords.y, coords.z - 0.9)
    }
end)

RegisterNetEvent('evidence:client:RemoveCasing', function(casingId)
    Casings[casingId] = nil
    revealedEvidences[casingId] = nil
end)

-- Función auxiliar para contar elementos en tabla
function GetTableLength(table)
    local count = 0
    for _ in pairs(table) do count = count + 1 end
    return count
end

-- Threads

-- Hilo principal para mostrar/ocultar evidencias - MODIFICADO CON SISTEMA DE LINTERNA
-- Hilo principal de evidencias optimizado
CreateThread(function()
    local evidenceTimers = {}
    local lastFlashlight = false

    while true do
        local ped = PlayerPedId()
        local pos = GetEntityCoords(ped)
        local PlayerData = QBCore.Functions.GetPlayerData()
        local wait = 1000  -- valor base alto (baja carga)
        local flashlightActive = IsFlashlightActive()
        local currentTime = GetGameTimer()

        -- Solo procesar si sos policía en servicio
        if PlayerData and PlayerData.job and PlayerData.job.name == 'police' and PlayerData.job.onduty then
            -- Solo bajar el wait si hay linterna o evidencias activas
            if flashlightActive or next(revealedEvidences) ~= nil then
                wait = 0
            end

            nearestEvidence = nil
            nearestEvidenceType = nil
            local closestDistance = 1.5

            -- Buscar sangre
            for bloodId, blood in pairs(BloodDrops) do
                local dist = #(pos - blood.coords)
                if dist < 10.0 then
                    if flashlightActive and dist < 5.0 then
                        RevealEvidence(bloodId)
                        evidenceTimers[bloodId] = currentTime + 8000
                    end
                    if evidenceTimers[bloodId] and currentTime > evidenceTimers[bloodId] then
                        revealedEvidences[bloodId] = nil
                        evidenceTimers[bloodId] = nil
                    end
                    if revealedEvidences[bloodId] then
                        DrawBloodMarker(blood.coords)
                        if dist < closestDistance then
                            closestDistance = dist
                            nearestEvidence = bloodId
                            nearestEvidenceType = 'blood'
                        end
                    end
                end
            end

            -- Buscar casquillos
            for casingId, casing in pairs(Casings) do
                local dist = #(pos - casing.coords)
                if dist < 10.0 then
                    if flashlightActive and dist < 5.0 then
                        RevealEvidence(casingId)
                        evidenceTimers[casingId] = currentTime + 8000
                    end
                    if evidenceTimers[casingId] and currentTime > evidenceTimers[casingId] then
                        revealedEvidences[casingId] = nil
                        evidenceTimers[casingId] = nil
                    end
                    if revealedEvidences[casingId] then
                        DrawMarkerAtEvidence(casing.coords, {r = 255, g = 255, b = 0})
                        if dist < closestDistance then
                            closestDistance = dist
                            nearestEvidence = casingId
                            nearestEvidenceType = 'casing'
                        end
                    end
                end
            end

            -- Buscar huellas
            for fingerId, finger in pairs(Fingerprints) do
                local dist = #(pos - finger.coords)
                if dist < 10.0 then
                    if flashlightActive and dist < 5.0 then
                        RevealEvidence(fingerId)
                        evidenceTimers[fingerId] = currentTime + 8000
                    end
                    if evidenceTimers[fingerId] and currentTime > evidenceTimers[fingerId] then
                        revealedEvidences[fingerId] = nil
                        evidenceTimers[fingerId] = nil
                    end
                    if revealedEvidences[fingerId] then
                        local coords = vector3(finger.coords.x, finger.coords.y, finger.coords.z + 0.90)
                        DrawMarkerAtEvidence(coords, {r = 0, g = 100, b = 255})
                        if dist < closestDistance then
                            closestDistance = dist
                            nearestEvidence = fingerId
                            nearestEvidenceType = 'fingerprint'
                        end
                    end
                end
            end

            -- Texto 3D
            if nearestEvidence and revealedEvidences[nearestEvidence] then
                local evidenceCoords, evidenceText
                if nearestEvidenceType == 'casing' then
                    evidenceCoords = Casings[nearestEvidence].coords
                    evidenceText = "~y~Casquillo de Bala~s~"
                elseif nearestEvidenceType == 'blood' then
                    evidenceCoords = BloodDrops[nearestEvidence].coords
                    evidenceText = "~o~Muestra de Sangre~s~"
                elseif nearestEvidenceType == 'fingerprint' then
                    evidenceCoords = Fingerprints[nearestEvidence].coords
                    evidenceText = "~b~Huella Digital~s~"
                end
                if evidenceCoords then
                    DrawText3D(evidenceCoords.x, evidenceCoords.y, evidenceCoords.z + 0.2, evidenceText)
                    DrawText3D(evidenceCoords.x, evidenceCoords.y, evidenceCoords.z + 0.1, "[G] Recoger   [H] Limpiar")
                end
            end
        else
            nearestEvidence = nil
            nearestEvidenceType = nil
        end

        -- Pequeña pausa adaptativa
        Wait(wait)
    end
end)

-- Hilo para controlar la tecla G (Recoger) y H (Limpiar) - MODIFICADO
CreateThread(function()
    while true do
        local wait = 1000
        
        if nearestEvidence and revealedEvidences[nearestEvidence] then  -- Solo si está revelada
            wait = 0
            
            if IsControlJustReleased(0, 47) then  -- Tecla G
                CollectNearestEvidence()
                Wait(1000)
            end
            
            if IsControlJustReleased(0, 74) then  -- Tecla H
                CleanNearestEvidence()
                Wait(1000)
            end
        end
        
        Wait(wait)
    end
end)

-- SISTEMA CORREGIDO: Crear sangre automáticamente al recibir daño
CreateThread(function()
    local lastHealth = GetEntityHealth(PlayerPedId())
    local lastBloodCreation = 0
    local skipFirstCheck = true  -- 🔥 NUEVA VARIABLE PARA SALTAR LA PRIMERA VERIFICACIÓN
    
    while true do
        Wait(500)
        local ped = PlayerPedId()
        local health = GetEntityHealth(ped)
        local currentTime = GetGameTimer()
        
        -- Verificar si recibió daño (salud disminuyó)
        if health < lastHealth then
            local damageTaken = lastHealth - health
            
            -- 🔥 SALTAR LA PRIMERA DETECCIÓN (cuando el jugador se conecta)
            if skipFirstCheck then
                skipFirstCheck = false
            else
                
                -- Crear sangre con cualquier daño
                if (currentTime - lastBloodCreation) > 3000 then -- Cooldown de 3 segundos
                    CreateBloodAutomatically()
                    lastBloodCreation = currentTime
                end
            end
        end
        
        lastHealth = health
    end
end)

-- Hilo para crear huellas al entrar en vehículos (corregido)
CreateThread(function()
    local lastVehicle = nil
    while true do
        Wait(1000)
        local ped = PlayerPedId()
        local vehicle = GetVehiclePedIsIn(ped, false)

        if vehicle ~= 0 and vehicle ~= lastVehicle then
            if DoesEntityExist(vehicle) then
                if NetworkGetEntityIsNetworked(vehicle) then
                    if math.random(1, 100) <= 80 then
                        CreateFingerprintOnVehicleEnter(vehicle)
                    end
                else

                end
            end
        end

        lastVehicle = vehicle
    end
end)

-- Hilo para actualizar status
CreateThread(function()
    while true do
        Wait(10000)
        if LocalPlayer.state.isLoggedIn then
            if CurrentStatusList and next(CurrentStatusList) then
                for k, _ in pairs(CurrentStatusList) do
                    if CurrentStatusList[k].time > 0 then
                        CurrentStatusList[k].time = CurrentStatusList[k].time - 10
                    else
                        CurrentStatusList[k].time = 0
                    end
                end
                TriggerServerEvent('evidence:server:UpdateStatus', CurrentStatusList)
            end
            if shotAmount > 0 then
                shotAmount = 0
            end
        end
    end
end)

-- Hilo para casquillos al disparar
CreateThread(function()
    local ped
    while true do
        ped = PlayerPedId()

        if IsPedArmed(ped, 4) then -- solo si tiene arma de fuego
            if IsPedShooting(ped) then
                local weapon = GetSelectedPedWeapon(ped)
                if not WhitelistedWeapon(weapon) then
                    shotAmount = shotAmount + 1

                    if shotAmount >= 2 then
                        local chance = math.min(30 + (shotAmount * 15), 85)
                        if math.random(1, 100) <= chance then
                            TriggerEvent('evidence:client:SetStatus', 'gunpowder', 300)
                        end
                    end
                    DropBulletCasing(weapon, ped)
                    Wait(1000)
                end
            end
            Wait(50) -- 20 comprobaciones por segundo como máximo
        else
            Wait(500) -- si no está armado, baja la frecuencia
        end
    end
end)

-- Thread para actualizar huellas que están asociadas a vehículos por NetID
CreateThread(function()
    while true do
        Wait(200) -- suficiente y económico
        for id, f in pairs(Fingerprints) do
            if f and f.vehicleNetId then
                local ent = NetworkGetEntityFromNetworkId(f.vehicleNetId)
                if DoesEntityExist(ent) then
                    local vehCoords = GetEntityCoords(ent)
                    if f.offset then
                        f.coords = vehCoords + f.offset
                    else
                        -- si no tenía offset, lo recomputamos
                        f.offset = f.coords - vehCoords
                        f.coords = vehCoords + f.offset
                    end
                else
                    -- vehículo desapareció/ya no está neteado: dejamos la huella fija en su última posición
                    f.vehicleNetId = nil
                    f.offset = nil
                end
            end
        end
    end
end)
