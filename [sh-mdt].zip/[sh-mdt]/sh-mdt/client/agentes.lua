local QBCore = exports['qb-core']:GetCoreObject()

-- Abrir NUI desde el client (si lo necesitas)
RegisterNetEvent('sh-mdt:client:openAgentes')
AddEventHandler('sh-mdt:client:openAgentes', function()
    SendNUIMessage({ action = 'open' })
    SetNuiFocus(true, true)
end)

-- Buscar jugador más cercano
RegisterNUICallback('agentes:getClosest', function(data, cb)
    local player, distance = QBCore.Functions.GetClosestPlayer()
    if player ~= -1 and distance <= 3.0 then
        local serverId = GetPlayerServerId(player)
        cb({ serverId = serverId })
    else
        cb({})
    end
end)

-- Agregar agente (setjob police 0)
RegisterNUICallback('agentes:addAgentByServerId', function(data, cb)
    local target = tonumber(data.serverId)
    if target then
        TriggerServerEvent('sh-mdt:server:addAgent', target)
        cb({ success = true })
    else
        cb({ success = false })
    end
end)

-- Llamada cliente para pedir la lista (se hace con QBCore.TriggerCallback)
RegisterNUICallback('agentes:getOficiales', function(data, cb)
    QBCore.Functions.TriggerCallback('sh-mdt:server:getOficiales', function(oficiales)
        cb(oficiales or {})
    end)
end)

RegisterNUICallback('agentes:getProfile', function(data, cb)
    local target = tonumber(data.serverId)
    QBCore.Functions.TriggerCallback('sh-mdt:server:getAgentProfile', function(profile)
        cb(profile or {})
    end, target)
end)

-- Cuando NUI pide generar acción de setGrade
RegisterNUICallback('agentes:setGrade', function(data, cb)
    local target = tonumber(data.serverId)
    local newGrade = tonumber(data.grade)
    if not target or not newGrade then return cb({ success = false }) end

    -- Escuchar respuesta temporal del server
    local timeout = false
    local result = nil

    local eventHandler
    eventHandler = RegisterNetEvent('sh-mdt:client:gradeResponse', function(success, msg)
        result = success
        QBCore.Functions.Notify(msg, success and "success" or "error")
        RemoveEventHandler(eventHandler)
    end)

    TriggerServerEvent('sh-mdt:server:setPlayerGrade', target, newGrade)

    -- Pequeño delay para asegurar sincronización y devolver respuesta al NUI
    SetTimeout(1000, function()
        cb({ success = result or false })
    end)
end)

-- Agregar tag a agente
RegisterNUICallback('agentes:addTag', function(data, cb)
    local target = tonumber(data.serverId)
    local tag = tostring(data.tag)
    TriggerServerEvent('sh-mdt:server:addTagToAgent', target, tag)
    cb({ ok = true })
end)

RegisterNUICallback('agentes:removeTag', function(data, cb)
    local target = tonumber(data.serverId)
    local tag = tostring(data.tag)
    TriggerServerEvent('sh-mdt:server:removeTagFromAgent', target, tag)
    cb({ ok = true })
end)

-- Petición para listar los rangos disponibles (se pide al servidor)
RegisterNUICallback('agentes:getRanks', function(data, cb)
    QBCore.Functions.TriggerCallback('sh-mdt:server:getJobGrades', function(grades)
        cb(grades or {})
    end)
end)

RegisterNUICallback('agentes:despedirAgent', function(data, cb)
    local target = tonumber(data.serverId)
    
    if not target then
        cb({ success = false, error = "ID inválido" })
        return
    end
    
    -- 🔥 CORRECCIÓN: No verificar si el jugador existe desde el CLIENTE
    -- El cliente no puede verificar jugadores en el servidor
    -- Esta verificación se hace en el SERVIDOR
    
    -- Enviar al servidor y esperar respuesta
    TriggerServerEvent('sh-mdt:server:despedirAgent', target)
    
    -- Respuesta inmediata al NUI
    cb({ success = true })
    
    -- Actualizar la interfaz después de un breve delay
    Citizen.SetTimeout(1000, function()
        SendNUIMessage({ action = 'refreshAgentes' })
    end)
end)

-- Agregar estos eventos al final del client/agentes.lua

-- Evento para actualizar la lista cuando se agrega/elimina un agente
RegisterNetEvent('sh-mdt:client:refreshAgentes', function()
    if IsNuiFocused() then
        SendNUIMessage({ action = 'refreshAgentes' })
    end
end)

-- Evento para notificar cambios
RegisterNetEvent('sh-mdt:client:agentUpdated', function()
    TriggerEvent('sh-mdt:client:refreshAgentes')
end)